//! # BlockForge Core
//!
//! A dependency-free, performance-first voxel engine core targeting
//! **Minecraft: Java Edition 1.21.11** (protocol 774, data version 4671).
//!
//! The crate is the *core* only: data structures, algorithms and the simulation primitives.
//! A renderer (wgpu / Vulkan / OpenGL), audio, input and gameplay systems plug on top of it.
//!
//! | module      | purpose                                                              |
//! |-------------|----------------------------------------------------------------------|
//! | [`math`]    | `Vec3`, `BlockPos`, `ChunkPos`, `Aabb`, `Face`, world-height consts   |
//! | [`rng`]     | bit-exact `java.util.Random` + Xoroshiro128++                         |
//! | [`noise`]   | improved Perlin + octaves                                             |
//! | [`block`]   | compact block registry (flags, light, hardness, textures)             |
//! | [`chunk`]   | 16³ sections, heightmaps, vanilla paletted-container serialisation    |
//! | [`world`]   | sparse chunk map with FxHash                                          |
//! | [`worldgen`]| deterministic noise terrain, ores, trees                              |
//! | [`lighting`]| sky + block light BFS                                                 |
//! | [`mesher`]  | greedy meshing with AO, opaque / translucent layers                   |
//! | [`manager`] | threaded generate → light → mesh pipeline with streaming              |
//! | [`physics`] | vanilla player movement + collision + step-up + sneak edge            |
//! | [`raycast`] | DDA block picking                                                     |
//! | [`tick`]    | 20 TPS fixed-step clock + frame statistics                            |
//! | [`protocol`]| VarInt/VarLong, framing, handshake, status ping                       |

#![forbid(unsafe_code)]
#![warn(rust_2018_idioms)]

pub mod block;
pub mod chunk;
pub mod lighting;
pub mod manager;
pub mod math;
pub mod mesher;
pub mod noise;
pub mod physics;
pub mod protocol;
pub mod raycast;
pub mod rng;
pub mod tick;
pub mod world;
pub mod worldgen;

pub mod prelude {
    pub use crate::block::BlockId;
    pub use crate::chunk::{Chunk, HeightmapKind, Section};
    pub use crate::manager::ChunkManager;
    pub use crate::math::{Aabb, BlockPos, ChunkPos, Face, Vec3};
    pub use crate::mesher::{ChunkMesh, MeshInput, Vertex};
    pub use crate::physics::{Input, Player};
    pub use crate::protocol::{DATA_VERSION, PROTOCOL_VERSION, VERSION_NAME};
    pub use crate::tick::{FrameStats, TickClock};
    pub use crate::world::World;
    pub use crate::worldgen::WorldGenerator;
}

/// Minecraft version this core targets.
pub const TARGET_VERSION: &str = protocol::VERSION_NAME;
