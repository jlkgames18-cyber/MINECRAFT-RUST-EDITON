//! Greedy mesher.
//!
//! Works on a padded 18³ snapshot of a 16³ section so a mesh job needs no access to the world
//! (perfect for worker threads). Hidden faces are culled, coplanar faces of the same block and
//! the same ambient-occlusion signature are merged into large quads, and vertices are packed
//! into 10 bytes.

use crate::block::{flags, BlockId};
use crate::math::{ChunkPos, MIN_Y, SECTION_COUNT};
use crate::world::World;

const P: usize = 18;
const PADDED_VOLUME: usize = P * P * P;

/// 10 byte vertex: position/uv are in block units (0..=16) so they fit a `u8`.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Vertex {
    pub pos: [u8; 3],
    pub face: u8,
    pub uv: [u8; 2],
    pub ao: u8,
    pub _pad: u8,
    pub tex: u16,
}

#[derive(Default, Clone, Debug)]
pub struct MeshData {
    pub vertices: Vec<Vertex>,
    pub indices: Vec<u32>,
}

impl MeshData {
    pub fn quad_count(&self) -> usize {
        self.indices.len() / 6
    }
    pub fn is_empty(&self) -> bool {
        self.indices.is_empty()
    }
    pub fn bytes(&self) -> usize {
        self.vertices.len() * std::mem::size_of::<Vertex>() + self.indices.len() * 4
    }
}

#[derive(Default, Clone, Debug)]
pub struct ChunkMesh {
    pub opaque: MeshData,
    pub translucent: MeshData,
}

impl ChunkMesh {
    pub fn is_empty(&self) -> bool {
        self.opaque.is_empty() && self.translucent.is_empty()
    }
    pub fn quad_count(&self) -> usize {
        self.opaque.quad_count() + self.translucent.quad_count()
    }
}

/// Padded copy of a section and its 1-block border.
pub struct MeshInput {
    blocks: Box<[u16; PADDED_VOLUME]>,
    pub any_solid: bool,
}

#[inline(always)]
fn pidx(x: i32, y: i32, z: i32) -> usize {
    (((y + 1) as usize) * P + (z + 1) as usize) * P + (x + 1) as usize
}

impl MeshInput {
    pub fn empty() -> Self {
        Self { blocks: Box::new([0; PADDED_VOLUME]), any_solid: false }
    }

    /// Snapshots section `sy` (0..24) of chunk `pos` from `world`.
    pub fn from_world(world: &World, pos: ChunkPos, sy: usize) -> Self {
        let mut me = Self::empty();
        let base_y = MIN_Y + (sy as i32) * 16;
        let bx = pos.min_block_x();
        let bz = pos.min_block_z();
        let mut any = false;
        for pz in 0..P as i32 {
            for px in 0..P as i32 {
                let wx = bx + px - 1;
                let wz = bz + pz - 1;
                let Some(chunk) = world.chunk(ChunkPos::new(wx >> 4, wz >> 4)) else { continue };
                let (lx, lz) = ((wx & 15) as usize, (wz & 15) as usize);
                for py in 0..P as i32 {
                    let wy = base_y + py - 1;
                    let id = chunk.get_block(lx, wy, lz);
                    me.blocks[((py as usize) * P + pz as usize) * P + px as usize] = id.0;
                    if (1..17).contains(&px) && (1..17).contains(&pz) && (1..17).contains(&py) && !id.is_air() {
                        any = true;
                    }
                }
            }
        }
        me.any_solid = any;
        me
    }

    #[inline(always)]
    pub fn get(&self, x: i32, y: i32, z: i32) -> BlockId {
        BlockId(self.blocks[pidx(x, y, z)])
    }

    /// Test helper / custom producers: writes in section-local coordinates (-1..=16).
    pub fn set(&mut self, x: i32, y: i32, z: i32, id: BlockId) {
        self.blocks[pidx(x, y, z)] = id.0;
        if (0..16).contains(&x) && (0..16).contains(&y) && (0..16).contains(&z) && !id.is_air() {
            self.any_solid = true;
        }
    }

    #[inline(always)]
    fn opaque(&self, p: [i32; 3]) -> bool {
        self.get(p[0], p[1], p[2]).is_opaque()
    }
}

#[inline(always)]
fn ao_value(s1: bool, s2: bool, c: bool) -> u8 {
    if s1 && s2 {
        0
    } else {
        3 - (s1 as u8 + s2 as u8 + c as u8)
    }
}

/// AO for the 4 corners of the face cell in the order (0,0),(1,0),(1,1),(0,1) in (u,v).
fn ao_corners(input: &MeshInput, n: [i32; 3], ua: usize, va: usize) -> [u8; 4] {
    let corner = |su: i32, sv: i32| -> u8 {
        let mut a = n;
        a[ua] += su;
        let mut b = n;
        b[va] += sv;
        let mut c = n;
        c[ua] += su;
        c[va] += sv;
        ao_value(input.opaque(a), input.opaque(b), input.opaque(c))
    };
    [corner(-1, -1), corner(1, -1), corner(1, 1), corner(-1, 1)]
}

#[inline(always)]
fn pack_key(id: u16, ao: [u8; 4]) -> u32 {
    (1 << 24) | ((ao[0] | ao[1] << 2 | ao[2] << 4 | ao[3] << 6) as u32) << 16 | id as u32
}

#[inline(always)]
fn key_ao(key: u32) -> [u8; 4] {
    let a = ((key >> 16) & 0xFF) as u8;
    [a & 3, (a >> 2) & 3, (a >> 4) & 3, (a >> 6) & 3]
}

#[inline(always)]
fn key_uniform(key: u32) -> bool {
    let a = key_ao(key);
    a[0] == a[1] && a[1] == a[2] && a[2] == a[3]
}

fn face_index(axis: usize, dir: i32) -> u8 {
    match (axis, dir > 0) {
        (0, true) => 5,  // East  +X
        (0, false) => 4, // West  -X
        (1, true) => 1,  // Up
        (1, false) => 0, // Down
        (2, true) => 3,  // South +Z
        _ => 2,          // North -Z
    }
}

pub fn mesh_section(input: &MeshInput) -> ChunkMesh {
    let mut mesh = ChunkMesh::default();
    if !input.any_solid {
        return mesh;
    }
    let mut mask = [0u32; 256];

    for axis in 0..3usize {
        let ua = (axis + 1) % 3;
        let va = (axis + 2) % 3;
        for &dir in &[-1i32, 1] {
            let face = face_index(axis, dir);
            for slice in 0..16i32 {
                // ---- build the visibility mask for this slice --------------------------------
                let mut any = false;
                for v in 0..16i32 {
                    for u in 0..16i32 {
                        let mut p = [0i32; 3];
                        p[axis] = slice;
                        p[ua] = u;
                        p[va] = v;
                        let cur = input.get(p[0], p[1], p[2]);
                        let cell = &mut mask[(v * 16 + u) as usize];
                        *cell = 0;
                        if cur.is_air() {
                            continue;
                        }
                        let mut n = p;
                        n[axis] += dir;
                        let nb = input.get(n[0], n[1], n[2]);
                        if nb.is_opaque() || (nb == cur && cur.flags() & flags::CULL_SAME != 0) {
                            continue;
                        }
                        let ao = if cur.is_liquid() { [3; 4] } else { ao_corners(input, n, ua, va) };
                        *cell = pack_key(cur.0, ao);
                        any = true;
                    }
                }
                if !any {
                    continue;
                }

                // ---- greedy merge ----------------------------------------------------------
                for v in 0..16usize {
                    let mut u = 0usize;
                    while u < 16 {
                        let key = mask[v * 16 + u];
                        if key == 0 {
                            u += 1;
                            continue;
                        }
                        let mergeable = key_uniform(key);
                        let mut w = 1usize;
                        let mut h = 1usize;
                        if mergeable {
                            while u + w < 16 && mask[v * 16 + u + w] == key {
                                w += 1;
                            }
                            'grow: while v + h < 16 {
                                for k in 0..w {
                                    if mask[(v + h) * 16 + u + k] != key {
                                        break 'grow;
                                    }
                                }
                                h += 1;
                            }
                        }
                        for dv in 0..h {
                            for du in 0..w {
                                mask[(v + dv) * 16 + u + du] = 0;
                            }
                        }
                        emit_quad(&mut mesh, key, face, axis, dir, slice as usize, u, v, w, h);
                        u += w;
                    }
                }
            }
        }
    }
    mesh
}

#[allow(clippy::too_many_arguments)]
fn emit_quad(mesh: &mut ChunkMesh, key: u32, face: u8, axis: usize, dir: i32, slice: usize, u: usize, v: usize, w: usize, h: usize) {
    let id = BlockId((key & 0xFFFF) as u16);
    let ao = key_ao(key);
    let ua = (axis + 1) % 3;
    let va = (axis + 2) % 3;
    let layer = if id.flags() & flags::TRANSLUCENT != 0 { &mut mesh.translucent } else { &mut mesh.opaque };

    let plane = (slice + usize::from(dir > 0)) as u8;
    let corners: [(usize, usize); 4] = [(u, v), (u + w, v), (u + w, v + h), (u, v + h)];
    let uvs: [(u8, u8); 4] = [(0, 0), (w as u8, 0), (w as u8, h as u8), (0, h as u8)];
    let order: [usize; 4] = if dir > 0 { [0, 1, 2, 3] } else { [0, 3, 2, 1] };
    let tex = id.texture_for_face(face);
    let swap_uv = axis == 0; // X faces: u axis is world Y, textures need V along Y

    let base = layer.vertices.len() as u32;
    for &c in &order {
        let mut pos = [0u8; 3];
        pos[axis] = plane;
        pos[ua] = corners[c].0 as u8;
        pos[va] = corners[c].1 as u8;
        let (tu, tv) = uvs[c];
        let uv = if swap_uv { [tv, tu] } else { [tu, tv] };
        layer.vertices.push(Vertex { pos, face, uv, ao: ao[c], _pad: 0, tex });
    }

    // choose the diagonal that avoids AO interpolation artefacts
    let a = |i: usize| ao[order[i]] as u32;
    if a(0) + a(2) >= a(1) + a(3) {
        layer.indices.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
    } else {
        layer.indices.extend_from_slice(&[base + 1, base + 2, base + 3, base + 1, base + 3, base]);
    }
}

/// Meshes every non-empty section of a chunk (convenience for tools/benchmarks).
pub fn mesh_chunk(world: &World, pos: ChunkPos) -> Vec<(usize, ChunkMesh)> {
    let Some(chunk) = world.chunk(pos) else { return Vec::new() };
    let mut out = Vec::new();
    for sy in 0..SECTION_COUNT {
        if chunk.sections[sy].is_empty() {
            continue;
        }
        let m = mesh_section(&MeshInput::from_world(world, pos, sy));
        if !m.is_empty() {
            out.push((sy, m));
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::Chunk;

    #[test]
    fn single_block_has_six_faces() {
        let mut i = MeshInput::empty();
        i.set(5, 5, 5, BlockId::STONE);
        let m = mesh_section(&i);
        assert_eq!(m.opaque.quad_count(), 6);
        assert_eq!(m.opaque.vertices.len(), 24);
    }

    #[test]
    fn adjacent_blocks_merge_and_cull() {
        let mut i = MeshInput::empty();
        i.set(5, 5, 5, BlockId::STONE);
        i.set(6, 5, 5, BlockId::STONE);
        let m = mesh_section(&i);
        assert_eq!(m.opaque.quad_count(), 6, "2x1x1 box must be 6 merged quads");
    }

    #[test]
    fn full_layer_is_six_quads() {
        let mut i = MeshInput::empty();
        for x in 0..16 {
            for z in 0..16 {
                i.set(x, 0, z, BlockId::STONE);
            }
        }
        assert_eq!(mesh_section(&i).opaque.quad_count(), 6);
    }

    #[test]
    fn glass_goes_to_translucent_and_culls_itself() {
        let mut i = MeshInput::empty();
        i.set(1, 1, 1, BlockId::GLASS);
        i.set(2, 1, 1, BlockId::GLASS);
        let m = mesh_section(&i);
        assert!(m.opaque.is_empty());
        assert_eq!(m.translucent.quad_count(), 6);
    }

    #[test]
    fn opaque_neighbour_hides_face_of_translucent_side() {
        let mut i = MeshInput::empty();
        i.set(1, 1, 1, BlockId::STONE);
        i.set(2, 1, 1, BlockId::GLASS);
        let m = mesh_section(&i);
        assert_eq!(m.opaque.quad_count(), 6); // stone shows its face towards glass
        assert_eq!(m.translucent.quad_count(), 5); // glass hides the face touching stone
    }

    #[test]
    fn triangles_face_outwards() {
        let mut i = MeshInput::empty();
        i.set(8, 8, 8, BlockId::STONE);
        let m = mesh_section(&i);
        let c = [8.5f32, 8.5, 8.5];
        for t in m.opaque.indices.chunks(3) {
            let v: Vec<[f32; 3]> =
                t.iter().map(|&k| m.opaque.vertices[k as usize].pos.map(|p| p as f32)).collect();
            let e1 = [v[1][0] - v[0][0], v[1][1] - v[0][1], v[1][2] - v[0][2]];
            let e2 = [v[2][0] - v[0][0], v[2][1] - v[0][1], v[2][2] - v[0][2]];
            let n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]];
            let to_face = [v[0][0] - c[0], v[0][1] - c[1], v[0][2] - c[2]];
            let dot = n[0] * to_face[0] + n[1] * to_face[1] + n[2] * to_face[2];
            assert!(dot > 0.0, "inward facing triangle");
        }
    }

    #[test]
    fn ao_darkens_inner_corner() {
        let mut i = MeshInput::empty();
        i.set(5, 5, 5, BlockId::STONE);
        i.set(6, 6, 5, BlockId::STONE); // sits diagonally above -> darkens the top face corner
        let m = mesh_section(&i);
        assert!(m.opaque.vertices.iter().any(|v| v.ao < 3));
    }

    #[test]
    fn world_snapshot_sees_neighbour_chunks() {
        let mut w = World::new(0);
        for cx in 0..2 {
            w.insert_chunk(Chunk::new(ChunkPos::new(cx, 0)));
        }
        w.set_block(15, 0, 3, BlockId::STONE);
        w.set_block(16, 0, 3, BlockId::STONE);
        let sy = ((0 - MIN_Y) / 16) as usize;
        let a = mesh_section(&MeshInput::from_world(&w, ChunkPos::new(0, 0), sy));
        // The +X face of the edge block must be culled by the neighbour chunk's block.
        assert_eq!(a.opaque.quad_count(), 5);
    }
}
