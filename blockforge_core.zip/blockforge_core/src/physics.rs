//! Player movement and collision using vanilla constants.
//!
//! Constants (per tick, 20 TPS): gravity 0.08, vertical drag 0.98, jump velocity 0.42,
//! default block friction 0.6 (horizontal drag = friction * 0.91), base movement speed 0.1,
//! sprint multiplier 1.3, air acceleration 0.02, step height 0.6, hitbox 0.6 x 1.8,
//! eye height 1.62 (sneaking 1.27 / hitbox 1.5).

use crate::math::{floor, Aabb, Vec3};
use crate::world::World;

pub const GRAVITY: f64 = 0.08;
pub const VERTICAL_DRAG: f64 = 0.98;
pub const AIR_DRAG: f64 = 0.91;
pub const JUMP_POWER: f64 = 0.42;
pub const DEFAULT_FRICTION: f64 = 0.6;
pub const BASE_SPEED: f64 = 0.1;
pub const SPRINT_MULTIPLIER: f64 = 1.3;
pub const SNEAK_MULTIPLIER: f64 = 0.3;
pub const AIR_ACCELERATION: f64 = 0.02;
pub const STEP_HEIGHT: f64 = 0.6;
pub const PLAYER_WIDTH: f64 = 0.6;
pub const PLAYER_HEIGHT: f64 = 1.8;
pub const PLAYER_SNEAK_HEIGHT: f64 = 1.5;
pub const EYE_HEIGHT: f64 = 1.62;
pub const SNEAK_EYE_HEIGHT: f64 = 1.27;
pub const TERMINAL_HINT: f64 = 3.92; // ≈ terminal velocity in blocks/tick (not clamped by vanilla)

#[derive(Clone, Copy, Debug, Default)]
pub struct Input {
    pub forward: f32, // +1 W, -1 S
    pub strafe: f32,  // +1 A (left), -1 D (right)
    pub jump: bool,
    pub sneak: bool,
    pub sprint: bool,
}

#[derive(Clone, Debug)]
pub struct Player {
    pub pos: Vec3,
    pub prev_pos: Vec3,
    pub vel: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub on_ground: bool,
    pub horizontal_collision: bool,
    pub sneaking: bool,
    pub sprinting: bool,
    pub in_water: bool,
    pub fall_distance: f64,
    jump_delay: u8,
}

impl Player {
    pub fn new(pos: Vec3) -> Self {
        Self {
            pos,
            prev_pos: pos,
            vel: Vec3::ZERO,
            yaw: 0.0,
            pitch: 0.0,
            on_ground: false,
            horizontal_collision: false,
            sneaking: false,
            sprinting: false,
            in_water: false,
            fall_distance: 0.0,
            jump_delay: 0,
        }
    }

    pub fn height(&self) -> f64 {
        if self.sneaking {
            PLAYER_SNEAK_HEIGHT
        } else {
            PLAYER_HEIGHT
        }
    }
    pub fn bounding_box(&self) -> Aabb {
        Aabb::from_feet(self.pos, PLAYER_WIDTH, self.height())
    }
    pub fn eye_position(&self) -> Vec3 {
        let e = if self.sneaking { SNEAK_EYE_HEIGHT } else { EYE_HEIGHT };
        Vec3::new(self.pos.x, self.pos.y + e, self.pos.z)
    }
    pub fn look_vector(&self) -> Vec3 {
        Vec3::from_rotation(self.pitch, self.yaw)
    }
    /// Smooth position for rendering between two ticks.
    pub fn lerp_pos(&self, partial: f64) -> Vec3 {
        self.prev_pos + (self.pos - self.prev_pos) * partial
    }

    /// Advance one 50 ms tick.
    pub fn tick(&mut self, world: &World, input: Input) {
        self.prev_pos = self.pos;
        self.sneaking = input.sneak;
        self.sprinting = input.sprint && input.forward > 0.0 && !input.sneak;
        self.in_water = water_at(world, self.pos, self.height());

        // vanilla zeroes tiny residual velocities
        if self.vel.x.abs() < 0.003 { self.vel.x = 0.0 }
        if self.vel.y.abs() < 0.003 { self.vel.y = 0.0 }
        if self.vel.z.abs() < 0.003 { self.vel.z = 0.0 }

        if self.jump_delay > 0 {
            self.jump_delay -= 1;
        }

        if input.jump {
            if self.in_water {
                self.vel.y += 0.04;
            } else if self.on_ground && self.jump_delay == 0 {
                self.vel.y = JUMP_POWER;
                if self.sprinting {
                    let r = (self.yaw as f64).to_radians();
                    self.vel.x -= r.sin() * 0.2;
                    self.vel.z += r.cos() * 0.2;
                }
                self.jump_delay = 10;
            }
        } else {
            self.jump_delay = 0;
        }

        // input vector (vanilla: 0.98 factor, normalised when longer than 1)
        let mut fwd = input.forward as f64 * 0.98;
        let mut str_ = input.strafe as f64 * 0.98;
        if input.sneak {
            fwd *= SNEAK_MULTIPLIER;
            str_ *= SNEAK_MULTIPLIER;
        }
        let friction = if self.on_ground { block_friction_below(world, self.pos) } else { 1.0 };
        let drag_h = friction * AIR_DRAG;

        let speed = if self.in_water {
            0.02
        } else if self.on_ground {
            let base = BASE_SPEED * if self.sprinting { SPRINT_MULTIPLIER } else { 1.0 };
            base * (0.216_000_02 / (friction * friction * friction))
        } else {
            AIR_ACCELERATION * if self.sprinting { SPRINT_MULTIPLIER } else { 1.0 }
        };
        self.move_relative(speed, fwd, str_);

        let intended = self.vel;
        let moved = self.move_with_collision(world, intended);
        if (intended.y - moved.y).abs() > 1e-12 {
            if intended.y < 0.0 {
                self.on_ground = true;
            }
            self.vel.y = 0.0;
        } else {
            self.on_ground = false;
        }
        if intended.y < 0.0 && !self.on_ground {
            self.fall_distance -= moved.y;
        }
        if self.on_ground {
            self.fall_distance = 0.0;
        }
        if (intended.x - moved.x).abs() > 1e-12 {
            self.vel.x = 0.0;
        }
        if (intended.z - moved.z).abs() > 1e-12 {
            self.vel.z = 0.0;
        }

        if self.in_water {
            self.vel.x *= 0.8;
            self.vel.z *= 0.8;
            self.vel.y = self.vel.y * 0.8 - 0.02;
        } else {
            self.vel.y = (self.vel.y - GRAVITY) * VERTICAL_DRAG;
            self.vel.x *= drag_h;
            self.vel.z *= drag_h;
        }
    }

    fn move_relative(&mut self, speed: f64, forward: f64, strafe: f64) {
        let mut v = Vec3::new(strafe, 0.0, forward);
        let len2 = v.length_sqr();
        if len2 < 1.0e-7 {
            return;
        }
        if len2 > 1.0 {
            v = v.normalize();
        }
        v = v * speed;
        let r = (self.yaw as f64).to_radians();
        let (s, c) = r.sin_cos();
        self.vel.x += v.x * c - v.z * s;
        self.vel.z += v.z * c + v.x * s;
    }

    /// Applies `delta` with collisions (and step-up). Returns the actual movement.
    fn move_with_collision(&mut self, world: &World, delta: Vec3) -> Vec3 {
        let bb = self.bounding_box();
        let mut actual = collide(world, &bb, delta);

        let h_collide = (delta.x - actual.x).abs() > 1e-12 || (delta.z - actual.z).abs() > 1e-12;
        self.horizontal_collision = h_collide;
        let falling_or_ground = self.on_ground || (delta.y < 0.0 && actual.y != delta.y);
        if h_collide && falling_or_ground {
            let up = collide(world, &bb, Vec3::new(delta.x, STEP_HEIGHT, delta.z));
            let lift = collide(world, &bb.expand_towards(Vec3::new(delta.x, 0.0, delta.z)), Vec3::new(0.0, STEP_HEIGHT, 0.0));
            let mut stepped = up;
            if lift.y < STEP_HEIGHT {
                let moved_box = bb.offset(lift);
                let h = collide(world, &moved_box, Vec3::new(delta.x, 0.0, delta.z)) + lift;
                if h.horizontal_distance_sqr() > stepped.horizontal_distance_sqr() {
                    stepped = h;
                }
            }
            if stepped.horizontal_distance_sqr() > actual.horizontal_distance_sqr() {
                let after = bb.offset(stepped);
                let down = collide(world, &after, Vec3::new(0.0, -stepped.y + delta.y, 0.0));
                actual = stepped + down;
            }
        }

        // sneaking never walks off an edge while grounded
        if self.sneaking && self.on_ground {
            actual = self.clamp_to_edge(world, actual);
        }

        self.pos += actual;
        actual
    }

    fn clamp_to_edge(&self, world: &World, mut m: Vec3) -> Vec3 {
        let bb = self.bounding_box();
        let step = 0.05;
        let no_ground = |dx: f64, dz: f64| {
            let b = bb.offset(Vec3::new(dx, -STEP_HEIGHT, dz));
            collide_boxes(world, &b).is_empty()
        };
        while m.x != 0.0 && no_ground(m.x, 0.0) {
            m.x = if m.x.abs() <= step { 0.0 } else { m.x - step * m.x.signum() };
        }
        while m.z != 0.0 && no_ground(0.0, m.z) {
            m.z = if m.z.abs() <= step { 0.0 } else { m.z - step * m.z.signum() };
        }
        while m.x != 0.0 && m.z != 0.0 && no_ground(m.x, m.z) {
            m.x = if m.x.abs() <= step { 0.0 } else { m.x - step * m.x.signum() };
            m.z = if m.z.abs() <= step { 0.0 } else { m.z - step * m.z.signum() };
        }
        m
    }
}

fn water_at(world: &World, pos: Vec3, height: f64) -> bool {
    let y = floor(pos.y + height * 0.5);
    world.get_block(floor(pos.x), y, floor(pos.z)).is_liquid()
}

fn block_friction_below(world: &World, pos: Vec3) -> f64 {
    let b = world.get_block(floor(pos.x), floor(pos.y - 0.500_001), floor(pos.z));
    b.info().friction as f64
}

/// Collision boxes of all solid blocks that intersect `area`.
fn collide_boxes(world: &World, area: &Aabb) -> Vec<Aabb> {
    let mut out = Vec::new();
    let (x0, x1) = (floor(area.min.x - 1.0e-7), floor(area.max.x + 1.0e-7));
    let (y0, y1) = (floor(area.min.y - 1.0e-7), floor(area.max.y + 1.0e-7));
    let (z0, z1) = (floor(area.min.z - 1.0e-7), floor(area.max.z + 1.0e-7));
    for x in x0..=x1 {
        for y in y0..=y1 {
            for z in z0..=z1 {
                if world.is_solid_for_collision(x, y, z) {
                    out.push(Aabb::unit_block(x, y, z));
                }
            }
        }
    }
    out
}

/// Resolves motion `d` for box `bb` against the world. Axis order = vanilla:
/// Y first, then the longer of X/Z first.
pub fn collide(world: &World, bb: &Aabb, d: Vec3) -> Vec3 {
    let area = bb.expand_towards(d);
    let boxes = collide_boxes(world, &area);
    let mut cur = *bb;
    let mut r = Vec3::ZERO;

    let mut dy = d.y;
    for b in &boxes {
        dy = b.collide_y(&cur, dy);
    }
    cur = cur.offset(Vec3::new(0.0, dy, 0.0));
    r.y = dy;

    let x_first = d.x.abs() >= d.z.abs();
    let mut dx = d.x;
    let mut dz = d.z;
    if x_first {
        for b in &boxes {
            dx = b.collide_x(&cur, dx);
        }
        cur = cur.offset(Vec3::new(dx, 0.0, 0.0));
        for b in &boxes {
            dz = b.collide_z(&cur, dz);
        }
    } else {
        for b in &boxes {
            dz = b.collide_z(&cur, dz);
        }
        cur = cur.offset(Vec3::new(0.0, 0.0, dz));
        for b in &boxes {
            dx = b.collide_x(&cur, dx);
        }
    }
    r.x = dx;
    r.z = dz;
    r
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::block::BlockId;
    use crate::chunk::Chunk;
    use crate::math::ChunkPos;

    fn flat_world() -> World {
        let mut w = World::new(0);
        for cx in -2..=2 {
            for cz in -2..=2 {
                let mut c = Chunk::new(ChunkPos::new(cx, cz));
                for x in 0..16 {
                    for z in 0..16 {
                        for y in -64..=63 {
                            c.set_block(x, y, z, BlockId::STONE);
                        }
                    }
                }
                w.insert_chunk(c);
            }
        }
        w
    }

    fn settle(p: &mut Player, w: &World) {
        for _ in 0..60 {
            p.tick(w, Input::default());
        }
    }

    #[test]
    fn falls_and_lands_on_ground() {
        let w = flat_world();
        let mut p = Player::new(Vec3::new(0.5, 80.0, 0.5));
        settle(&mut p, &w);
        assert!(p.on_ground);
        assert!((p.pos.y - 64.0).abs() < 1e-6, "y = {}", p.pos.y);
    }

    #[test]
    fn jump_reaches_vanilla_height() {
        let w = flat_world();
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        settle(&mut p, &w);
        let mut max_y = p.pos.y;
        p.tick(&w, Input { jump: true, ..Default::default() });
        for _ in 0..30 {
            max_y = max_y.max(p.pos.y);
            p.tick(&w, Input::default());
        }
        let h = max_y - 64.0;
        // vanilla jump height is ≈1.2522 blocks
        assert!((h - 1.2522).abs() < 0.01, "jump height {h}");
    }

    #[test]
    fn walking_speed_matches_vanilla() {
        let w = flat_world();
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        settle(&mut p, &w);
        let start = p.pos;
        for _ in 0..20 {
            p.tick(&w, Input { forward: 1.0, ..Default::default() });
        }
        let dist = (p.pos - start).length();
        // walking ≈ 4.317 blocks/s (accelerating from rest, so slightly less over 1s)
        assert!(dist > 3.5 && dist < 4.4, "walked {dist} blocks/s");
    }

    #[test]
    fn sprinting_is_faster_than_walking() {
        let w = flat_world();
        let run = |sprint: bool| {
            let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
            settle(&mut p, &w);
            let s = p.pos;
            for _ in 0..40 {
                p.tick(&w, Input { forward: 1.0, sprint, ..Default::default() });
            }
            (p.pos - s).length()
        };
        assert!(run(true) > run(false) * 1.2);
    }

    #[test]
    fn wall_blocks_movement() {
        let mut w = flat_world();
        for y in 64..=66 {
            w.set_block(3, y, 0, BlockId::STONE);
        }
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        p.yaw = -90.0; // face +X
        settle(&mut p, &w);
        for _ in 0..80 {
            p.tick(&w, Input { forward: 1.0, ..Default::default() });
        }
        assert!(p.pos.x < 3.0 - 0.3 + 1e-6, "x = {}", p.pos.x);
    }

    #[test]
    fn auto_step_up_half_height() {
        let mut w = flat_world();
        // a 0.6 reachable step doesn't exist with full cubes, so verify we CAN'T climb 1 block
        for z in -2..=2 {
            w.set_block(3, 64, z, BlockId::STONE);
        }
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        p.yaw = -90.0;
        settle(&mut p, &w);
        for _ in 0..60 {
            p.tick(&w, Input { forward: 1.0, ..Default::default() });
        }
        assert!(p.pos.x < 2.8, "should be blocked by 1-block ledge, x = {}", p.pos.x);
        assert!((p.pos.y - 64.0).abs() < 1e-6);
    }

    #[test]
    fn can_jump_up_one_block() {
        let mut w = flat_world();
        for x in 3..=12 {
            for z in -2..=2 {
                w.set_block(x, 64, z, BlockId::STONE);
            }
        }
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        p.yaw = -90.0;
        settle(&mut p, &w);
        for _ in 0..60 {
            p.tick(&w, Input { forward: 1.0, jump: true, ..Default::default() });
        }
        settle(&mut p, &w); // stop moving and let the player land
        assert!(p.pos.x > 3.5, "x = {}", p.pos.x);
        assert!((p.pos.y - 65.0).abs() < 1e-6, "y = {}", p.pos.y);
    }

    #[test]
    fn sneaking_does_not_fall_off_edge() {
        let mut w = flat_world();
        for y in 60..=63 {
            for x in 2..=10 {
                for z in -3..=3 {
                    w.set_block(x, y, z, BlockId::AIR);
                }
            }
        }
        // platform at x<=1
        let mut p = Player::new(Vec3::new(0.5, 64.0, 0.5));
        p.yaw = -90.0;
        settle(&mut p, &w);
        for _ in 0..80 {
            p.tick(&w, Input { forward: 1.0, sneak: true, ..Default::default() });
        }
        assert!(p.on_ground);
        assert!(p.pos.x < 2.5, "x = {}", p.pos.x);
    }
}
