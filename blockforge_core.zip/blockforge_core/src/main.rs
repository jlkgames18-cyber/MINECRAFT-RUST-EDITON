//! Headless benchmark / self-check for the core.
//!
//! ```text
//! cargo run --release -- [--view N] [--seed S] [--threads T]
//! ```

use blockforge_core::chunk::HeightmapKind;
use blockforge_core::mesher::{mesh_section, MeshInput};
use blockforge_core::prelude::*;
use blockforge_core::raycast::raycast_solid;
use std::time::Instant;

fn arg<T: std::str::FromStr>(name: &str, default: T) -> T {
    let args: Vec<String> = std::env::args().collect();
    args.iter()
        .position(|a| a == name)
        .and_then(|i| args.get(i + 1))
        .and_then(|v| v.parse().ok())
        .unwrap_or(default)
}

fn main() {
    let view: i32 = arg("--view", 8);
    let seed: i64 = arg("--seed", 1_234_567);
    let threads: usize = arg(
        "--threads",
        std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2),
    );

    println!("BlockForge Core  |  target Minecraft Java {VERSION_NAME}  (protocol {PROTOCOL_VERSION}, data {DATA_VERSION})");
    println!("seed={seed} view_distance={view} threads={threads}\n");

    // ---- 1. single threaded terrain generation ------------------------------------------
    let gen = WorldGenerator::new(seed);
    let t = Instant::now();
    let n = 64;
    let mut sink = 0u64;
    for i in 0..n {
        let c = gen.generate_chunk(ChunkPos::new(i % 8, i / 8));
        sink += c.height_at(0, 0, HeightmapKind::WorldSurface) as u64;
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[worldgen ] {n} chunks in {:.1} ms  -> {:.1} chunks/s/thread  (sink {sink})", dt * 1e3, n as f64 / dt);

    // ---- 2. meshing throughput ----------------------------------------------------------
    let mut w = World::new(seed);
    for cx in -1..=8 {
        for cz in -1..=8 {
            w.insert_chunk(gen.generate_chunk(ChunkPos::new(cx, cz)));
        }
    }
    let t = Instant::now();
    let mut sections = 0u64;
    let mut quads = 0u64;
    for cx in 0..8 {
        for cz in 0..8 {
            let chunk = w.chunk(ChunkPos::new(cx, cz)).unwrap();
            for sy in 0..24 {
                if chunk.sections[sy].is_empty() {
                    continue;
                }
                let input = MeshInput::from_world(&w, ChunkPos::new(cx, cz), sy);
                let m = mesh_section(&input);
                quads += m.quad_count() as u64;
                sections += 1;
            }
        }
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[mesher   ] {sections} sections in {:.1} ms -> {:.0} sections/s/thread, {quads} quads", dt * 1e3, sections as f64 / dt);

    // ---- 3. full threaded streaming pipeline --------------------------------------------
    let mut mgr = ChunkManager::new(seed, threads);
    let t = Instant::now();
    loop {
        mgr.update(ChunkPos::new(0, 0), view);
        if mgr.is_idle() {
            break;
        }
        std::thread::sleep(std::time::Duration::from_micros(200));
    }
    let dt = t.elapsed().as_secs_f64();
    println!(
        "[pipeline ] {} chunks, {} sections, {} quads in {:.2} s  -> {:.0} chunks/s",
        mgr.world.loaded_count(),
        mgr.stats.sections_meshed,
        mgr.stats.quads,
        dt,
        mgr.stats.chunks_generated as f64 / dt
    );
    println!(
        "[memory   ] world {:.1} MiB, meshes {:.1} MiB",
        mgr.world.heap_bytes() as f64 / 1_048_576.0,
        mgr.mesh_bytes() as f64 / 1_048_576.0
    );

    // ---- 4. physics + raycast -----------------------------------------------------------
    let sx = 8;
    let sz = 8;
    let h = mgr.world.height_at(sx, sz, HeightmapKind::MotionBlocking).unwrap_or(80);
    let mut p = Player::new(Vec3::new(sx as f64 + 0.5, h as f64 + 2.0, sz as f64 + 0.5));
    let t = Instant::now();
    let ticks = 200_000;
    for i in 0..ticks {
        p.yaw = (i % 360) as f32;
        p.tick(&mgr.world, Input { forward: 1.0, jump: i % 40 == 0, sprint: true, ..Default::default() });
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[physics  ] {ticks} player ticks in {:.1} ms -> {:.2} M ticks/s (final pos {:.1}, {:.1}, {:.1})",
        dt * 1e3, ticks as f64 / dt / 1e6, p.pos.x, p.pos.y, p.pos.z);

    let t = Instant::now();
    let rays = 1_000_000;
    let mut hits = 0u32;
    let o = Vec3::new(8.5, h as f64 + 10.0, 8.5);
    for i in 0..rays {
        let a = i as f32 * 0.001;
        if raycast_solid(&mgr.world, o, Vec3::from_rotation(20.0 + (i % 60) as f32, a * 57.0), 4.5 * 4.0).is_some() {
            hits += 1;
        }
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[raycast  ] {rays} rays in {:.1} ms -> {:.2} M rays/s ({hits} hits)", dt * 1e3, rays as f64 / dt / 1e6);

    // ---- 5. network serialisation -------------------------------------------------------
    let t = Instant::now();
    let mut bytes = 0usize;
    let mut count = 0;
    for pos in mgr.world.loaded_positions().take(100) {
        let mut b = PacketBuf::with_capacity(32 * 1024);
        mgr.world.chunk(pos).unwrap().write_sections(&mut b);
        bytes += b.len();
        count += 1;
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[network  ] {count} chunks serialised: {:.1} KiB avg, {:.0} chunks/s", bytes as f64 / count as f64 / 1024.0, count as f64 / dt);

    // ---- 6. tick clock ------------------------------------------------------------------
    let mut clock = TickClock::new(Instant::now());
    std::thread::sleep(std::time::Duration::from_millis(260));
    let (n, partial) = clock.advance(Instant::now());
    println!("[tick     ] 260 ms -> {n} ticks, partial {partial:.2} (expected 5)");
    println!("\nOK");
}

use blockforge_core::protocol::PacketBuf;
