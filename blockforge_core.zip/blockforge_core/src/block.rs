//! Compact block registry.
//!
//! Block states are `u16` ids that index a `const` table, so every property lookup in the hot
//! paths (meshing, collision, lighting) is a single array load with no hashing and no
//! allocation. The table can be regenerated from the official data generator
//! (`java -DbundlerMainClass=net.minecraft.data.Main -jar server.jar --reports`) –
//! `tools/` hooks are described in the README.

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, Default, PartialOrd, Ord)]
pub struct BlockId(pub u16);

pub mod flags {
    pub const SOLID: u8 = 1 << 0; // has a full-cube collision box
    pub const OPAQUE: u8 = 1 << 1; // blocks light + hides neighbour faces
    pub const LIQUID: u8 = 1 << 2;
    pub const TRANSLUCENT: u8 = 1 << 3; // rendered in the translucent pass
    pub const CULL_SAME: u8 = 1 << 4; // hide faces between two identical blocks (glass, water)
    pub const NO_RENDER: u8 = 1 << 5; // air
}

use flags::*;

#[derive(Clone, Copy, Debug)]
pub struct BlockInfo {
    pub name: &'static str,
    pub flags: u8,
    pub light_emission: u8,
    pub light_filter: u8, // how much light is absorbed passing through (0..=15)
    pub hardness: f32,    // -1.0 = unbreakable
    pub friction: f32,
    pub tex_top: u16,
    pub tex_bottom: u16,
    pub tex_side: u16,
}

const fn b(
    name: &'static str,
    flags: u8,
    light_emission: u8,
    light_filter: u8,
    hardness: f32,
    tex: (u16, u16, u16),
) -> BlockInfo {
    BlockInfo {
        name,
        flags,
        light_emission,
        light_filter,
        hardness,
        friction: 0.6,
        tex_top: tex.0,
        tex_bottom: tex.1,
        tex_side: tex.2,
    }
}

const FULL: u8 = SOLID | OPAQUE;

pub const BLOCK_COUNT: usize = 24;

pub static BLOCKS: [BlockInfo; BLOCK_COUNT] = [
    b("minecraft:air", NO_RENDER, 0, 0, 0.0, (0, 0, 0)),
    b("minecraft:stone", FULL, 0, 15, 1.5, (1, 1, 1)),
    b("minecraft:grass_block", FULL, 0, 15, 0.6, (2, 3, 4)),
    b("minecraft:dirt", FULL, 0, 15, 0.5, (3, 3, 3)),
    b("minecraft:cobblestone", FULL, 0, 15, 2.0, (5, 5, 5)),
    b("minecraft:oak_planks", FULL, 0, 15, 2.0, (6, 6, 6)),
    b("minecraft:bedrock", FULL, 0, 15, -1.0, (7, 7, 7)),
    b("minecraft:water", LIQUID | TRANSLUCENT | CULL_SAME, 0, 1, 100.0, (8, 8, 8)),
    b("minecraft:lava", LIQUID, 15, 1, 100.0, (9, 9, 9)),
    b("minecraft:sand", FULL, 0, 15, 0.5, (10, 10, 10)),
    b("minecraft:gravel", FULL, 0, 15, 0.6, (11, 11, 11)),
    b("minecraft:oak_log", FULL, 0, 15, 2.0, (12, 12, 13)),
    b("minecraft:oak_leaves", SOLID, 0, 1, 0.2, (14, 14, 14)),
    b("minecraft:glass", SOLID | TRANSLUCENT | CULL_SAME, 0, 0, 0.3, (15, 15, 15)),
    b("minecraft:deepslate", FULL, 0, 15, 3.0, (16, 16, 17)),
    b("minecraft:snow_block", FULL, 0, 15, 0.2, (18, 18, 18)),
    b("minecraft:glowstone", FULL, 15, 15, 0.3, (19, 19, 19)),
    b("minecraft:coal_ore", FULL, 0, 15, 3.0, (20, 20, 20)),
    b("minecraft:iron_ore", FULL, 0, 15, 3.0, (21, 21, 21)),
    b("minecraft:diamond_ore", FULL, 0, 15, 3.0, (22, 22, 22)),
    b("minecraft:obsidian", FULL, 0, 15, 50.0, (23, 23, 23)),
    b("minecraft:bricks", FULL, 0, 15, 2.0, (24, 24, 24)),
    b("minecraft:ice", SOLID | TRANSLUCENT | CULL_SAME, 0, 1, 0.5, (25, 25, 25)),
    b("minecraft:sandstone", FULL, 0, 15, 0.8, (26, 27, 28)),
];

impl BlockId {
    pub const AIR: BlockId = BlockId(0);
    pub const STONE: BlockId = BlockId(1);
    pub const GRASS_BLOCK: BlockId = BlockId(2);
    pub const DIRT: BlockId = BlockId(3);
    pub const COBBLESTONE: BlockId = BlockId(4);
    pub const OAK_PLANKS: BlockId = BlockId(5);
    pub const BEDROCK: BlockId = BlockId(6);
    pub const WATER: BlockId = BlockId(7);
    pub const LAVA: BlockId = BlockId(8);
    pub const SAND: BlockId = BlockId(9);
    pub const GRAVEL: BlockId = BlockId(10);
    pub const OAK_LOG: BlockId = BlockId(11);
    pub const OAK_LEAVES: BlockId = BlockId(12);
    pub const GLASS: BlockId = BlockId(13);
    pub const DEEPSLATE: BlockId = BlockId(14);
    pub const SNOW_BLOCK: BlockId = BlockId(15);
    pub const GLOWSTONE: BlockId = BlockId(16);
    pub const COAL_ORE: BlockId = BlockId(17);
    pub const IRON_ORE: BlockId = BlockId(18);
    pub const DIAMOND_ORE: BlockId = BlockId(19);
    pub const OBSIDIAN: BlockId = BlockId(20);
    pub const BRICKS: BlockId = BlockId(21);
    pub const ICE: BlockId = BlockId(22);
    pub const SANDSTONE: BlockId = BlockId(23);

    #[inline(always)]
    pub fn info(self) -> &'static BlockInfo {
        // Unknown ids degrade to air instead of panicking in release builds.
        BLOCKS.get(self.0 as usize).unwrap_or(&BLOCKS[0])
    }
    #[inline(always)]
    pub fn flags(self) -> u8 {
        self.info().flags
    }
    #[inline(always)]
    pub fn is_air(self) -> bool {
        self.0 == 0
    }
    #[inline(always)]
    pub fn is_opaque(self) -> bool {
        self.flags() & OPAQUE != 0
    }
    #[inline(always)]
    pub fn is_solid(self) -> bool {
        self.flags() & SOLID != 0
    }
    #[inline(always)]
    pub fn is_liquid(self) -> bool {
        self.flags() & LIQUID != 0
    }
    #[inline(always)]
    pub fn light_emission(self) -> u8 {
        self.info().light_emission
    }
    #[inline(always)]
    pub fn name(self) -> &'static str {
        self.info().name
    }

    pub fn from_name(name: &str) -> Option<BlockId> {
        let full;
        let n = if name.contains(':') {
            name
        } else {
            full = format!("minecraft:{name}");
            &full
        };
        BLOCKS.iter().position(|i| i.name == n).map(|i| BlockId(i as u16))
    }

    /// Texture atlas slot for a given face (`0=down,1=up,2..5=sides`).
    #[inline(always)]
    pub fn texture_for_face(self, face: u8) -> u16 {
        let i = self.info();
        match face {
            0 => i.tex_bottom,
            1 => i.tex_top,
            _ => i.tex_side,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constants_match_table() {
        assert_eq!(BlockId::AIR.name(), "minecraft:air");
        assert_eq!(BlockId::STONE.name(), "minecraft:stone");
        assert_eq!(BlockId::SANDSTONE.name(), "minecraft:sandstone");
        assert_eq!(BLOCKS.len(), BlockId::SANDSTONE.0 as usize + 1);
    }

    #[test]
    fn lookup_by_name() {
        assert_eq!(BlockId::from_name("stone"), Some(BlockId::STONE));
        assert_eq!(BlockId::from_name("minecraft:water"), Some(BlockId::WATER));
        assert_eq!(BlockId::from_name("nope"), None);
    }

    #[test]
    fn flags_are_sane() {
        assert!(BlockId::STONE.is_opaque() && BlockId::STONE.is_solid());
        assert!(!BlockId::WATER.is_solid() && BlockId::WATER.is_liquid());
        assert!(!BlockId::GLASS.is_opaque() && BlockId::GLASS.is_solid());
        assert_eq!(BlockId(60_000).name(), "minecraft:air");
    }
}
