//! Multi-threaded chunk pipeline: generate -> light -> mesh, with view-distance streaming.
//!
//! * a small std-only thread pool (no external crates)
//! * generation jobs return finished chunks through a channel
//! * mesh jobs get an immutable 18³ snapshot, so no locks are held while meshing
//! * every mesh job carries an epoch so stale results (after a block edit) are dropped

use crate::block::BlockId;
use crate::chunk::Chunk;
use crate::lighting::compute_chunk_light;
use crate::math::{ChunkPos, SECTION_COUNT};
use crate::mesher::{mesh_section, ChunkMesh, MeshInput};
use crate::world::{FxBuild, FxHashMap, World};
use crate::worldgen::WorldGenerator;
use std::collections::{HashMap, HashSet};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;

type Job = Box<dyn FnOnce() + Send + 'static>;

pub struct ThreadPool {
    tx: Option<Sender<Job>>,
    workers: Vec<JoinHandle<()>>,
}

impl ThreadPool {
    pub fn new(threads: usize) -> Self {
        let threads = threads.max(1);
        let (tx, rx) = channel::<Job>();
        let rx = Arc::new(Mutex::new(rx));
        let workers = (0..threads)
            .map(|i| {
                let rx = Arc::clone(&rx);
                std::thread::Builder::new()
                    .name(format!("bf-worker-{i}"))
                    .spawn(move || loop {
                        let job = {
                            let guard = match rx.lock() {
                                Ok(g) => g,
                                Err(p) => p.into_inner(),
                            };
                            guard.recv()
                        };
                        match job {
                            Ok(j) => j(),
                            Err(_) => break,
                        }
                    })
                    .expect("failed to spawn worker")
            })
            .collect();
        Self { tx: Some(tx), workers }
    }

    pub fn execute<F: FnOnce() + Send + 'static>(&self, f: F) {
        if let Some(tx) = &self.tx {
            let _ = tx.send(Box::new(f));
        }
    }

    pub fn threads(&self) -> usize {
        self.workers.len()
    }
}

impl Drop for ThreadPool {
    fn drop(&mut self) {
        self.tx.take();
        for w in self.workers.drain(..) {
            let _ = w.join();
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct MeshKey {
    pub chunk: ChunkPos,
    pub section: u8,
}

struct MeshResult {
    key: MeshKey,
    epoch: u32,
    mesh: ChunkMesh,
}

#[derive(Default, Clone, Debug)]
pub struct ManagerStats {
    pub chunks_generated: u64,
    pub sections_meshed: u64,
    pub quads: u64,
}

pub struct ChunkManager {
    pub world: World,
    pub meshes: HashMap<MeshKey, ChunkMesh, FxBuild>,
    pub stats: ManagerStats,
    generator: Arc<WorldGenerator>,
    pool: ThreadPool,
    gen_tx: Sender<Chunk>,
    gen_rx: Receiver<Chunk>,
    mesh_tx: Sender<MeshResult>,
    mesh_rx: Receiver<MeshResult>,
    pending_gen: HashSet<ChunkPos>,
    dirty: HashSet<ChunkPos>,
    epochs: FxHashMap<i64, u32>,
    pending_mesh: usize,
    max_inflight_gen: usize,
    max_inflight_mesh: usize,
}

impl ChunkManager {
    pub fn new(seed: i64, threads: usize) -> Self {
        let (gen_tx, gen_rx) = channel();
        let (mesh_tx, mesh_rx) = channel();
        let threads = threads.max(1);
        Self {
            world: World::new(seed),
            meshes: HashMap::default(),
            stats: ManagerStats::default(),
            generator: Arc::new(WorldGenerator::new(seed)),
            pool: ThreadPool::new(threads),
            gen_tx,
            gen_rx,
            mesh_tx,
            mesh_rx,
            pending_gen: HashSet::new(),
            dirty: HashSet::new(),
            epochs: FxHashMap::default(),
            pending_mesh: 0,
            max_inflight_gen: threads * 4,
            max_inflight_mesh: threads * 16,
        }
    }

    pub fn threads(&self) -> usize {
        self.pool.threads()
    }

    /// Spiral-sorted offsets within a circular view distance.
    fn offsets(view: i32) -> Vec<(i32, i32)> {
        let mut v = Vec::new();
        for dx in -view..=view {
            for dz in -view..=view {
                if dx * dx + dz * dz <= view * view + view {
                    v.push((dx, dz));
                }
            }
        }
        v.sort_by_key(|&(x, z)| x * x + z * z);
        v
    }

    /// Drives the whole pipeline once. Call every frame (cheap when idle).
    pub fn update(&mut self, center: ChunkPos, view_distance: i32) {
        // 1. request generation (closest first)
        for (dx, dz) in Self::offsets(view_distance + 1) {
            if self.pending_gen.len() >= self.max_inflight_gen {
                break;
            }
            let p = ChunkPos::new(center.x + dx, center.z + dz);
            if self.world.is_loaded(p) || self.pending_gen.contains(&p) {
                continue;
            }
            self.pending_gen.insert(p);
            let g = Arc::clone(&self.generator);
            let tx = self.gen_tx.clone();
            self.pool.execute(move || {
                let mut c = g.generate_chunk(p);
                compute_chunk_light(&mut c);
                let _ = tx.send(c);
            });
        }

        // 2. collect finished chunks
        while let Ok(c) = self.gen_rx.try_recv() {
            let p = c.pos;
            self.pending_gen.remove(&p);
            self.world.insert_chunk(c);
            self.stats.chunks_generated += 1;
            self.mark_dirty_with_neighbours(p);
        }

        // 3. unload far chunks
        let far = view_distance + 3;
        let to_unload: Vec<ChunkPos> =
            self.world.loaded_positions().filter(|p| p.chebyshev_distance(center) > far).collect();
        for p in to_unload {
            self.world.unload_chunk(p);
            self.dirty.remove(&p);
            for sy in 0..SECTION_COUNT as u8 {
                self.meshes.remove(&MeshKey { chunk: p, section: sy });
            }
        }

        // 4. schedule meshing for dirty chunks whose neighbourhood is loaded
        let mut ready: Vec<ChunkPos> = self.dirty.iter().cloned().collect();
        ready.sort_by_key(|p| p.chebyshev_distance(center));
        for p in ready {
            if self.pending_mesh >= self.max_inflight_mesh {
                break;
            }
            if !self.world.is_loaded(p) {
                self.dirty.remove(&p);
                continue;
            }
            if !self.neighbourhood_loaded(p) {
                continue;
            }
            self.dirty.remove(&p);
            self.schedule_chunk_mesh(p);
        }

        // 5. collect finished meshes
        while let Ok(r) = self.mesh_rx.try_recv() {
            self.pending_mesh = self.pending_mesh.saturating_sub(1);
            let current = self.epochs.get(&r.key.chunk.pack()).copied().unwrap_or(0);
            if r.epoch != current || !self.world.is_loaded(r.key.chunk) {
                continue;
            }
            self.stats.sections_meshed += 1;
            self.stats.quads += r.mesh.quad_count() as u64;
            if r.mesh.is_empty() {
                self.meshes.remove(&r.key);
            } else {
                self.meshes.insert(r.key, r.mesh);
            }
        }
    }

    fn mark_dirty_with_neighbours(&mut self, p: ChunkPos) {
        for dx in -1..=1 {
            for dz in -1..=1 {
                self.dirty.insert(ChunkPos::new(p.x + dx, p.z + dz));
            }
        }
    }

    fn schedule_chunk_mesh(&mut self, p: ChunkPos) {
        let epoch = {
            let e = self.epochs.entry(p.pack()).or_insert(0);
            *e = e.wrapping_add(1);
            *e
        };
        let Some(chunk) = self.world.chunk(p) else { return };
        let mut jobs = Vec::new();
        let mut empties = Vec::new();
        for sy in 0..SECTION_COUNT {
            if chunk.sections[sy].is_empty() {
                empties.push(sy);
                continue;
            }
            jobs.push((sy, MeshInput::from_world(&self.world, p, sy)));
        }
        for sy in empties {
            self.meshes.remove(&MeshKey { chunk: p, section: sy as u8 });
        }
        for (sy, input) in jobs {
            let tx = self.mesh_tx.clone();
            let key = MeshKey { chunk: p, section: sy as u8 };
            self.pending_mesh += 1;
            self.pool.execute(move || {
                let mesh = mesh_section(&input);
                let _ = tx.send(MeshResult { key, epoch, mesh });
            });
        }
    }

    /// Edits a block and refreshes lighting + affected meshes.
    pub fn set_block(&mut self, x: i32, y: i32, z: i32, id: BlockId) -> bool {
        if self.world.set_block(x, y, z, id).is_none() {
            return false;
        }
        let cp = ChunkPos::new(x >> 4, z >> 4);
        if let Some(c) = self.world.chunk_mut(cp) {
            compute_chunk_light(c);
        }
        self.dirty.insert(cp);
        let (lx, lz) = (x & 15, z & 15);
        if lx == 0 {
            self.dirty.insert(ChunkPos::new(cp.x - 1, cp.z));
        }
        if lx == 15 {
            self.dirty.insert(ChunkPos::new(cp.x + 1, cp.z));
        }
        if lz == 0 {
            self.dirty.insert(ChunkPos::new(cp.x, cp.z - 1));
        }
        if lz == 15 {
            self.dirty.insert(ChunkPos::new(cp.x, cp.z + 1));
        }
        true
    }

    fn neighbourhood_loaded(&self, p: ChunkPos) -> bool {
        (-1..=1).all(|dx| (-1..=1).all(|dz| self.world.is_loaded(ChunkPos::new(p.x + dx, p.z + dz))))
    }

    /// True when nothing is queued or in flight. Dirty border chunks whose neighbours are
    /// not loaded yet cannot be meshed and therefore don't count as pending work.
    pub fn is_idle(&self) -> bool {
        self.pending_gen.is_empty()
            && self.pending_mesh == 0
            && !self.dirty.iter().any(|&p| self.world.is_loaded(p) && self.neighbourhood_loaded(p))
    }

    pub fn mesh_bytes(&self) -> usize {
        self.meshes.values().map(|m| m.opaque.bytes() + m.translucent.bytes()).sum()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    fn pump(m: &mut ChunkManager, center: ChunkPos, view: i32) {
        let t = Instant::now();
        loop {
            m.update(center, view);
            if m.is_idle() {
                break;
            }
            assert!(t.elapsed() < Duration::from_secs(60), "pipeline stalled");
            std::thread::sleep(Duration::from_millis(1));
        }
    }

    #[test]
    fn pool_runs_jobs() {
        let pool = ThreadPool::new(3);
        let (tx, rx) = channel();
        for i in 0..50 {
            let tx = tx.clone();
            pool.execute(move || tx.send(i).unwrap());
        }
        let mut got: Vec<i32> = (0..50).map(|_| rx.recv().unwrap()).collect();
        got.sort();
        assert_eq!(got, (0..50).collect::<Vec<_>>());
    }

    #[test]
    fn streams_generates_and_meshes() {
        let mut m = ChunkManager::new(42, 2);
        pump(&mut m, ChunkPos::new(0, 0), 2);
        assert!(m.world.loaded_count() >= 25);
        assert!(!m.meshes.is_empty());
        assert!(m.stats.quads > 0);
    }

    #[test]
    fn unloads_when_player_moves_away() {
        let mut m = ChunkManager::new(7, 2);
        pump(&mut m, ChunkPos::new(0, 0), 1);
        assert!(m.world.is_loaded(ChunkPos::new(0, 0)));
        pump(&mut m, ChunkPos::new(100, 100), 1);
        assert!(!m.world.is_loaded(ChunkPos::new(0, 0)));
        assert!(m.world.is_loaded(ChunkPos::new(100, 100)));
    }

    #[test]
    fn block_edit_remeshes() {
        let mut m = ChunkManager::new(3, 2);
        pump(&mut m, ChunkPos::new(0, 0), 1);
        let h = m.world.height_at(8, 8, crate::chunk::HeightmapKind::WorldSurface).unwrap();
        let before = m.stats.sections_meshed;
        assert!(m.set_block(8, h + 5, 8, BlockId::GLOWSTONE));
        pump(&mut m, ChunkPos::new(0, 0), 1);
        assert!(m.stats.sections_meshed > before);
        assert_eq!(m.world.get_block(8, h + 5, 8), BlockId::GLOWSTONE);
    }
}
