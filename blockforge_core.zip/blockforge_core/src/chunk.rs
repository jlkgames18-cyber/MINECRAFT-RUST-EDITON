//! Chunk storage.
//!
//! In memory every section keeps a flat `[u16; 4096]` (or a single value when uniform) for the
//! fastest possible random access. The vanilla *paletted container* wire format (single value /
//! indirect / direct, entries never straddling a `long`) is produced on demand by
//! [`write_paletted`] when a chunk is serialised for a client.

use crate::block::{flags, BlockId};
use crate::math::{ChunkPos, MIN_Y, SECTION_COUNT, WORLD_HEIGHT};
use crate::protocol::PacketBuf;

pub const SECTION_VOLUME: usize = 4096;
pub const BLOCK_DIRECT_BITS: u8 = 15;
pub const BIOME_DIRECT_BITS: u8 = 7;

#[inline(always)]
pub const fn section_index(x: usize, y: usize, z: usize) -> usize {
    (y << 8) | (z << 4) | x
}

#[derive(Clone)]
pub struct Section {
    blocks: Option<Box<[u16; SECTION_VOLUME]>>,
    single: u16,
    non_air: u16,
    pub biomes: [u8; 64],
    pub sky_light: Option<Box<[u8; 2048]>>,
    pub block_light: Option<Box<[u8; 2048]>>,
}

impl Default for Section {
    fn default() -> Self {
        Self { blocks: None, single: 0, non_air: 0, biomes: [0; 64], sky_light: None, block_light: None }
    }
}

impl Section {
    #[inline(always)]
    pub fn get(&self, x: usize, y: usize, z: usize) -> BlockId {
        match &self.blocks {
            Some(b) => BlockId(b[section_index(x, y, z)]),
            None => BlockId(self.single),
        }
    }

    #[inline]
    pub fn set(&mut self, x: usize, y: usize, z: usize, id: BlockId) -> BlockId {
        let idx = section_index(x, y, z);
        let old = match &mut self.blocks {
            Some(b) => {
                let o = b[idx];
                b[idx] = id.0;
                o
            }
            None => {
                if self.single == id.0 {
                    return id;
                }
                let mut arr = Box::new([self.single; SECTION_VOLUME]);
                let o = arr[idx];
                arr[idx] = id.0;
                self.blocks = Some(arr);
                o
            }
        };
        if old == 0 && id.0 != 0 {
            self.non_air += 1;
        } else if old != 0 && id.0 == 0 {
            self.non_air -= 1;
        }
        BlockId(old)
    }

    pub fn fill(&mut self, id: BlockId) {
        self.blocks = None;
        self.single = id.0;
        self.non_air = if id.0 == 0 { 0 } else { SECTION_VOLUME as u16 };
    }

    #[inline]
    pub fn non_air_count(&self) -> u16 {
        self.non_air
    }
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.non_air == 0
    }
    /// Raw slice if the section isn't uniform.
    #[inline]
    pub fn raw(&self) -> Option<&[u16; SECTION_VOLUME]> {
        self.blocks.as_deref()
    }
    #[inline]
    pub fn uniform_value(&self) -> Option<BlockId> {
        if self.blocks.is_none() {
            Some(BlockId(self.single))
        } else {
            None
        }
    }

    /// Collapses back to the single-value representation when possible (saves memory).
    pub fn compact(&mut self) {
        if let Some(b) = &self.blocks {
            let first = b[0];
            if b.iter().all(|&v| v == first) {
                self.single = first;
                self.blocks = None;
            }
        }
    }

    pub fn heap_bytes(&self) -> usize {
        self.blocks.as_ref().map_or(0, |_| SECTION_VOLUME * 2)
            + self.sky_light.as_ref().map_or(0, |_| 2048)
            + self.block_light.as_ref().map_or(0, |_| 2048)
    }

    // ---- light (nibble arrays) --------------------------------------------------------
    #[inline]
    pub fn get_sky_light(&self, x: usize, y: usize, z: usize) -> u8 {
        nibble_get(self.sky_light.as_deref(), section_index(x, y, z))
    }
    #[inline]
    pub fn get_block_light(&self, x: usize, y: usize, z: usize) -> u8 {
        nibble_get(self.block_light.as_deref(), section_index(x, y, z))
    }
}

#[inline]
fn nibble_get(arr: Option<&[u8; 2048]>, idx: usize) -> u8 {
    match arr {
        Some(a) => (a[idx >> 1] >> ((idx & 1) << 2)) & 0xF,
        None => 0,
    }
}

#[inline]
pub fn nibble_set(arr: &mut [u8; 2048], idx: usize, v: u8) {
    let shift = (idx & 1) << 2;
    let b = &mut arr[idx >> 1];
    *b = (*b & !(0xF << shift)) | ((v & 0xF) << shift);
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum HeightmapKind {
    WorldSurface,
    MotionBlocking,
}

pub struct Chunk {
    pub pos: ChunkPos,
    pub sections: Vec<Section>,
    /// Value = (highest matching block y) - MIN_Y + 1, `0` when the column is empty (vanilla layout).
    world_surface: [u16; 256],
    motion_blocking: [u16; 256],
    pub dirty: bool,
    pub light_ready: bool,
}

impl Chunk {
    pub fn new(pos: ChunkPos) -> Self {
        Self {
            pos,
            sections: (0..SECTION_COUNT).map(|_| Section::default()).collect(),
            world_surface: [0; 256],
            motion_blocking: [0; 256],
            dirty: false,
            light_ready: false,
        }
    }

    #[inline(always)]
    pub fn get_block(&self, x: usize, y: i32, z: usize) -> BlockId {
        let ry = y - MIN_Y;
        if !(0..WORLD_HEIGHT).contains(&ry) {
            return BlockId::AIR;
        }
        self.sections[(ry >> 4) as usize].get(x, (ry & 15) as usize, z)
    }

    /// Sets a block, keeps heightmaps in sync and returns the previous block.
    pub fn set_block(&mut self, x: usize, y: i32, z: usize, id: BlockId) -> BlockId {
        let ry = y - MIN_Y;
        if !(0..WORLD_HEIGHT).contains(&ry) {
            return BlockId::AIR;
        }
        let old = self.sections[(ry >> 4) as usize].set(x, (ry & 15) as usize, z, id);
        if old != id {
            self.dirty = true;
            self.update_heightmaps(x, y, z, id);
        }
        old
    }

    fn update_heightmaps(&mut self, x: usize, y: i32, z: usize, id: BlockId) {
        let col = (z << 4) | x;
        let top = (y - MIN_Y + 1) as u16;
        self.update_one(col, y, top, !id.is_air(), HeightmapKind::WorldSurface);
        let blocking = id.flags() & (flags::SOLID | flags::LIQUID) != 0;
        self.update_one(col, y, top, blocking, HeightmapKind::MotionBlocking);
    }

    fn update_one(&mut self, col: usize, y: i32, top: u16, matches: bool, kind: HeightmapKind) {
        let cur = match kind {
            HeightmapKind::WorldSurface => self.world_surface[col],
            HeightmapKind::MotionBlocking => self.motion_blocking[col],
        };
        let new = if matches {
            cur.max(top)
        } else if cur == top {
            // The top block was removed: scan downwards for the next match.
            let (x, z) = (col & 15, col >> 4);
            let mut yy = y - 1;
            let mut found = 0u16;
            while yy >= MIN_Y {
                let b = self.get_block(x, yy, z);
                let m = match kind {
                    HeightmapKind::WorldSurface => !b.is_air(),
                    HeightmapKind::MotionBlocking => b.flags() & (flags::SOLID | flags::LIQUID) != 0,
                };
                if m {
                    found = (yy - MIN_Y + 1) as u16;
                    break;
                }
                yy -= 1;
            }
            found
        } else {
            cur
        };
        match kind {
            HeightmapKind::WorldSurface => self.world_surface[col] = new,
            HeightmapKind::MotionBlocking => self.motion_blocking[col] = new,
        }
    }

    /// Full recompute – call after bulk generation.
    pub fn rebuild_heightmaps(&mut self) {
        for z in 0..16usize {
            for x in 0..16usize {
                let col = (z << 4) | x;
                self.world_surface[col] = 0;
                self.motion_blocking[col] = 0;
                for si in (0..SECTION_COUNT).rev() {
                    let s = &self.sections[si];
                    if s.is_empty() {
                        continue;
                    }
                    let mut done_ws = self.world_surface[col] != 0;
                    let mut done_mb = self.motion_blocking[col] != 0;
                    for ly in (0..16usize).rev() {
                        let b = s.get(x, ly, z);
                        let h = (si * 16 + ly + 1) as u16;
                        if !done_ws && !b.is_air() {
                            self.world_surface[col] = h;
                            done_ws = true;
                        }
                        if !done_mb && b.flags() & (flags::SOLID | flags::LIQUID) != 0 {
                            self.motion_blocking[col] = h;
                            done_mb = true;
                        }
                        if done_ws && done_mb {
                            break;
                        }
                    }
                    if done_ws && done_mb {
                        break;
                    }
                }
            }
        }
    }

    /// World Y of the first free block above the column's top block.
    #[inline]
    pub fn height_at(&self, x: usize, z: usize, kind: HeightmapKind) -> i32 {
        let v = match kind {
            HeightmapKind::WorldSurface => self.world_surface[(z << 4) | x],
            HeightmapKind::MotionBlocking => self.motion_blocking[(z << 4) | x],
        };
        v as i32 + MIN_Y
    }

    pub fn compact(&mut self) {
        for s in &mut self.sections {
            s.compact();
        }
    }

    pub fn heap_bytes(&self) -> usize {
        self.sections.iter().map(|s| s.heap_bytes()).sum::<usize>() + std::mem::size_of::<Self>()
    }

    /// Heightmap in the wire format: 9 bits per entry (for a 384-high world), no straddling.
    pub fn heightmap_longs(&self, kind: HeightmapKind) -> Vec<i64> {
        let src = match kind {
            HeightmapKind::WorldSurface => &self.world_surface,
            HeightmapKind::MotionBlocking => &self.motion_blocking,
        };
        let values: Vec<u16> = src.to_vec();
        pack_values(&values, 9)
    }

    /// Serialises the section array exactly in the `chunk data` layout (block count,
    /// block palette container, biome palette container per section).
    pub fn write_sections(&self, buf: &mut PacketBuf) {
        let mut scratch = [0u16; SECTION_VOLUME];
        for s in &self.sections {
            buf.write_i16(s.non_air_count() as i16);
            match s.raw() {
                Some(raw) => write_paletted(buf, &raw[..], 4, 8, BLOCK_DIRECT_BITS),
                None => {
                    scratch.fill(s.uniform_value().unwrap_or(BlockId::AIR).0);
                    write_paletted(buf, &scratch[..], 4, 8, BLOCK_DIRECT_BITS)
                }
            }
            let biomes: Vec<u16> = s.biomes.iter().map(|&b| b as u16).collect();
            write_paletted(buf, &biomes, 1, 3, BIOME_DIRECT_BITS);
        }
    }
}

/// Packs `values` using `bits` per entry, entries never straddle a 64-bit word
/// (the layout used since 1.16).
pub fn pack_values(values: &[u16], bits: u8) -> Vec<i64> {
    let per_long = 64 / bits as usize;
    let longs = values.len().div_ceil(per_long);
    let mut out = vec![0i64; longs];
    for (i, &v) in values.iter().enumerate() {
        let li = i / per_long;
        let shift = (i % per_long) * bits as usize;
        out[li] |= (v as i64) << shift;
    }
    out
}

pub fn unpack_values(longs: &[i64], bits: u8, count: usize) -> Vec<u16> {
    let per_long = 64 / bits as usize;
    let mask = (1u64 << bits) - 1;
    (0..count)
        .map(|i| {
            let word = longs[i / per_long] as u64;
            ((word >> ((i % per_long) * bits as usize)) & mask) as u16
        })
        .collect()
}

#[inline]
fn ceil_log2(n: usize) -> u8 {
    if n <= 1 {
        0
    } else {
        (usize::BITS - (n - 1).leading_zeros()) as u8
    }
}

/// Writes one paletted container.
/// * `min_bits`/`max_bits`: bounds of the indirect representation
/// * `direct_bits`: bits per entry when falling back to global ids
pub fn write_paletted(buf: &mut PacketBuf, values: &[u16], min_bits: u8, max_bits: u8, direct_bits: u8) {
    let mut lookup = vec![u16::MAX; 1usize << direct_bits];
    let mut palette: Vec<u16> = Vec::with_capacity(16);
    for &v in values {
        let slot = &mut lookup[v as usize];
        if *slot == u16::MAX {
            *slot = palette.len() as u16;
            palette.push(v);
        }
    }

    if palette.len() == 1 {
        buf.write_u8(0);
        buf.write_varint(palette[0] as i32);
        buf.write_varint(0);
        return;
    }

    let bits = ceil_log2(palette.len()).max(min_bits);
    if bits <= max_bits {
        buf.write_u8(bits);
        buf.write_varint(palette.len() as i32);
        for &p in &palette {
            buf.write_varint(p as i32);
        }
        let indices: Vec<u16> = values.iter().map(|&v| lookup[v as usize]).collect();
        let longs = pack_values(&indices, bits);
        buf.write_varint(longs.len() as i32);
        for l in longs {
            buf.write_i64(l);
        }
    } else {
        buf.write_u8(direct_bits);
        let longs = pack_values(values, direct_bits);
        buf.write_varint(longs.len() as i32);
        for l in longs {
            buf.write_i64(l);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn section_set_get_and_counts() {
        let mut s = Section::default();
        assert!(s.is_empty());
        s.set(1, 2, 3, BlockId::STONE);
        assert_eq!(s.get(1, 2, 3), BlockId::STONE);
        assert_eq!(s.non_air_count(), 1);
        s.set(1, 2, 3, BlockId::AIR);
        assert_eq!(s.non_air_count(), 0);
        s.compact();
        assert!(s.uniform_value().is_some());
    }

    #[test]
    fn heightmap_follows_edits() {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        c.set_block(3, 10, 4, BlockId::STONE);
        assert_eq!(c.height_at(3, 4, HeightmapKind::WorldSurface), 11);
        c.set_block(3, 20, 4, BlockId::DIRT);
        assert_eq!(c.height_at(3, 4, HeightmapKind::WorldSurface), 21);
        c.set_block(3, 20, 4, BlockId::AIR);
        assert_eq!(c.height_at(3, 4, HeightmapKind::WorldSurface), 11);
        c.set_block(3, 10, 4, BlockId::AIR);
        assert_eq!(c.height_at(3, 4, HeightmapKind::WorldSurface), MIN_Y);
    }

    #[test]
    fn rebuild_matches_incremental() {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        for y in -64..40 {
            c.set_block(5, y, 5, BlockId::STONE);
        }
        c.set_block(5, 40, 5, BlockId::WATER);
        let a = (c.height_at(5, 5, HeightmapKind::WorldSurface), c.height_at(5, 5, HeightmapKind::MotionBlocking));
        c.rebuild_heightmaps();
        let b = (c.height_at(5, 5, HeightmapKind::WorldSurface), c.height_at(5, 5, HeightmapKind::MotionBlocking));
        assert_eq!(a, b);
        assert_eq!(a.0, 41);
    }

    #[test]
    fn pack_unpack_roundtrip() {
        for bits in [4u8, 5, 8, 9, 15] {
            let max = (1u32 << bits) - 1;
            let vals: Vec<u16> = (0..4096u32).map(|i| ((i * 2654435761u32) % (max + 1)) as u16).collect();
            let packed = pack_values(&vals, bits);
            assert_eq!(unpack_values(&packed, bits, vals.len()), vals, "bits={bits}");
        }
    }

    #[test]
    fn heightmap_wire_length() {
        let c = Chunk::new(ChunkPos::new(0, 0));
        assert_eq!(c.heightmap_longs(HeightmapKind::WorldSurface).len(), 37);
    }

    #[test]
    fn paletted_single_value_layout() {
        let mut b = PacketBuf::new();
        write_paletted(&mut b, &[1u16; 4096], 4, 8, BLOCK_DIRECT_BITS);
        assert_eq!(b.as_slice(), &[0, 1, 0]);
    }

    #[test]
    fn paletted_indirect_uses_min_4_bits() {
        let mut vals = vec![0u16; 4096];
        vals[0] = 1;
        let mut b = PacketBuf::new();
        write_paletted(&mut b, &vals, 4, 8, BLOCK_DIRECT_BITS);
        let s = b.as_slice();
        assert_eq!(s[0], 4); // bits
        assert_eq!(s[1], 2); // palette len
        // 16 entries per long -> 256 longs -> varint(256) = 0x80 0x02
        assert_eq!(&s[4..6], &[0x80, 0x02]);
    }

    #[test]
    fn chunk_serialises_all_sections() {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        c.set_block(0, 0, 0, BlockId::STONE);
        let mut b = PacketBuf::new();
        c.write_sections(&mut b);
        assert!(b.len() > SECTION_COUNT * 6);
    }
}
