//! Deterministic terrain generator (noise based, thread safe).
//!
//! Pipeline per chunk (all column loops are cache friendly and allocation free):
//! 1. continentalness / erosion / detail noise -> surface height
//! 2. stone, deepslate transition (y -8..0 jitter), bedrock floor (y -64..-60 jitter)
//! 3. surface layers: grass/dirt, sand near sea level, snow on peaks
//! 4. sea (y < 63) filled with water
//! 5. ore veins using a per-chunk seeded `JavaRandom`

use crate::block::BlockId;
use crate::chunk::Chunk;
use crate::math::{ChunkPos, MIN_Y};
use crate::noise::OctaveNoise;
use crate::rng::{JavaRandom, RandomSource, Xoroshiro128pp};

pub const SEA_LEVEL: i32 = 63;

pub struct WorldGenerator {
    seed: i64,
    continental: OctaveNoise,
    erosion: OctaveNoise,
    detail: OctaveNoise,
    surface: OctaveNoise,
}

impl WorldGenerator {
    pub fn new(seed: i64) -> Self {
        let mut r = Xoroshiro128pp::from_seed(seed);
        Self {
            seed,
            continental: OctaveNoise::new(&mut r, 4),
            erosion: OctaveNoise::new(&mut r, 4),
            detail: OctaveNoise::new(&mut r, 6),
            surface: OctaveNoise::new(&mut r, 3),
        }
    }

    /// Terrain height (world y of the topmost solid block) at a column.
    pub fn height(&self, x: i32, z: i32) -> i32 {
        let fx = x as f64;
        let fz = z as f64;
        let c = self.continental.sample2d(fx / 512.0, fz / 512.0); // -1..1
        let e = self.erosion.sample2d(fx / 256.0 + 1000.0, fz / 256.0 - 1000.0);
        let d = self.detail.sample2d(fx / 48.0, fz / 48.0);
        let base = 64.0 + c * 38.0;
        let mountain = ((c - 0.15).max(0.0) * 1.4) * (1.0 - e.abs()) * 70.0;
        let h = base + mountain + d * (6.0 + (1.0 - e.abs()) * 10.0);
        h.round() as i32
    }

    pub fn generate_chunk(&self, pos: ChunkPos) -> Chunk {
        let mut chunk = Chunk::new(pos);
        let bx = pos.min_block_x();
        let bz = pos.min_block_z();

        // Per chunk RNG derived from the seed (same trick vanilla uses for decorators).
        let mut rng = JavaRandom::new(
            self.seed ^ (pos.x as i64).wrapping_mul(341873128712) ^ (pos.z as i64).wrapping_mul(132897987541),
        );

        for lz in 0..16usize {
            for lx in 0..16usize {
                let wx = bx + lx as i32;
                let wz = bz + lz as i32;
                let h = self.height(wx, wz);
                let top = h.max(SEA_LEVEL);
                let jitter = self.surface.sample2d(wx as f64 / 8.0, wz as f64 / 8.0);
                let deepslate_top = ((jitter * 4.0) as i32) - 4; // around y=-4

                let cold = h > 150 + (jitter * 8.0) as i32;
                let beach = (h - SEA_LEVEL).abs() <= 2 && h <= SEA_LEVEL + 2;

                for y in MIN_Y..=top {
                    let id = if y <= MIN_Y + 4 && (y == MIN_Y || rng.next_i32_bounded(5) as i32 > (y - MIN_Y)) {
                        BlockId::BEDROCK
                    } else if y > h {
                        BlockId::WATER
                    } else if y == h {
                        if beach {
                            BlockId::SAND
                        } else if h < SEA_LEVEL {
                            BlockId::GRAVEL
                        } else if cold {
                            BlockId::SNOW_BLOCK
                        } else {
                            BlockId::GRASS_BLOCK
                        }
                    } else if y >= h - 3 {
                        if beach {
                            BlockId::SANDSTONE
                        } else if cold {
                            BlockId::STONE
                        } else {
                            BlockId::DIRT
                        }
                    } else if y < deepslate_top {
                        BlockId::DEEPSLATE
                    } else {
                        BlockId::STONE
                    };
                    chunk.set_block(lx, y, lz, id);
                }
            }
        }

        self.place_ores(&mut chunk, &mut rng);
        self.place_trees(&mut chunk, &mut rng);

        chunk.rebuild_heightmaps();
        chunk.compact();
        chunk.dirty = false;
        chunk
    }

    fn place_ores(&self, chunk: &mut Chunk, rng: &mut JavaRandom) {
        // (block, attempts per chunk, vein size, min_y, max_y)
        const ORES: [(BlockId, i32, i32, i32, i32); 4] = [
            (BlockId::COAL_ORE, 20, 17, 0, 128),
            (BlockId::IRON_ORE, 20, 9, -24, 56),
            (BlockId::DIAMOND_ORE, 7, 4, -64, 16),
            (BlockId::GRAVEL, 8, 33, -64, 64),
        ];
        for &(ore, tries, size, min_y, max_y) in &ORES {
            for _ in 0..tries {
                let x = rng.next_i32_bounded(16);
                let z = rng.next_i32_bounded(16);
                let y = min_y + rng.next_i32_bounded(max_y - min_y);
                let (mut cx, mut cy, mut cz) = (x, y, z);
                for _ in 0..size {
                    if (0..16).contains(&cx) && (0..16).contains(&cz) {
                        let cur = chunk.get_block(cx as usize, cy, cz as usize);
                        if cur == BlockId::STONE || cur == BlockId::DEEPSLATE {
                            chunk.set_block(cx as usize, cy, cz as usize, ore);
                        }
                    }
                    cx += rng.next_i32_bounded(3) - 1;
                    cy += rng.next_i32_bounded(3) - 1;
                    cz += rng.next_i32_bounded(3) - 1;
                }
            }
        }
    }

    fn place_trees(&self, chunk: &mut Chunk, rng: &mut JavaRandom) {
        for _ in 0..3 {
            // keep a 2 block margin so a canopy never crosses the chunk boundary
            let x = 2 + rng.next_i32_bounded(12);
            let z = 2 + rng.next_i32_bounded(12);
            let ground = {
                let mut y = 200;
                while y > SEA_LEVEL && chunk.get_block(x as usize, y, z as usize).is_air() {
                    y -= 1;
                }
                y
            };
            if chunk.get_block(x as usize, ground, z as usize) != BlockId::GRASS_BLOCK {
                continue;
            }
            let trunk = 4 + rng.next_i32_bounded(3);
            for dy in 1..=trunk {
                chunk.set_block(x as usize, ground + dy, z as usize, BlockId::OAK_LOG);
            }
            let top = ground + trunk;
            for dy in -1..=2 {
                let r: i32 = if dy >= 1 { 1 } else { 2 };
                for dx in -r..=r {
                    for dz in -r..=r {
                        if r == 2 && dx.abs() == 2 && dz.abs() == 2 && rng.next_bool() {
                            continue;
                        }
                        let (lx, ly, lz) = ((x + dx) as usize, top + dy, (z + dz) as usize);
                        if chunk.get_block(lx, ly, lz).is_air() {
                            chunk.set_block(lx, ly, lz, BlockId::OAK_LEAVES);
                        }
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::HeightmapKind;

    #[test]
    fn generation_is_deterministic() {
        let g1 = WorldGenerator::new(2024);
        let g2 = WorldGenerator::new(2024);
        let a = g1.generate_chunk(ChunkPos::new(3, -2));
        let b = g2.generate_chunk(ChunkPos::new(3, -2));
        for y in (-64..200).step_by(7) {
            for i in 0..16usize {
                assert_eq!(a.get_block(i, y, 15 - i), b.get_block(i, y, 15 - i));
            }
        }
    }

    #[test]
    fn terrain_has_bedrock_floor_and_surface() {
        let g = WorldGenerator::new(1);
        let c = g.generate_chunk(ChunkPos::new(0, 0));
        for x in 0..16usize {
            for z in 0..16usize {
                assert_eq!(c.get_block(x, MIN_Y, z), BlockId::BEDROCK);
                let h = c.height_at(x, z, HeightmapKind::WorldSurface);
                assert!(h > MIN_Y + 5 && h < 320, "height {h}");
                assert!(!c.get_block(x, h - 1, z).is_air());
                assert!(c.get_block(x, h, z).is_air());
            }
        }
    }

    #[test]
    fn different_seeds_differ() {
        let a = WorldGenerator::new(1).height(100, 100);
        let b = WorldGenerator::new(2).height(100, 100);
        let c = WorldGenerator::new(3).height(-4000, 900);
        assert!(a != b || b != c);
    }
}
