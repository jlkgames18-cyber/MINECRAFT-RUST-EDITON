# BlockForge Core — Minecraft Java 1.21.11 engine core (Rust)

نواة محرك مكعبات (Voxel) مكتوبة بالكامل بلغة **Rust** وبدون أي اعتماديات خارجية،
تستهدف **Minecraft: Java Edition 1.21.11** — Protocol `774`، Data Version `4671`.

This is the *core* only (data, algorithms, simulation). Renderer / audio / UI / gameplay plug on top.

## Quick start

```bash
# install Rust: https://rustup.rs
cargo test --release          # 67 unit tests
cargo run --release           # headless benchmark / self-check
cargo run --release -- --view 12 --threads 8 --seed 42
```

## Modules

| module       | what it does |
|--------------|--------------|
| `math`       | `Vec3`, `BlockPos` (26/26/12 bit packing), `ChunkPos`, `Aabb`, `Face` (vanilla `Direction` order), world height −64..320 |
| `rng`        | bit-exact `java.util.Random` (verified against reference vectors) + Xoroshiro128++ with Stafford-13 seeding |
| `noise`      | improved Perlin (permutation shuffled by the seeded RNG, per-instance offsets) + octaves |
| `block`      | `const` block table: flags, light, hardness, friction, textures. O(1) lookups |
| `chunk`      | 24 sections of 16³, heightmaps, vanilla *paletted container* serialisation (single / indirect / direct, no straddling) |
| `world`      | sparse chunk map with FxHash, unloaded-chunk-is-solid collision rule |
| `worldgen`   | deterministic terrain, bedrock/deepslate layers, sea level 63, ores, trees |
| `lighting`   | sky + block light flood fill (BFS) |
| `mesher`     | greedy mesher: face culling, AO-aware merging, 10-byte vertices, opaque + translucent layers |
| `manager`    | thread pool + generate → light → mesh pipeline, streaming, epochs for stale-result dropping |
| `physics`    | vanilla player physics (gravity 0.08, drag 0.98, jump 0.42, friction 0.6·0.91, sprint ×1.3, step 0.6, sneak edge) |
| `raycast`    | DDA voxel traversal, reach 4.5 / 5.0 |
| `tick`       | 20 TPS accumulator with partial-tick interpolation, catch-up cap, FPS / 1 % low stats |
| `protocol`   | VarInt/VarLong, frames, handshake, status JSON, position codec |

## Performance design

* `#![forbid(unsafe_code)]`, zero dependencies, `lto = "fat"`, `codegen-units = 1`, `panic = "abort"`
* sections are flat `[u16; 4096]` (or a single value when uniform) — no palette decode in hot paths
* meshing runs on an 18³ snapshot → lock-free worker threads
* nothing allocates inside the greedy-meshing inner loops
* all block queries are `const` table lookups

## Fidelity — what is matched, what is not

Matched to vanilla (and covered by tests):
`java.util.Random` output, BlockPos / ChunkPos packing, VarInt encoding, handshake & status format,
paletted-container wire layout, heightmap wire layout (9 bits × 256), 20 TPS, world height,
player hitbox / eye height, jump height ≈ 1.2522, walking speed ≈ 4.317 b/s, collision axis order, step-up algorithm,
protocol 774 / data version 4671.

**Not** 1:1 (honest scope notes):
* block-state ids are internal (24 blocks). To get the official numbering run the server data generator
  (`java -DbundlerMainClass=net.minecraft.data.Main -jar server.jar --reports`) and generate `block.rs` from `reports/blocks.json`.
* world generation is a noise-based approximation, **not** the vanilla density-function / biome-source pipeline,
  so seeds do not reproduce vanilla terrain.
* lighting is per-chunk (no cross-chunk stitching), play-state packets / encryption / compression are not included.

## License

MIT
