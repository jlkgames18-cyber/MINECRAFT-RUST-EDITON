import { useMemo, useState } from "react";
import GameView from "./components/GameView";
import { lines, rustFiles, totalRustLines, totalWebLines, webFiles } from "./data/sources";
import { buildZip, download } from "./utils/zip";

const STATS: [string, string, string][] = [
  ["415", "كتلة", "كانت 24"],
  ["1168", "عنصر", "أدوات، دروع، طعام، بيض مخلوقات…"],
  ["583", "وصفة", "515 تصنيع + 68 صهر"],
  ["42", "بيئة (Biome)", "كانت 0"],
  ["64", "مخلوق", "ذكاء اصطناعي + قواعد ظهور"],
  ["33 / 42", "تأثيرات / سحر", "Effects / Enchantments"],
  ["133", "اختبار آلي", "126 وحدة + 7 تكامل"],
  ["13", "نوع شجر/فطر", "بدون قطع عند حدود الـ chunk"],
];

const FIXES: [string, string][] = [
  ["الإضاءة معكوسة: الماء والأوراق والزجاج والجليد كانت تحجب الضوء كلياً", "فلتر الإضاءة = الضوء الممتص، مع حد أدنى 1 لكل خطوة"],
  ["ضوء السماء كان ينقص 1 لكل كتلة هواء عند النزول", "نزول عمودي بلا فقد عبر الكتل الشفافة (قاعدة ماين كرافت)"],
  ["الإضاءة لا تعبر حدود الـ chunk (خطوط سوداء)", "ربط الإضاءة مع الجيران + إعادة إضاءة الحدود بعد كل تحميل/تعديل"],
  ["مسافة السقوط تتجاهل آخر tick ولا يوجد حدث هبوط", "تراكم دقيق + landed_fall؛ الماء والسلالم والطيران تلغي الضرر"],
  ["الحمم تتصرف كالماء تماماً", "in_lava منفصل: مقاومة 0.5 وغرق بطيء"],
  ["الأشجار تُقصّ بهامش 2 كتل فتظهر فجوات وأشجار ناقصة", "إعادة تشغيل عشوائية الجيران 3×3 → أشجار كاملة عبر الحدود"],
  ["تعديل كتلة يعيد إضاءة الـ chunk نفسه فقط", "تحديث الجيران عند الحافة + إعادة بناء المش"],
  ["الـ mesher يدمج الوجوه دون اعتبار للإضاءة", "مفتاح الدمج يشمل الإضاءة وAO؛ كل رأس يحمل sky<<4|block"],
  ["أعلام الكتل u8 — لا مجال لإضافة سلوكيات", "u16: نباتات، جاذبية، سلالم، قابلية الاشتعال، أداة مطلوبة، random tick"],
  ["عروق الخامات خطوط بعرض كتلة واحدة", "عروق إهليلجية، متغيرات deepslate، نطاقات ارتفاع مثل ماين كرافت"],
];

const SYSTEMS: [string, string][] = [
  ["biome.rs", "42 بيئة + مصدر مناخ (حرارة/رطوبة/ارتفاع/أنهار/قمم)"],
  ["worldgen.rs", "كهوف جبنية وخيطية، أنهار، محيطات، خامات، نباتات، حمم تحت -54"],
  ["trees.rs", "بلوط، بتولا، صنوبر، غابة، أكاسيا، بلوط داكن، كرز، مانغروف، فطر عملاق، أشواك جليد"],
  ["structures.rs", "آبار الصحراء + الزنزانات (Spawner + صناديق)"],
  ["ticking.rs", "تدفق الماء والحمم، ماء لا نهائي، سبج/حجر، رمل ساقط، نمو وانتشار وتحلل"],
  ["item.rs", "1168 عنصراً: أدوات 6 مستويات، دروع، طعام، متغيرات، 16 لوناً، أسطوانات"],
  ["recipe.rs", "515 وصفة تصنيع (شكلية/عشوائية/معكوسة) + 68 وصفة صهر"],
  ["inventory.rs", "36 خانة، دروع، دمج المجموعات، متانة الأدوات"],
  ["mining.rs", "صيغة سرعة التكسير الأصلية، مستويات الأدوات، المسروقات، Fortune/Silk Touch"],
  ["effects.rs", "33 تأثيراً و42 سحراً مع المعدّلات"],
  ["game.rs", "أوضاع اللعب، الجوع، الغرق، حماية الدروع، ضرر السقوط، الخبرة"],
  ["entity.rs", "64 مخلوقاً: مطاردة، تجوّل، كريبر ينفجر، حرق تحت الشمس، قواعد الظهور"],
  ["explosion.rs", "خوارزمية الانفجار الأصلية (أشعة 16³) وضرر الكيانات"],
  ["time.rs", "دورة الليل والنهار، أطوار القمر، آلة حالة الطقس"],
  ["commands.rs", "/gamemode /time /weather /tp /give /setblock /fill /effect /xp …"],
  ["save.rs", "حفظ الـ chunks: palette + CRC‑32 + كتابة ذرّية"],
  ["physics.rs v2", "طيران، سباحة، حمم، سلالم، جليد، رمل الأرواح، شبكة العنكبوت، عسل"],
  ["mesher.rs v2", "إضاءة لكل رأس، نباتات متقاطعة، دمج حسب AO + الضوء"],
];

const BENCH = `BlockForge Core v0.2.0  |  target Minecraft Java 1.21.11  (protocol 774, data 4671)
registries: 415 blocks · 452 textures · 1168 items · 515 crafting + 68 smelting recipes · 42 biomes · 64 mobs · 33 effects · 42 enchantments

[worldgen ] 64 chunks in 611.4 ms  -> 104.7 chunks/s/thread
[mesher   ] 577 sections, 156299 quads in 114.9 ms  -> 5023 sections/s
[raycast  ] 20000 rays in 12.2 ms
[physics  ] 200 sprint ticks -> on_ground=true
[pipeline ] view 8: 293 chunks, 2001 sections meshed, 547567 quads in 1892 ms
[simulate ] 100 ticks (water poured from the sky + random ticks): 65 block changes in 17.9 ms
[save     ] one chunk = 18836 bytes, reload ok = true`;

function Section({ id, title, kicker, children }: { id?: string; title: string; kicker?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto w-full max-w-6xl px-4 py-12">
      {kicker && <div className="mb-2 text-sm font-semibold tracking-wide text-emerald-400">{kicker}</div>}
      <h2 className="mb-6 text-2xl font-extrabold text-white md:text-3xl">{title}</h2>
      {children}
    </section>
  );
}

export default function App() {
  const [open, setOpen] = useState<string | null>("blockforge_core/src/lib.rs");
  const [busy, setBusy] = useState<string | null>(null);
  const current = useMemo(() => rustFiles.find((f) => f.path === open), [open]);

  const bytes = (n: number) => (n > 1024 * 1024 ? (n / 1048576).toFixed(2) + " MB" : (n / 1024).toFixed(0) + " KB");
  const rustBytes = rustFiles.reduce((n, f) => n + f.content.length, 0);
  const webBytes = webFiles.reduce((n, f) => n + f.content.length, 0);

  const doDownload = (kind: "all" | "rust" | "web") => {
    setBusy(kind);
    setTimeout(() => {
      const entries = kind === "rust" ? rustFiles : kind === "web" ? webFiles : [...rustFiles, ...webFiles];
      const name = kind === "rust" ? "blockforge_core-v0.2.0-source.zip" : kind === "web" ? "blockforge-web-demo-source.zip" : "blockforge-full-source.zip";
      download(buildZip(entries), name);
      setBusy(null);
    }, 30);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-200" style={{ fontFamily: "'Segoe UI', Tahoma, 'Noto Sans Arabic', system-ui, sans-serif" }}>
      <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#top" className="flex items-center gap-2 font-extrabold text-white">
            <span className="grid h-8 w-8 place-items-center rounded bg-emerald-500 text-slate-950">▣</span>
            BlockForge Core 2
          </a>
          <nav className="hidden gap-5 text-sm text-slate-300 md:flex">
            <a className="hover:text-white" href="#demo">العرض الحي</a>
            <a className="hover:text-white" href="#stats">الأرقام</a>
            <a className="hover:text-white" href="#fixes">الإصلاحات</a>
            <a className="hover:text-white" href="#systems">الأنظمة</a>
            <a className="hover:text-white" href="#code">الكود</a>
            <a className="rounded bg-emerald-500 px-3 py-1 font-bold text-slate-950 hover:bg-emerald-400" href="#download">تحميل المصدر</a>
          </nav>
        </div>
      </header>

      <main id="top">
        <div className="relative overflow-hidden border-b border-white/10 bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.18),transparent_60%)]">
          <div className="mx-auto max-w-6xl px-4 py-14 text-center md:py-20">
            <div className="mx-auto mb-4 inline-flex rounded-full bg-emerald-500/15 px-4 py-1 text-sm text-emerald-300 ring-1 ring-emerald-400/30">Rust · بدون أي اعتماديات · Minecraft Java 1.21.11</div>
            <h1 className="text-4xl font-black leading-tight text-white md:text-6xl">
              نواة ماين كرافت <span className="text-emerald-400">بلغة Rust</span>
              <br />بعد التطوير والإصلاح
            </h1>
            <p className="mx-auto mt-5 max-w-3xl text-lg leading-8 text-slate-300">
              أخذنا نواة <b>BlockForge</b> من مستودع <span dir="ltr" className="font-mono text-emerald-300">MINECRAFT-RUST-EDITON</span> وأصلحنا أخطاءها الجوهرية وأضفنا مئات العناصر:
              415 كتلة، 42 بيئة، كهوف، أنهار، سوائل، تصنيع، مخلوقات، أوامر، حفظ العالم… وكل ذلك مختبَر بـ 133 اختباراً. جرّب الخوارزميات مباشرة في اللعبة أدناه ثم حمّل الكود الكامل.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a href="#demo" className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-slate-950 shadow-lg shadow-emerald-500/30 hover:bg-emerald-400">▶ جرّب العرض الحي</a>
              <a href="#download" className="rounded-xl bg-white/10 px-6 py-3 font-bold text-white ring-1 ring-white/20 hover:bg-white/15">⬇ تحميل الكود المصدري</a>
            </div>
          </div>
        </div>

        <Section id="demo" kicker="لعبة قابلة للّعب" title="العرض الحي — عالم يُولَّد بخوارزميات النواة">
          <GameView />
        </Section>

        <Section id="stats" kicker="الحصيلة" title="ما الذي أُضيف؟">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {STATS.map(([n, l, s]) => (
              <div key={l} className="rounded-2xl bg-gradient-to-b from-white/[0.07] to-white/[0.02] p-5 ring-1 ring-white/10">
                <div className="text-3xl font-black text-emerald-400 md:text-4xl" dir="ltr">{n}</div>
                <div className="mt-1 font-bold text-white">{l}</div>
                <div className="mt-1 text-xs text-slate-400">{s}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10"><b className="text-white" dir="ltr">{totalRustLines.toLocaleString("en")}</b> سطر Rust في {rustFiles.filter((f) => f.path.endsWith(".rs")).length} ملفاً (كانت 4247 سطراً في 16 ملفاً)</div>
            <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10"><b className="text-white" dir="ltr">{totalWebLines.toLocaleString("en")}</b> سطر TypeScript/React في العرض الحي</div>
            <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">0 اعتماديات خارجية في Cargo.toml، و <code dir="ltr">#![forbid(unsafe_code)]</code></div>
          </div>
        </Section>

        <Section id="fixes" kicker="Bug fixes" title="الأخطاء التي وُجدت وأُصلحت">
          <div className="overflow-hidden rounded-2xl ring-1 ring-white/10">
            <table className="w-full text-right text-sm">
              <thead className="bg-white/10 text-slate-200">
                <tr><th className="w-10 p-3">#</th><th className="p-3">المشكلة في النسخة الأصلية 0.1.0</th><th className="p-3">الإصلاح في 0.2.0</th></tr>
              </thead>
              <tbody>
                {FIXES.map(([a, b], i) => (
                  <tr key={i} className="border-t border-white/10 odd:bg-white/[0.02]">
                    <td className="p-3 font-mono text-emerald-400">{i + 1}</td>
                    <td className="p-3 text-slate-300">{a}</td>
                    <td className="p-3 text-emerald-200">{b}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        <Section id="systems" kicker="Systems" title="الأنظمة الجديدة في النواة">
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {SYSTEMS.map(([m, d]) => (
              <div key={m} className="rounded-xl bg-white/[0.04] p-4 ring-1 ring-white/10 transition hover:bg-white/[0.07] hover:ring-emerald-400/40">
                <div dir="ltr" className="mb-1 text-left font-mono text-sm font-bold text-emerald-300">{m}</div>
                <div className="text-sm leading-6 text-slate-300">{d}</div>
              </div>
            ))}
          </div>
          <div className="mt-6 rounded-2xl bg-slate-900 p-4 ring-1 ring-white/10">
            <div className="mb-2 text-sm font-bold text-white">نتيجة <code dir="ltr">cargo run --release</code> (قياس حقيقي على بيئة الاختبار)</div>
            <pre dir="ltr" className="overflow-x-auto text-left font-mono text-xs leading-5 text-emerald-200">{BENCH}</pre>
          </div>
          <p className="mt-4 text-sm leading-7 text-slate-400">
            <b className="text-slate-300">ملاحظة صريحة:</b> النواة لا تعيد إنتاج تضاريس ماين كرافت الأصلية بنفس البذرة (التوليد تقريبي بالضجيج)، ولا تحتوي على الـ Nether/End أو الريدستون أو حزم الشبكة الخاصة بمرحلة اللعب،
            والأدراج/الألواح/الأبواب موجودة كعناصر حتى يحصل المُرسِم على أشكال أنصاف الكتل. العرض الحي أعلاه نسخة TypeScript من خوارزميات النواة وليس الـ Rust نفسه.
          </p>
        </Section>

        <Section id="code" kicker="Source" title="تصفّح كود Rust">
          <div className="grid gap-4 md:grid-cols-[260px_1fr]">
            <div dir="ltr" className="max-h-[520px] overflow-auto rounded-2xl bg-slate-900 p-2 ring-1 ring-white/10">
              {rustFiles.map((f) => (
                <button key={f.path} onClick={() => setOpen(f.path)} className={`flex w-full items-center justify-between gap-2 rounded px-2 py-1 text-left font-mono text-xs ${open === f.path ? "bg-emerald-500/20 text-emerald-200" : "text-slate-300 hover:bg-white/5"}`}>
                  <span className="truncate">{f.path.replace("blockforge_core/", "")}</span>
                  <span className="shrink-0 text-slate-500">{lines(f.content)}</span>
                </button>
              ))}
            </div>
            <div dir="ltr" className="max-h-[520px] overflow-auto rounded-2xl bg-slate-900 ring-1 ring-white/10">
              <div className="sticky top-0 border-b border-white/10 bg-slate-900 px-4 py-2 text-left font-mono text-xs text-emerald-300">{current?.path}</div>
              <pre className="p-4 text-left font-mono text-[11.5px] leading-5 text-slate-300">{current ? current.content.slice(0, 60000) : ""}</pre>
            </div>
          </div>
        </Section>

        <Section id="download" kicker="الخطوة الأخيرة" title="تحميل الكود المصدري الكامل">
          <div className="rounded-3xl bg-gradient-to-br from-emerald-500/20 via-slate-900 to-slate-900 p-6 ring-1 ring-emerald-400/40 md:p-10">
            <div className="grid items-center gap-8 md:grid-cols-[1.3fr_1fr]">
              <div>
                <p className="mb-5 leading-8 text-slate-300">
                  الأرشيف يُبنى داخل المتصفح من الملفات الحقيقية نفسها (لا روابط خارجية): مشروع Cargo كامل جاهز للبناء + اختبارات + مولّد الكتل، مع مصدر العرض الحي.
                </p>
                <button
                  onClick={() => doDownload("all")}
                  disabled={busy !== null}
                  className="w-full rounded-2xl bg-emerald-500 px-8 py-5 text-xl font-black text-slate-950 shadow-xl shadow-emerald-500/30 transition hover:bg-emerald-400 disabled:opacity-60 md:w-auto"
                >
                  {busy === "all" ? "جارٍ إنشاء الأرشيف…" : "⬇ تحميل الكود المصدري الكامل (ZIP)"}
                </button>
                <div className="mt-4 flex flex-wrap gap-2 text-sm">
                  <button onClick={() => doDownload("rust")} className="rounded-lg bg-white/10 px-4 py-2 font-semibold text-white ring-1 ring-white/15 hover:bg-white/20">نواة Rust فقط ({bytes(rustBytes)})</button>
                  <button onClick={() => doDownload("web")} className="rounded-lg bg-white/10 px-4 py-2 font-semibold text-white ring-1 ring-white/15 hover:bg-white/20">العرض الحي فقط ({bytes(webBytes)})</button>
                </div>
              </div>
              <div dir="ltr" className="rounded-2xl bg-black/50 p-4 text-left font-mono text-xs leading-6 text-slate-300 ring-1 ring-white/10">
                <div className="text-slate-500"># بعد فك الضغط</div>
                <div>cd blockforge_core</div>
                <div>cargo test --release <span className="text-slate-500">  # 133 tests</span></div>
                <div>cargo run --release <span className="text-slate-500">   # benchmark</span></div>
                <div>python3 tools/gen_blocks.py &gt; src/block_table.rs</div>
                <div className="mt-2 text-slate-500"># العرض الحي</div>
                <div>cd web-demo &amp;&amp; npm i &amp;&amp; npm run dev</div>
              </div>
            </div>
            <div className="mt-6 text-xs text-slate-400" dir="ltr">
              {rustFiles.length + webFiles.length} files · blockforge_core/ ({rustFiles.length}) + web-demo/ ({webFiles.length}) · MIT
            </div>
          </div>
        </Section>
      </main>

      <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500">
        BlockForge Core 2 — مشروع تعليمي مستقل، غير تابع لـ Mojang أو Microsoft. Minecraft علامة تجارية مملوكة لأصحابها.
      </footer>
    </div>
  );
}
