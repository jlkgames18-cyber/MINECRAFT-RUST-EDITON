// Port of physics.rs: vanilla player movement (20 TPS), collision, step-up, sneak edge, swimming, flying.
import { B, BLOCKS, getBlock } from "./blocks";
import { H, World } from "./world";

const WATER = B("water");
const LAVA = B("lava");
export const GRAVITY = 0.08;
export const JUMP = 0.42;
export const STEP = 0.6;
export const W = 0.6;
export const HEIGHT = 1.8;
export const SNEAK_HEIGHT = 1.5;
export const EYE = 1.62;
export const SNEAK_EYE = 1.27;

export interface Vec3 { x: number; y: number; z: number }
export interface Input { forward: number; strafe: number; jump: boolean; sneak: boolean; sprint: boolean }
interface Box { x0: number; y0: number; z0: number; x1: number; y1: number; z1: number }

const EPS = 1e-7;
const floor = Math.floor;

function solidAt(world: World, x: number, y: number, z: number): boolean {
  if (y < 0) return true;
  if (y >= H) return false;
  if (!world.get(x >> 4, z >> 4)) return true; // unloaded chunks are solid (like world.rs)
  return getBlock(world.getBlock(x, y, z)).solid;
}

function boxesIn(world: World, a: Box): Box[] {
  const out: Box[] = [];
  for (let x = floor(a.x0 - EPS); x <= floor(a.x1 + EPS); x++)
    for (let y = floor(a.y0 - EPS); y <= floor(a.y1 + EPS); y++)
      for (let z = floor(a.z0 - EPS); z <= floor(a.z1 + EPS); z++)
        if (solidAt(world, x, y, z)) out.push({ x0: x, y0: y, z0: z, x1: x + 1, y1: y + 1, z1: z + 1 });
  return out;
}

const off = (b: Box, dx: number, dy: number, dz: number): Box => ({ x0: b.x0 + dx, y0: b.y0 + dy, z0: b.z0 + dz, x1: b.x1 + dx, y1: b.y1 + dy, z1: b.z1 + dz });

function clipX(o: Box, b: Box, d: number) {
  if (o.y1 > b.y0 && o.y0 < b.y1 && o.z1 > b.z0 && o.z0 < b.z1) {
    if (d > 0 && o.x1 <= b.x0 + EPS) d = Math.min(d, b.x0 - o.x1);
    else if (d < 0 && o.x0 >= b.x1 - EPS) d = Math.max(d, b.x1 - o.x0);
  }
  return d;
}
function clipY(o: Box, b: Box, d: number) {
  if (o.x1 > b.x0 && o.x0 < b.x1 && o.z1 > b.z0 && o.z0 < b.z1) {
    if (d > 0 && o.y1 <= b.y0 + EPS) d = Math.min(d, b.y0 - o.y1);
    else if (d < 0 && o.y0 >= b.y1 - EPS) d = Math.max(d, b.y1 - o.y0);
  }
  return d;
}
function clipZ(o: Box, b: Box, d: number) {
  if (o.x1 > b.x0 && o.x0 < b.x1 && o.y1 > b.y0 && o.y0 < b.y1) {
    if (d > 0 && o.z1 <= b.z0 + EPS) d = Math.min(d, b.z0 - o.z1);
    else if (d < 0 && o.z0 >= b.z1 - EPS) d = Math.max(d, b.z1 - o.z0);
  }
  return d;
}

/** Resolves motion with the vanilla axis order: Y first, then the longer of X / Z. */
export function collide(world: World, bb: Box, d: Vec3): Vec3 {
  const area: Box = {
    x0: bb.x0 + Math.min(0, d.x), y0: bb.y0 + Math.min(0, d.y), z0: bb.z0 + Math.min(0, d.z),
    x1: bb.x1 + Math.max(0, d.x), y1: bb.y1 + Math.max(0, d.y), z1: bb.z1 + Math.max(0, d.z),
  };
  const boxes = boxesIn(world, area);
  let cur = bb;
  let dy = d.y;
  for (const b of boxes) dy = clipY(cur, b, dy);
  cur = off(cur, 0, dy, 0);
  let dx = d.x;
  let dz = d.z;
  if (Math.abs(d.x) >= Math.abs(d.z)) {
    for (const b of boxes) dx = clipX(cur, b, dx);
    cur = off(cur, dx, 0, 0);
    for (const b of boxes) dz = clipZ(cur, b, dz);
  } else {
    for (const b of boxes) dz = clipZ(cur, b, dz);
    cur = off(cur, 0, 0, dz);
    for (const b of boxes) dx = clipX(cur, b, dx);
  }
  return { x: dx, y: dy, z: dz };
}

export class Player {
  pos: Vec3;
  prev: Vec3;
  vel: Vec3 = { x: 0, y: 0, z: 0 };
  yaw = 0; // degrees, 0 = facing -Z
  pitch = 0;
  onGround = false;
  hCollide = false;
  sneaking = false;
  sprinting = false;
  inWater = false;
  inLava = false;
  eyesInWater = false;
  flying = false;
  canFly = true;
  fall = 0;
  landedFall = 0;
  private jumpDelay = 0;

  constructor(pos: Vec3) {
    this.pos = { ...pos };
    this.prev = { ...pos };
  }
  get height() {
    return this.sneaking ? SNEAK_HEIGHT : HEIGHT;
  }
  box(at: Vec3 = this.pos): Box {
    return { x0: at.x - W / 2, y0: at.y, z0: at.z - W / 2, x1: at.x + W / 2, y1: at.y + this.height, z1: at.z + W / 2 };
  }
  eye(partial = 1): Vec3 {
    const p = { x: this.prev.x + (this.pos.x - this.prev.x) * partial, y: this.prev.y + (this.pos.y - this.prev.y) * partial, z: this.prev.z + (this.pos.z - this.prev.z) * partial };
    return { x: p.x, y: p.y + (this.sneaking ? SNEAK_EYE : EYE), z: p.z };
  }

  tick(world: World, input: Input) {
    this.prev = { ...this.pos };
    this.sneaking = input.sneak && !this.flying;
    this.sprinting = input.sprint && input.forward > 0 && !input.sneak;
    const mid = world.getBlock(floor(this.pos.x), floor(this.pos.y + this.height * 0.5), floor(this.pos.z));
    this.inWater = mid === WATER;
    this.inLava = mid === LAVA;
    const e = this.eye();
    this.eyesInWater = world.getBlock(floor(e.x), floor(e.y), floor(e.z)) === WATER;
    this.landedFall = 0;
    if (!this.canFly) this.flying = false;
    if (Math.abs(this.vel.x) < 0.003) this.vel.x = 0;
    if (Math.abs(this.vel.y) < 0.003) this.vel.y = 0;
    if (Math.abs(this.vel.z) < 0.003) this.vel.z = 0;
    if (this.jumpDelay > 0) this.jumpDelay--;

    if (this.flying) {
      this.vel.y += ((input.jump ? 1 : 0) - (input.sneak ? 1 : 0)) * 0.15;
    } else if (input.jump) {
      if (this.inWater || this.inLava) this.vel.y += 0.04;
      else if (this.onGround && this.jumpDelay === 0) {
        this.vel.y = JUMP;
        if (this.sprinting) {
          const r = (this.yaw * Math.PI) / 180;
          this.vel.x -= Math.sin(r) * 0.2;
          this.vel.z -= Math.cos(r) * 0.2;
        }
        this.jumpDelay = 10;
      }
    } else this.jumpDelay = 0;

    let fwd = input.forward * 0.98;
    let str = input.strafe * 0.98;
    if (input.sneak && !this.flying) {
      fwd *= 0.3;
      str *= 0.3;
    }
    const below = this.onGround ? world.getBlock(floor(this.pos.x), floor(this.pos.y - 0.500001), floor(this.pos.z)) : 0;
    const friction = this.onGround ? getBlock(below).friction : 1;
    const dragH = friction * 0.91;
    let speed: number;
    if (this.flying) speed = 0.05 * (input.sprint ? 2 : 1);
    else if (this.inWater || this.inLava) speed = 0.02;
    else if (this.onGround) speed = 0.1 * (this.sprinting ? 1.3 : 1) * (0.21600002 / (friction * friction * friction));
    else speed = 0.02 * (this.sprinting ? 1.3 : 1);
    // move relative
    const len2 = fwd * fwd + str * str;
    if (len2 > 1e-7) {
      const n = len2 > 1 ? 1 / Math.sqrt(len2) : 1;
      const r = (this.yaw * Math.PI) / 180;
      const s = Math.sin(r);
      const c = Math.cos(r);
      this.vel.x += (-s * fwd - c * str) * n * speed;
      this.vel.z += (-c * fwd + s * str) * n * speed;
    }

    const delta: Vec3 = { ...this.vel };
    const moved = this.move(world, delta);
    if (moved.y < 0) this.fall -= moved.y;
    if (Math.abs(delta.y - moved.y) > 1e-12) {
      if (delta.y < 0) this.onGround = true;
      this.vel.y = 0;
    } else this.onGround = false;
    if (this.onGround || this.inWater || this.flying) {
      if (this.onGround && !this.inWater && !this.flying) this.landedFall = this.fall;
      this.fall = 0;
    }
    if (this.flying && this.onGround && !input.jump) this.flying = false;
    if (Math.abs(delta.x - moved.x) > 1e-12) this.vel.x = 0;
    if (Math.abs(delta.z - moved.z) > 1e-12) this.vel.z = 0;

    if (this.flying) {
      this.vel.x *= 0.91;
      this.vel.z *= 0.91;
      this.vel.y *= 0.6;
    } else if (this.inLava) {
      this.vel.x *= 0.5;
      this.vel.z *= 0.5;
      this.vel.y = this.vel.y * 0.5 - 0.02;
    } else if (this.inWater) {
      this.vel.x *= 0.8;
      this.vel.z *= 0.8;
      this.vel.y = this.vel.y * 0.8 - 0.02;
    } else {
      this.vel.y = (this.vel.y - GRAVITY) * 0.98;
      this.vel.x *= dragH;
      this.vel.z *= dragH;
    }
  }

  private move(world: World, d: Vec3): Vec3 {
    const bb = this.box();
    let actual = collide(world, bb, d);
    const h = Math.abs(d.x - actual.x) > 1e-12 || Math.abs(d.z - actual.z) > 1e-12;
    this.hCollide = h;
    if (h && (this.onGround || (d.y < 0 && actual.y !== d.y))) {
      const lift = collide(world, bb, { x: 0, y: STEP, z: 0 }).y;
      const raised = off(bb, 0, lift, 0);
      const hz = collide(world, raised, { x: d.x, y: 0, z: d.z });
      const dist = (v: Vec3) => v.x * v.x + v.z * v.z;
      if (dist(hz) > dist(actual)) {
        const after = off(raised, hz.x, 0, hz.z);
        const down = collide(world, after, { x: 0, y: -lift + Math.min(0, d.y), z: 0 });
        actual = { x: hz.x, y: lift + down.y, z: hz.z };
      }
    }
    if (this.sneaking && this.onGround) actual = this.clampEdge(world, actual);
    this.pos.x += actual.x;
    this.pos.y += actual.y;
    this.pos.z += actual.z;
    return actual;
  }

  private clampEdge(world: World, m: Vec3): Vec3 {
    const bb = this.box();
    const step = 0.05;
    const noGround = (dx: number, dz: number) => boxesIn(world, off(bb, dx, -STEP, dz)).length === 0;
    const shrink = (v: number) => (Math.abs(v) <= step ? 0 : v - step * Math.sign(v));
    while (m.x !== 0 && noGround(m.x, 0)) m.x = shrink(m.x);
    while (m.z !== 0 && noGround(0, m.z)) m.z = shrink(m.z);
    while (m.x !== 0 && m.z !== 0 && noGround(m.x, m.z)) {
      m.x = shrink(m.x);
      m.z = shrink(m.z);
    }
    return m;
  }
}

export interface Hit { x: number; y: number; z: number; nx: number; ny: number; nz: number }

/** DDA voxel traversal (port of raycast.rs). */
export function raycast(world: World, o: Vec3, d: Vec3, max: number): Hit | null {
  let x = floor(o.x);
  let y = floor(o.y);
  let z = floor(o.z);
  const sx = Math.sign(d.x);
  const sy = Math.sign(d.y);
  const sz = Math.sign(d.z);
  const tdx = d.x !== 0 ? Math.abs(1 / d.x) : Infinity;
  const tdy = d.y !== 0 ? Math.abs(1 / d.y) : Infinity;
  const tdz = d.z !== 0 ? Math.abs(1 / d.z) : Infinity;
  let tx = d.x > 0 ? (x + 1 - o.x) * tdx : d.x < 0 ? (o.x - x) * tdx : Infinity;
  let ty = d.y > 0 ? (y + 1 - o.y) * tdy : d.y < 0 ? (o.y - y) * tdy : Infinity;
  let tz = d.z > 0 ? (z + 1 - o.z) * tdz : d.z < 0 ? (o.z - z) * tdz : Infinity;
  let nx = 0;
  let ny = 0;
  let nz = 0;
  let t = 0;
  for (let i = 0; i < 200 && t <= max; i++) {
    const b = BLOCKS[world.getBlock(x, y, z)];
    if (b.id !== 0 && !b.liquid) return { x, y, z, nx, ny, nz };
    if (tx < ty && tx < tz) { x += sx; t = tx; tx += tdx; nx = -sx; ny = 0; nz = 0; }
    else if (ty < tz) { y += sy; t = ty; ty += tdy; nx = 0; ny = -sy; nz = 0; }
    else { z += sz; t = tz; tz += tdz; nx = 0; ny = 0; nz = -sz; }
  }
  return null;
}

