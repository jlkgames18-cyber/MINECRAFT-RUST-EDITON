// Port of rng.rs / noise.rs: seeded PRNG + improved Perlin noise with octaves.

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hash2(seed: number, x: number, z: number): number {
  let h = (seed ^ Math.imul(x, 0x9e3779b1) ^ Math.imul(z, 0x85ebca6b)) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x7feb352d);
  h = Math.imul(h ^ (h >>> 15), 0x846ca68b);
  return (h ^ (h >>> 16)) >>> 0;
}

const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
const lerp = (t: number, a: number, b: number) => a + t * (b - a);
function grad(h: number, x: number, y: number, z: number) {
  const u = (h & 15) < 8 ? x : y;
  const v = (h & 15) < 4 ? y : (h & 15) === 12 || (h & 15) === 14 ? x : z;
  return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
}

export class ImprovedNoise {
  private p = new Uint8Array(512);
  private ox: number;
  private oy: number;
  private oz: number;
  constructor(rnd: () => number) {
    this.ox = rnd() * 256;
    this.oy = rnd() * 256;
    this.oz = rnd() * 256;
    const perm = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [perm[i], perm[j]] = [perm[j], perm[i]];
    }
    for (let i = 0; i < 512; i++) this.p[i] = perm[i & 255];
  }
  noise(x: number, y: number, z: number): number {
    x += this.ox;
    y += this.oy;
    z += this.oz;
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const zi = Math.floor(z);
    const X = xi & 255;
    const Y = yi & 255;
    const Z = zi & 255;
    x -= xi;
    y -= yi;
    z -= zi;
    const u = fade(x);
    const v = fade(y);
    const w = fade(z);
    const p = this.p;
    const A = p[X] + Y;
    const AA = p[A] + Z;
    const AB = p[A + 1] + Z;
    const B = p[X + 1] + Y;
    const BA = p[B] + Z;
    const BB = p[B + 1] + Z;
    return lerp(
      w,
      lerp(v, lerp(u, grad(p[AA], x, y, z), grad(p[BA], x - 1, y, z)), lerp(u, grad(p[AB], x, y - 1, z), grad(p[BB], x - 1, y - 1, z))),
      lerp(
        v,
        lerp(u, grad(p[AA + 1], x, y, z - 1), grad(p[BA + 1], x - 1, y, z - 1)),
        lerp(u, grad(p[AB + 1], x, y - 1, z - 1), grad(p[BB + 1], x - 1, y - 1, z - 1)),
      ),
    );
  }
}

export class OctaveNoise {
  private oct: ImprovedNoise[];
  private max = 0;
  constructor(rnd: () => number, octaves: number) {
    this.oct = Array.from({ length: octaves }, () => new ImprovedNoise(rnd));
    let a = 1;
    for (let i = 0; i < octaves; i++) {
      this.max += a;
      a *= 0.5;
    }
  }
  sample(x: number, y: number, z: number): number {
    let f = 1;
    let a = 1;
    let s = 0;
    for (const o of this.oct) {
      s += o.noise(x * f, y * f, z * f) * a;
      f *= 2;
      a *= 0.5;
    }
    return s / this.max;
  }
  sample2d(x: number, z: number) {
    return this.sample(x, 0, z);
  }
}
