// Block registry of the web demo (a 70-block subset of the 415 blocks of the Rust core).
// Flags / hardness / tool tiers mirror block.rs + mining.rs.

export type ToolKind = "none" | "pickaxe" | "axe" | "shovel" | "hoe" | "sword" | "shears";

export interface BlockDef {
  id: number;
  name: string;
  label: string;
  tex: [string, string, string]; // top, bottom, side texture names
  solid: boolean;
  opaque: boolean;
  liquid: boolean;
  translucent: boolean; // goes to the blended mesh
  cross: boolean;
  hardness: number;
  tool: ToolKind;
  tier: number; // minimum tool tier to harvest (0 = hand)
  emissive: boolean;
  friction: number;
}

const defs: BlockDef[] = [];
const byName = new Map<string, BlockDef>();

interface Opts {
  t?: string | [string, string] | [string, string, string];
  solid?: boolean;
  opaque?: boolean;
  liquid?: boolean;
  translucent?: boolean;
  cross?: boolean;
  hard?: number;
  tool?: ToolKind;
  tier?: number;
  emissive?: boolean;
  friction?: number;
}

function add(name: string, label: string, o: Opts = {}) {
  let t: [string, string, string];
  if (!o.t) t = [name, name, name];
  else if (typeof o.t === "string") t = [o.t, o.t, o.t];
  else if (o.t.length === 2) t = [o.t[0], o.t[0], o.t[1]];
  else t = o.t;
  const cross = !!o.cross;
  const d: BlockDef = {
    id: defs.length,
    name,
    label,
    tex: t,
    solid: o.solid ?? !(cross || o.liquid || name === "air"),
    opaque: o.opaque ?? !(cross || o.liquid || o.translucent || name === "air"),
    liquid: !!o.liquid,
    translucent: !!o.translucent || !!o.liquid,
    cross,
    hardness: o.hard ?? 1,
    tool: o.tool ?? "none",
    tier: o.tier ?? 0,
    emissive: !!o.emissive,
    friction: o.friction ?? 0.6,
  };
  defs.push(d);
  byName.set(name, d);
}

add("air", "هواء", { solid: false, opaque: false, hard: 0 });
add("stone", "حجر", { hard: 1.5, tool: "pickaxe", tier: 1 });
add("grass_block", "عشب", { t: ["grass_top", "dirt", "grass_side"], hard: 0.6, tool: "shovel" });
add("dirt", "تراب", { hard: 0.5, tool: "shovel" });
add("cobblestone", "حجر مكسّر", { hard: 2, tool: "pickaxe", tier: 1 });
add("oak_planks", "ألواح بلوط", { hard: 2, tool: "axe" });
add("bedrock", "حجر الأساس", { hard: -1 });
add("water", "ماء", { liquid: true, hard: 100 });
add("sand", "رمل", { hard: 0.5, tool: "shovel" });
add("gravel", "حصى", { hard: 0.6, tool: "shovel" });
add("oak_log", "جذع بلوط", { t: ["log_top", "log_side"], hard: 2, tool: "axe" });
add("oak_leaves", "أوراق بلوط", { opaque: false, hard: 0.2, tool: "hoe" });
add("glass", "زجاج", { translucent: true, opaque: false, hard: 0.3 });
add("deepslate", "أردواز عميق", { t: ["deepslate_top", "deepslate"], hard: 3, tool: "pickaxe", tier: 1 });
add("snow_block", "كتلة ثلج", { t: "snow", hard: 0.2, tool: "shovel" });
add("glowstone", "حجر متوهج", { hard: 0.3, emissive: true });
add("coal_ore", "خام فحم", { hard: 3, tool: "pickaxe", tier: 1 });
add("iron_ore", "خام حديد", { hard: 3, tool: "pickaxe", tier: 2 });
add("gold_ore", "خام ذهب", { hard: 3, tool: "pickaxe", tier: 3 });
add("diamond_ore", "خام ألماس", { hard: 3, tool: "pickaxe", tier: 3 });
add("redstone_ore", "خام ريدستون", { hard: 3, tool: "pickaxe", tier: 3 });
add("obsidian", "سبج", { hard: 50, tool: "pickaxe", tier: 4 });
add("bricks", "طوب", { hard: 2, tool: "pickaxe", tier: 1 });
add("sandstone", "حجر رملي", { t: ["sandstone_top", "sandstone_bottom", "sandstone"], hard: 0.8, tool: "pickaxe", tier: 1 });
add("ice", "جليد", { translucent: true, opaque: false, hard: 0.5, tool: "pickaxe", friction: 0.98 });
add("spruce_log", "جذع صنوبر", { t: ["spruce_log_top", "spruce_log"], hard: 2, tool: "axe" });
add("spruce_leaves", "أوراق صنوبر", { opaque: false, hard: 0.2, tool: "hoe" });
add("birch_log", "جذع بتولا", { t: ["birch_log_top", "birch_log"], hard: 2, tool: "axe" });
add("birch_leaves", "أوراق بتولا", { opaque: false, hard: 0.2, tool: "hoe" });
add("cactus", "صبار", { t: ["cactus_top", "cactus_top", "cactus_side"], opaque: false, hard: 0.4 });
add("crafting_table", "طاولة صناعة", { t: ["crafting_top", "oak_planks", "crafting_side"], hard: 2.5, tool: "axe" });
add("bookshelf", "رف كتب", { t: ["oak_planks", "bookshelf"], hard: 1.5, tool: "axe" });
add("tnt", "تي إن تي", { t: ["tnt_top", "tnt_bottom", "tnt_side"], hard: 0 });
add("white_wool", "صوف أبيض", { hard: 0.8 });
add("red_wool", "صوف أحمر", { hard: 0.8 });
add("blue_wool", "صوف أزرق", { hard: 0.8 });
add("green_wool", "صوف أخضر", { hard: 0.8 });
add("yellow_wool", "صوف أصفر", { hard: 0.8 });
add("lava", "حمم", { liquid: true, hard: 100, emissive: true });
add("mossy_cobblestone", "حجر مكسّر طحلبي", { hard: 2, tool: "pickaxe", tier: 1 });
add("granite", "جرانيت", { hard: 1.5, tool: "pickaxe", tier: 1 });
add("diorite", "ديوريت", { hard: 1.5, tool: "pickaxe", tier: 1 });
add("andesite", "أنديزيت", { hard: 1.5, tool: "pickaxe", tier: 1 });
add("clay", "طين", { hard: 0.6, tool: "shovel" });
add("podzol", "بودزول", { t: ["podzol_top", "dirt", "podzol_side"], hard: 0.5, tool: "shovel" });
add("red_sand", "رمل أحمر", { hard: 0.5, tool: "shovel" });
add("terracotta", "فخار", { hard: 1.25, tool: "pickaxe", tier: 1 });
add("packed_ice", "جليد مضغوط", { hard: 0.5, tool: "pickaxe", friction: 0.98 });
add("pumpkin", "يقطين", { t: ["pumpkin_top", "pumpkin_top", "pumpkin_side"], hard: 1, tool: "axe" });
add("melon", "بطيخ", { t: ["melon_top", "melon_top", "melon_side"], hard: 1, tool: "axe" });
add("hay_block", "حزمة قش", { t: ["hay_top", "hay_side"], hard: 0.5, tool: "hoe" });
add("sea_lantern", "فانوس البحر", { hard: 0.3, emissive: true });
add("copper_ore", "خام نحاس", { hard: 3, tool: "pickaxe", tier: 2 });
add("lapis_ore", "خام لازورد", { hard: 3, tool: "pickaxe", tier: 2 });
add("emerald_ore", "خام زمرد", { hard: 3, tool: "pickaxe", tier: 3 });
add("furnace", "فرن", { t: ["furnace_top", "furnace_top", "furnace_side"], hard: 3.5, tool: "pickaxe", tier: 1 });
add("spruce_planks", "ألواح صنوبر", { hard: 2, tool: "axe" });
add("birch_planks", "ألواح بتولا", { hard: 2, tool: "axe" });
add("short_grass", "عشب قصير", { cross: true, hard: 0 });
add("dandelion", "هندباء", { cross: true, hard: 0 });
add("poppy", "خشخاش", { cross: true, hard: 0 });
add("dead_bush", "شجيرة ميتة", { cross: true, hard: 0 });
add("oak_sapling", "شتلة بلوط", { cross: true, hard: 0 });
add("red_mushroom", "فطر أحمر", { cross: true, hard: 0 });

export const BLOCKS = defs;
export const B = (name: string): number => {
  const d = byName.get(name);
  if (!d) throw new Error("unknown block " + name);
  return d.id;
};
export const blockByName = (name: string) => byName.get(name);
export const getBlock = (id: number): BlockDef => defs[id] ?? defs[0];

// ---- tools (mirrors the item table of item.rs) --------------------------------------
export interface Tool {
  name: string;
  label: string;
  kind: ToolKind;
  tier: number;
  speed: number;
}
export const TOOLS: Tool[] = [
  { name: "hand", label: "اليد", kind: "none", tier: 0, speed: 1 },
  { name: "wooden_pickaxe", label: "معول خشبي", kind: "pickaxe", tier: 1, speed: 2 },
  { name: "stone_pickaxe", label: "معول حجري", kind: "pickaxe", tier: 2, speed: 4 },
  { name: "iron_pickaxe", label: "معول حديدي", kind: "pickaxe", tier: 3, speed: 6 },
  { name: "diamond_pickaxe", label: "معول ألماسي", kind: "pickaxe", tier: 4, speed: 8 },
  { name: "golden_pickaxe", label: "معول ذهبي", kind: "pickaxe", tier: 1, speed: 12 },
  { name: "iron_axe", label: "فأس حديدي", kind: "axe", tier: 3, speed: 6 },
  { name: "iron_shovel", label: "مجرفة حديدية", kind: "shovel", tier: 3, speed: 6 },
];

/** Ticks needed to break (port of mining.rs `break_ticks`); null = unbreakable, 0 = instant. */
export function breakTicks(block: BlockDef, tool: Tool, inWater: boolean, onGround: boolean): number | null {
  if (block.id === 0 || block.hardness < 0) return null;
  if (block.hardness === 0) return 0;
  const matches = tool.kind !== "none" && tool.kind === block.tool;
  const needsTool = block.tool !== "none" && block.tier > 0;
  const canHarvest = !needsTool || (matches && tool.tier >= block.tier);
  let speed = matches ? tool.speed : 1;
  if (inWater) speed /= 5;
  if (!onGround) speed /= 5;
  const damage = speed / block.hardness / (canHarvest ? 30 : 100);
  if (damage >= 1) return 0;
  return Math.ceil(1 / damage);
}
