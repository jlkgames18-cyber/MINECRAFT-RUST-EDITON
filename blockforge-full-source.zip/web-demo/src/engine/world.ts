// World storage, terrain generation (port of worldgen.rs / biome.rs ideas) and greedy-ish face meshing.
import * as THREE from "three";
import { B, BLOCKS, getBlock } from "./blocks";
import { hash2, mulberry32, OctaveNoise } from "./noise";
import { ATLAS_COLS, TILE, getAtlas, textureNames } from "./textures";

export const CH = 16;
export const H = 128;
export const SEA = 46;

export const BIOMES = [
  "المحيط", "الشاطئ", "الصحراء", "السهول", "الغابة", "غابة البتولا", "التايغا", "السهول الثلجية", "الجبال", "القمم المتجمدة",
] as const;
export enum Biome { Ocean, Beach, Desert, Plains, Forest, Birch, Taiga, Snowy, Mountains, Peaks }

export class Chunk {
  blocks = new Uint8Array(CH * H * CH);
  heights = new Uint8Array(CH * CH);
  biomes = new Uint8Array(CH * CH);
  opaque: THREE.Mesh | null = null;
  trans: THREE.Mesh | null = null;
  meshed = false;
  dirty = true;
  constructor(public cx: number, public cz: number) {}
  idx(x: number, y: number, z: number) {
    return (y * CH + z) * CH + x;
  }
  recomputeHeights() {
    for (let z = 0; z < CH; z++)
      for (let x = 0; x < CH; x++) {
        let y = H - 1;
        while (y > 0) {
          const b = this.blocks[this.idx(x, y, z)];
          if (b !== 0 && !BLOCKS[b].cross) break;
          y--;
        }
        this.heights[z * CH + x] = y;
      }
  }
}

const key = (cx: number, cz: number) => (cx + 32768) * 65536 + (cz + 32768);

class Generator {
  continental: OctaveNoise;
  erosion: OctaveNoise;
  detail: OctaveNoise;
  temp: OctaveNoise;
  humid: OctaveNoise;
  weird: OctaveNoise;
  cheese: OctaveNoise;
  spagA: OctaveNoise;
  spagB: OctaveNoise;
  surf: OctaveNoise;
  constructor(public seed: number) {
    const r = mulberry32(seed);
    this.continental = new OctaveNoise(r, 5);
    this.erosion = new OctaveNoise(r, 4);
    this.detail = new OctaveNoise(r, 5);
    this.temp = new OctaveNoise(r, 4);
    this.humid = new OctaveNoise(r, 4);
    this.weird = new OctaveNoise(r, 3);
    this.cheese = new OctaveNoise(r, 3);
    this.spagA = new OctaveNoise(r, 2);
    this.spagB = new OctaveNoise(r, 2);
    this.surf = new OctaveNoise(r, 3);
  }
  height(x: number, z: number): number {
    const c = Math.max(-1, Math.min(1, this.continental.sample2d(x / 520, z / 520) * 2.4));
    const e = Math.max(-1, Math.min(1, this.erosion.sample2d(x / 260 + 1000, z / 260 - 1000) * 2.2));
    const d = this.detail.sample2d(x / 48, z / 48);
    const base = 53 + c * 26;
    const mountain = Math.max(c - 0.3, 0) * 1.43 * (1 - Math.abs(e) * 0.55) * 62;
    return Math.round(Math.min(H - 8, base + mountain + d * (3 + (1 - Math.abs(e)) * 7)));
  }
  biome(x: number, z: number, h: number): Biome {
    const t = Math.max(-1, Math.min(1, this.temp.sample2d(x / 300, z / 300) * 2.3));
    const hm = Math.max(-1, Math.min(1, this.humid.sample2d(x / 260 + 500, z / 260 - 500) * 2.3));
    const above = h - SEA;
    if (above < -1) return Biome.Ocean;
    if (above <= 1) return Biome.Beach;
    if (above > 50) return t < -0.1 ? Biome.Peaks : Biome.Mountains;
    if (above > 30) return t < -0.35 ? Biome.Peaks : Biome.Mountains;
    if (t < -0.45) return hm > 0.15 ? Biome.Taiga : Biome.Snowy;
    if (t < -0.1) return hm > -0.2 ? Biome.Taiga : Biome.Plains;
    if (t < 0.25) return hm < -0.3 ? Biome.Plains : hm < 0.3 ? Biome.Forest : Biome.Birch;
    if (t < 0.5) return hm < -0.2 ? Biome.Desert : hm < 0.2 ? Biome.Plains : Biome.Forest;
    return hm < 0.15 ? Biome.Desert : Biome.Forest;
  }
  top(biome: Biome, h: number, x: number, z: number): [number, number] {
    const n = this.surf.sample2d(x / 12, z / 12) * 2;
    switch (biome) {
      case Biome.Desert: return [B("sand"), B("sandstone")];
      case Biome.Beach: return [B("sand"), B("sandstone")];
      case Biome.Ocean: return n > 0.6 ? [B("clay"), B("clay")] : n < -0.25 ? [B("gravel"), B("gravel")] : [B("sand"), B("sand")];
      case Biome.Snowy: return [B("snow_block"), B("dirt")];
      case Biome.Peaks: return [B("snow_block"), B("stone")];
      case Biome.Mountains: return h > SEA + 38 + n * 4 ? [B("stone"), B("stone")] : [B("grass_block"), B("dirt")];
      case Biome.Taiga: return n > 0.6 ? [B("podzol"), B("dirt")] : [B("grass_block"), B("dirt")];
      default: return [B("grass_block"), B("dirt")];
    }
  }
}

type TreeKind = "oak" | "birch" | "spruce" | "cactus";

export class World {
  chunks = new Map<number, Chunk>();
  gen: Generator;
  constructor(public seed: number) {
    this.gen = new Generator(seed);
  }
  get(cx: number, cz: number) {
    return this.chunks.get(key(cx, cz));
  }
  getBlock(x: number, y: number, z: number): number {
    if (y < 0) return 1;
    if (y >= H) return 0;
    const c = this.chunks.get(key(x >> 4, z >> 4));
    if (!c) return 0;
    return c.blocks[c.idx(x & 15, y, z & 15)];
  }
  getHeight(x: number, z: number): number {
    const c = this.chunks.get(key(x >> 4, z >> 4));
    return c ? c.heights[(z & 15) * CH + (x & 15)] : 0;
  }
  biomeAt(x: number, z: number): Biome {
    const c = this.chunks.get(key(x >> 4, z >> 4));
    return c ? (c.biomes[(z & 15) * CH + (x & 15)] as Biome) : Biome.Plains;
  }
  setBlock(x: number, y: number, z: number, id: number): boolean {
    if (y < 0 || y >= H) return false;
    const c = this.chunks.get(key(x >> 4, z >> 4));
    if (!c) return false;
    const lx = x & 15;
    const lz = z & 15;
    c.blocks[c.idx(lx, y, lz)] = id;
    // update height of the column
    const cur = c.heights[lz * CH + lx];
    const solidish = id !== 0 && !getBlock(id).cross;
    if (solidish && y > cur) c.heights[lz * CH + lx] = y;
    else if (!solidish && y === cur) {
      let yy = y - 1;
      while (yy > 0) {
        const b = c.blocks[c.idx(lx, yy, lz)];
        if (b !== 0 && !BLOCKS[b].cross) break;
        yy--;
      }
      c.heights[lz * CH + lx] = yy;
    }
    c.dirty = true;
    const touch = (cx: number, cz: number) => {
      const n = this.get(cx, cz);
      if (n) n.dirty = true;
    };
    // light changes with the height map: neighbours within 2 cells may be affected
    if (lx <= 1) touch(c.cx - 1, c.cz);
    if (lx >= 14) touch(c.cx + 1, c.cz);
    if (lz <= 1) touch(c.cx, c.cz - 1);
    if (lz >= 14) touch(c.cx, c.cz + 1);
    return true;
  }

  // ------------------------------------------------------------------ generation
  generate(cx: number, cz: number): Chunk {
    const g = this.gen;
    const c = new Chunk(cx, cz);
    const bx = cx * CH;
    const bz = cz * CH;
    const cols: { h: number; b: Biome }[] = [];
    const rnd = mulberry32(hash2(this.seed, cx, cz));
    for (let lz = 0; lz < CH; lz++)
      for (let lx = 0; lx < CH; lx++) {
        const wx = bx + lx;
        const wz = bz + lz;
        const h = g.height(wx, wz);
        const b = g.biome(wx, wz, h);
        cols.push({ h, b });
        c.biomes[lz * CH + lx] = b;
        const [topB, fill] = g.top(b, h, wx, wz);
        const jitter = g.surf.sample2d(wx / 8, wz / 8);
        const dsTop = Math.floor(jitter * 6) + 8;
        const top = Math.max(h, SEA);
        for (let y = 0; y <= top; y++) {
          let id: number;
          if (y === 0) id = B("bedrock");
          else if (y <= 2 && rnd() < 0.55) id = B("bedrock");
          else if (y > h) id = B("water");
          else if (y === h) id = h < SEA && (topB === B("grass_block") || topB === B("snow_block") || topB === B("podzol")) ? B("dirt") : topB;
          else if (y >= h - 3) id = fill;
          else if (y < dsTop) id = B("deepslate");
          else id = B("stone");
          c.blocks[c.idx(lx, y, lz)] = id;
        }
      }
    // caves (cheese caverns + spaghetti tunnels)
    for (let lz = 0; lz < CH; lz++)
      for (let lx = 0; lx < CH; lx++) {
        const col = cols[lz * CH + lx];
        const wx = bx + lx;
        const wz = bz + lz;
        const ocean = col.h < SEA - 1;
        const spagTop = ocean ? col.h - 6 : col.h - 2;
        for (let y = 4; y <= spagTop; y++) {
          const cur = c.blocks[c.idx(lx, y, lz)];
          if (cur === 0 || cur === B("water")) continue;
          let carve = false;
          if (y <= Math.min(col.h - 8, 36)) carve = g.cheese.sample(wx / 30, y / 18, wz / 30) * 1.9 > 0.93 - (36 - y) * 0.002;
          if (!carve) {
            const a = g.spagA.sample(wx / 22, y / 16, wz / 22) * 2;
            if (Math.abs(a) < 0.08) carve = Math.abs(g.spagB.sample(wx / 22 + 100, y / 16, wz / 22 - 100) * 2) < 0.08;
          }
          if (carve) c.blocks[c.idx(lx, y, lz)] = y <= 7 ? B("lava") : 0;
        }
      }
    // ores (ellipsoid veins, port of Rust `vein`)
    const ORES: [string, number, number, number, number][] = [
      ["coal_ore", 18, 17, 6, 100], ["iron_ore", 16, 9, 4, 64], ["copper_ore", 10, 10, 8, 60], ["gold_ore", 3, 9, 4, 30],
      ["redstone_ore", 6, 8, 4, 16], ["lapis_ore", 2, 7, 4, 30], ["diamond_ore", 4, 4, 4, 16], ["dirt", 8, 33, 20, 120],
      ["gravel", 6, 33, 4, 50], ["granite", 6, 33, 10, 70], ["diorite", 6, 33, 10, 70], ["andesite", 6, 33, 10, 70],
    ];
    for (const [name, tries, size, y0, y1] of ORES) {
      const id = B(name);
      for (let t = 0; t < tries; t++) {
        const ox = Math.floor(rnd() * 16);
        const oz = Math.floor(rnd() * 16);
        const oy = y0 + Math.floor(rnd() * (y1 - y0));
        const r = Math.max(1, Math.ceil(Math.cbrt(size)));
        for (let k = 0; k < size * 2; k++) {
          const x = ox + Math.floor(rnd() * (2 * r + 1)) - r;
          const y = oy + Math.floor(rnd() * (2 * r + 1)) - r;
          const z = oz + Math.floor(rnd() * (2 * r + 1)) - r;
          if ((x - ox) ** 2 + (y - oy) ** 2 + (z - oz) ** 2 > r * r + 1 || x < 0 || x > 15 || z < 0 || z > 15 || y < 1 || y >= H) continue;
          const i = c.idx(x, y, z);
          const cur = c.blocks[i];
          if (cur === B("stone") || cur === B("deepslate")) c.blocks[i] = id;
        }
      }
    }
    // ground cover
    for (let t = 0; t < 70; t++) {
      const lx = Math.floor(rnd() * 16);
      const lz = Math.floor(rnd() * 16);
      const col = cols[lz * CH + lx];
      if (col.h <= SEA || col.h >= H - 3) continue;
      const ground = c.blocks[c.idx(lx, col.h, lz)];
      if (c.blocks[c.idx(lx, col.h + 1, lz)] !== 0) continue;
      const r = rnd();
      let plant = -1;
      const grassy = ground === B("grass_block") || ground === B("podzol");
      if (grassy) {
        if (col.b === Biome.Plains) plant = r < 0.6 ? B("short_grass") : r < 0.7 ? B("dandelion") : r < 0.76 ? B("poppy") : -1;
        else if (col.b === Biome.Forest || col.b === Biome.Birch) plant = r < 0.35 ? B("short_grass") : r < 0.4 ? B("poppy") : r < 0.43 ? B("red_mushroom") : -1;
        else if (col.b === Biome.Taiga) plant = r < 0.3 ? B("short_grass") : -1;
        else if (col.b === Biome.Mountains) plant = r < 0.2 ? B("short_grass") : -1;
      } else if (col.b === Biome.Desert && ground === B("sand")) {
        if (r < 0.06) plant = B("dead_bush");
        else if (r < 0.1) {
          for (let k = 1; k <= 1 + Math.floor(rnd() * 3); k++) c.blocks[c.idx(lx, col.h + k, lz)] = B("cactus");
        }
      }
      if (plant >= 0) c.blocks[c.idx(lx, col.h + 1, lz)] = plant;
    }
    // trees from the 3×3 neighbourhood so canopies cross borders (idea of Rust `trees_from_origin`)
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) this.treesFromOrigin(c, cx + dx, cz + dz);
    c.recomputeHeights();
    return c;
  }

  private treesFromOrigin(c: Chunk, ox: number, oz: number) {
    const g = this.gen;
    const r = mulberry32(hash2(this.seed ^ 0x7ee5, ox, oz));
    for (let t = 0; t < 10; t++) {
      const lx = Math.floor(r() * 16);
      const lz = Math.floor(r() * 16);
      const roll = r();
      const pick = r();
      const wx = ox * CH + lx;
      const wz = oz * CH + lz;
      const h = g.height(wx, wz);
      const b = g.biome(wx, wz, h);
      if (h <= SEA || h > SEA + 34) continue;
      let kind: TreeKind | null = null;
      switch (b) {
        case Biome.Forest: if (roll < 0.7) kind = pick < 0.2 ? "birch" : "oak"; break;
        case Biome.Birch: if (roll < 0.65) kind = "birch"; break;
        case Biome.Plains: if (roll < 0.03) kind = "oak"; break;
        case Biome.Taiga: if (roll < 0.55) kind = "spruce"; break;
        case Biome.Snowy: if (roll < 0.06) kind = "spruce"; break;
        case Biome.Mountains: if (roll < 0.12) kind = "spruce"; break;
        default: break;
      }
      if (!kind) continue;
      const [topB] = g.top(b, h, wx, wz);
      if (topB !== B("grass_block") && topB !== B("podzol") && topB !== B("snow_block")) continue;
      if (c.cx * CH > wx + 4 || c.cx * CH + 15 < wx - 4 || c.cz * CH > wz + 4 || c.cz * CH + 15 < wz - 4) continue;
      this.growTree(c, kind, wx, h, wz, mulberry32(hash2(this.seed ^ 0x5a5a, wx, wz)));
    }
  }

  private growTree(c: Chunk, kind: TreeKind, x: number, ground: number, z: number, r: () => number) {
    const put = (px: number, py: number, pz: number, id: number, soft: boolean) => {
      const lx = px - c.cx * CH;
      const lz = pz - c.cz * CH;
      if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || py < 0 || py >= H) return;
      const i = c.idx(lx, py, lz);
      const cur = c.blocks[i];
      if (cur === 0 || BLOCKS[cur].cross || (!soft && BLOCKS[cur].name.endsWith("leaves"))) c.blocks[i] = id;
    };
    const disc = (cy: number, rad: number, id: number, trim: boolean) => {
      for (let dx = -rad; dx <= rad; dx++)
        for (let dz = -rad; dz <= rad; dz++) {
          if (trim && rad >= 2 && Math.abs(dx) === rad && Math.abs(dz) === rad && r() < 0.5) continue;
          put(x + dx, cy, z + dz, id, true);
        }
    };
    if (kind === "oak" || kind === "birch") {
      const h = kind === "birch" ? 5 + Math.floor(r() * 3) : 4 + Math.floor(r() * 3);
      const log = B(kind === "birch" ? "birch_log" : "oak_log");
      const leaf = B(kind === "birch" ? "birch_leaves" : "oak_leaves");
      const top = ground + h;
      for (let dy = -1; dy <= 2; dy++) disc(top + dy, dy >= 1 ? 1 : 2, leaf, true);
      for (let y = ground + 1; y <= top + 1; y++) put(x, y, z, log, false);
    } else if (kind === "spruce") {
      const h = 6 + Math.floor(r() * 4);
      const log = B("spruce_log");
      const leaf = B("spruce_leaves");
      const top = ground + h;
      for (let y = ground + 1; y <= top; y++) put(x, y, z, log, false);
      put(x, top + 1, z, leaf, true);
      const seq = [1, 2, 1, 2, 3, 2, 3, 2, 3];
      for (let i = 0; i < h - 2; i++) {
        const rad = seq[Math.min(i, 8)];
        for (let dx = -rad; dx <= rad; dx++)
          for (let dz = -rad; dz <= rad; dz++) if (dx * dx + dz * dz <= rad * rad + 1 && !(dx === 0 && dz === 0)) put(x + dx, top - i, z + dz, leaf, true);
      }
    }
  }

  // ------------------------------------------------------------------ meshing
  private skyAt(x: number, y: number, z: number): number {
    const h = this.getHeight(x, z);
    if (y > h) return 1;
    return Math.max(0.17, 1 - (h - y) * 0.15);
  }

  buildMesh(c: Chunk, mats: { opaque: THREE.Material; trans: THREE.Material }, scene: THREE.Scene) {
    const atlas = getAtlas();
    const aw = atlas.width;
    const ah = atlas.height;
    const o = { p: [] as number[], u: [] as number[], c: [] as number[], i: [] as number[] };
    const t = { p: [] as number[], u: [] as number[], c: [] as number[], i: [] as number[] };
    const bx = c.cx * CH;
    const bz = c.cz * CH;
    const FACES = [
      { d: [0, 1, 0], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], s: 1.0, t: 0 },
      { d: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], s: 0.5, t: 1 },
      { d: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], s: 0.8, t: 2 },
      { d: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], s: 0.8, t: 2 },
      { d: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], s: 0.66, t: 2 },
      { d: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], s: 0.66, t: 2 },
    ];
    const AO = [0.5, 0.68, 0.84, 1];
    const UV = [[0, 0], [1, 0], [1, 1], [0, 1]];
    const uvRect = (tile: number) => {
      const tx = (tile % ATLAS_COLS) * TILE;
      const ty = Math.floor(tile / ATLAS_COLS) * TILE;
      const e = 0.2;
      return [(tx + e) / aw, 1 - (ty + TILE - e) / ah, (tx + TILE - e) / aw, 1 - (ty + e) / ah];
    };
    const tileOf = (name: string) => textureNames.indexOf(name);
    const rectCache = new Map<string, number[]>();
    const rect = (name: string) => {
      let r = rectCache.get(name);
      if (!r) {
        r = uvRect(tileOf(name));
        rectCache.set(name, r);
      }
      return r;
    };
    let maxY = 0;
    for (let z = 0; z < CH; z++) for (let x = 0; x < CH; x++) maxY = Math.max(maxY, c.heights[z * CH + x]);
    maxY = Math.min(H - 1, Math.max(maxY + 2, SEA + 1));

    const opaqueAt = (x: number, y: number, z: number) => BLOCKS[this.getBlock(x, y, z)].opaque;

    for (let y = 0; y <= maxY; y++) {
      for (let z = 0; z < CH; z++) {
        for (let x = 0; x < CH; x++) {
          const id = c.blocks[c.idx(x, y, z)];
          if (id === 0) continue;
          const b = BLOCKS[id];
          const wx = bx + x;
          const wz = bz + z;
          const out = b.translucent ? t : o;
          if (b.cross) {
            const light = this.skyAt(wx, y, wz);
            const rr = rect(b.tex[2]);
            const diag = [
              [[0, 0, 0], [1, 0, 1], [1, 1, 1], [0, 1, 0]],
              [[1, 0, 0], [0, 0, 1], [0, 1, 1], [1, 1, 0]],
            ];
            for (const q of diag)
              for (const flip of [false, true]) {
                const base = out.p.length / 3;
                for (let k = 0; k < 4; k++) {
                  out.p.push(wx + q[k][0], y + q[k][1], wz + q[k][2]);
                  out.u.push(UV[k][0] ? rr[2] : rr[0], UV[k][1] ? rr[3] : rr[1]);
                  const s = 0.9 * light;
                  out.c.push(s, s, s);
                }
                if (flip) out.i.push(base, base + 3, base + 2, base, base + 2, base + 1);
                else out.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
              }
            continue;
          }
          const cullSame = b.translucent || b.name.endsWith("leaves");
          for (const f of FACES) {
            const nx = wx + f.d[0];
            const ny = y + f.d[1];
            const nz = wz + f.d[2];
            const nid = this.getBlock(nx, ny, nz);
            const nb = BLOCKS[nid];
            if (nb.opaque) continue;
            if (nid === id && cullSame) continue;
            if (b.liquid && nb.liquid) continue;
            const light = b.emissive ? 1 : this.skyAt(nx, ny, nz);
            const rr = rect(b.tex[f.t]);
            // axes for AO
            const ax = f.d[0] !== 0 ? 0 : f.d[1] !== 0 ? 1 : 2;
            const ua = (ax + 1) % 3;
            const va = (ax + 2) % 3;
            const ao: number[] = [];
            for (let k = 0; k < 4; k++) {
              const cu = f.c[k][ua] * 2 - 1;
              const cv = f.c[k][va] * 2 - 1;
              const p1 = [nx, ny, nz];
              const p2 = [nx, ny, nz];
              const p3 = [nx, ny, nz];
              p1[ua] += cu;
              p2[va] += cv;
              p3[ua] += cu;
              p3[va] += cv;
              const s1 = opaqueAt(p1[0], p1[1], p1[2]) ? 1 : 0;
              const s2 = opaqueAt(p2[0], p2[1], p2[2]) ? 1 : 0;
              const s3 = opaqueAt(p3[0], p3[1], p3[2]) ? 1 : 0;
              ao.push(s1 && s2 ? 0 : 3 - (s1 + s2 + s3));
            }
            const base = out.p.length / 3;
            for (let k = 0; k < 4; k++) {
              let py = f.c[k][1];
              if (b.liquid && py === 1 && this.getBlock(wx, y + 1, wz) !== id) py = 0.88;
              out.p.push(wx + f.c[k][0], y + py, wz + f.c[k][2]);
              out.u.push(UV[k][0] ? rr[2] : rr[0], UV[k][1] ? rr[3] : rr[1]);
              const s = (b.emissive ? 1 : f.s) * AO[ao[k]] * light;
              out.c.push(s, s, s);
            }
            if (ao[0] + ao[2] >= ao[1] + ao[3]) out.i.push(base, base + 1, base + 2, base, base + 2, base + 3);
            else out.i.push(base + 1, base + 2, base + 3, base + 1, base + 3, base);
          }
        }
      }
    }
    const make = (d: typeof o, mat: THREE.Material, old: THREE.Mesh | null, order: number) => {
      if (old) {
        scene.remove(old);
        old.geometry.dispose();
      }
      if (d.i.length === 0) return null;
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.Float32BufferAttribute(d.p, 3));
      geo.setAttribute("uv", new THREE.Float32BufferAttribute(d.u, 2));
      geo.setAttribute("color", new THREE.Float32BufferAttribute(d.c, 3));
      geo.setIndex(d.i);
      geo.computeBoundingSphere();
      const m = new THREE.Mesh(geo, mat);
      m.renderOrder = order;
      m.frustumCulled = true;
      scene.add(m);
      return m;
    };
    c.opaque = make(o, mats.opaque, c.opaque, 0);
    c.trans = make(t, mats.trans, c.trans, 1);
    c.meshed = true;
    c.dirty = false;
  }

  disposeChunk(c: Chunk, scene: THREE.Scene) {
    for (const m of [c.opaque, c.trans]) {
      if (m) {
        scene.remove(m);
        m.geometry.dispose();
      }
    }
    this.chunks.delete(key(c.cx, c.cz));
  }
  addChunk(c: Chunk) {
    this.chunks.set(key(c.cx, c.cz), c);
  }
}
