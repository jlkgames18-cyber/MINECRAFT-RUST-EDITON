// The playable demo: three.js renderer + streaming world + player + building / mining + day-night cycle.
import * as THREE from "three";
import { B, TOOLS, blockByName, breakTicks, getBlock } from "./blocks";
import { Input, Player, raycast } from "./physics";
import { getAtlas } from "./textures";
import { BIOMES, CH, H, SEA, World } from "./world";

export interface HudState {
  fps: number;
  x: number;
  y: number;
  z: number;
  biome: string;
  time: string;
  chunks: number;
  mode: "creative" | "survival";
  locked: boolean;
  progress: number;
  tool: string;
  hotbar: number[];
  selected: number;
  flying: boolean;
  underwater: boolean;
  loading: boolean;
  target: string;
  seed: number;
}

export interface Hooks {
  onHud: (s: HudState) => void;
  onUi: (what: "chat" | "inventory" | "command") => void;
}

const DAY = 24000;

/** Port of lighting.rs `sky_brightness` (0.2..1.0). */
export function skyBrightness(dayTime: number): number {
  const t = ((dayTime + 18000) % DAY) / DAY;
  let a = 1 - (Math.cos(t * Math.PI * 2) * 2 + 0.2);
  a = Math.min(1, Math.max(0, a));
  return 0.2 + (1 - a) * 0.8;
}

export class Game {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(75, 1, 0.05, 600);
  world: World;
  player: Player;
  seed: number;
  viewDist = 6;
  survival = false;
  hotbar = [B("stone"), B("grass_block"), B("dirt"), B("oak_planks"), B("oak_log"), B("glass"), B("bricks"), B("glowstone"), B("tnt")];
  selected = 0;
  toolIndex = 0;
  dayTime = 1000;
  timeRunning = true;

  private mats: { opaque: THREE.MeshBasicMaterial; trans: THREE.MeshBasicMaterial };
  private keys = new Set<string>();
  private locked = false;
  private raf = 0;
  private last = performance.now();
  private acc = 0;
  private frames = 0;
  private fpsTimer = 0;
  private fps = 0;
  private hudTimer = 0;
  private mouseDown = [false, false, false];
  private mining: { x: number; y: number; z: number; ticks: number; total: number } | null = null;
  private placeCooldown = 0;
  private lastSpace = 0;
  private lastW = 0;
  private ready = false;
  private highlight: THREE.LineSegments;
  private crack: THREE.Mesh;
  private sun: THREE.Mesh;
  private moon: THREE.Mesh;
  private stars: THREE.Points;
  private target: ReturnType<typeof raycast> = null;
  private uiOpen = false;
  private disposed = false;
  private offsets: [number, number][] = [];
  private lastChunkKey = "";
  private skyColor = new THREE.Color();

  constructor(private canvas: HTMLCanvasElement, private host: HTMLElement, private hooks: Hooks, seed = 20240611) {
    this.seed = seed;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    const tex = new THREE.CanvasTexture(getAtlas());
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = false;
    this.mats = {
      opaque: new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, alphaTest: 0.5 }),
      trans: new THREE.MeshBasicMaterial({ map: tex, vertexColors: true, transparent: true, depthWrite: false }),
    };
    this.scene.fog = new THREE.Fog(0x88bbee, 20, 90);
    this.world = new World(seed);
    this.player = new Player(this.findSpawn());
    this.player.canFly = true;

    const box = new THREE.BoxGeometry(1.004, 1.004, 1.004);
    this.highlight = new THREE.LineSegments(new THREE.EdgesGeometry(box), new THREE.LineBasicMaterial({ color: 0x000000 }));
    this.highlight.visible = false;
    this.scene.add(this.highlight);
    this.crack = new THREE.Mesh(box, new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0, depthWrite: false }));
    this.crack.visible = false;
    this.scene.add(this.crack);

    const disc = (color: number, size: number) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshBasicMaterial({ color, fog: false, side: THREE.DoubleSide }));
      this.scene.add(m);
      return m;
    };
    this.sun = disc(0xfff2b0, 60);
    this.moon = disc(0xdfe8ff, 40);
    const sp: number[] = [];
    for (let i = 0; i < 500; i++) {
      const u = Math.random() * 2 - 1;
      const a = Math.random() * Math.PI * 2;
      const s = Math.sqrt(1 - u * u);
      sp.push(Math.cos(a) * s * 450, u * 450, Math.sin(a) * s * 450);
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.Float32BufferAttribute(sp, 3));
    this.stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, fog: false }));
    this.scene.add(this.stars);

    this.rebuildOffsets();
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    document.addEventListener("pointerlockchange", this.onLockChange);
    canvas.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    window.addEventListener("mousemove", this.onMouseMove);
    canvas.addEventListener("wheel", this.onWheel, { passive: true });
    canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(host);
    this.ro = ro;
    this.resize();
    this.last = performance.now();
    this.loop();
  }
  private ro: ResizeObserver;

  // ---------------------------------------------------------------- setup helpers
  private findSpawn() {
    const g = this.world.gen;
    for (let r = 0; r < 800; r += 8) {
      for (let a = 0; a < Math.max(1, r / 4); a++) {
        const ang = (a / Math.max(1, r / 4)) * Math.PI * 2;
        const x = Math.round(Math.cos(ang) * r) + 8;
        const z = Math.round(Math.sin(ang) * r) + 8;
        const h = g.height(x, z);
        if (h > SEA + 2 && h < SEA + 22) return { x: x + 0.5, y: h + 2, z: z + 0.5 };
      }
    }
    return { x: 8.5, y: SEA + 20, z: 8.5 };
  }
  private rebuildOffsets() {
    const v = this.viewDist;
    const o: [number, number][] = [];
    for (let dx = -v; dx <= v; dx++) for (let dz = -v; dz <= v; dz++) if (dx * dx + dz * dz <= v * v + v) o.push([dx, dz]);
    o.sort((a, b) => a[0] * a[0] + a[1] * a[1] - (b[0] * b[0] + b[1] * b[1]));
    this.offsets = o;
    (this.scene.fog as THREE.Fog).far = Math.max(40, v * CH * 0.95);
    this.lastChunkKey = "";
  }
  setViewDistance(v: number) {
    this.viewDist = v;
    this.rebuildOffsets();
  }
  private resize() {
    const w = this.host.clientWidth || 800;
    const h = this.host.clientHeight || 450;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  requestLock() {
    this.canvas.requestPointerLock?.();
  }
  setUiOpen(open: boolean) {
    this.uiOpen = open;
    if (open) {
      this.keys.clear();
      this.mouseDown = [false, false, false];
      this.mining = null;
      if (document.pointerLockElement) document.exitPointerLock();
    }
  }
  resetWorld(seed: number) {
    for (const c of [...this.world.chunks.values()]) this.world.disposeChunk(c, this.scene);
    this.seed = seed;
    this.world = new World(seed);
    const s = this.findSpawn();
    this.player = new Player(s);
    this.player.canFly = true;
    this.ready = false;
    this.lastChunkKey = "";
  }

  // ---------------------------------------------------------------- input
  private onKeyDown = (e: KeyboardEvent) => {
    if (this.uiOpen) return;
    if (!this.locked) return;
    const k = e.code;
    if (k === "KeyE") {
      this.hooks.onUi("inventory");
      e.preventDefault();
      return;
    }
    if (k === "Enter") {
      this.hooks.onUi("chat");
      e.preventDefault();
      return;
    }
    if (k === "Slash") {
      this.hooks.onUi("command");
      e.preventDefault();
      return;
    }
    if (k.startsWith("Digit") && k !== "Digit0") this.selected = parseInt(k.slice(5)) - 1;
    if (k === "KeyG") this.survival = !this.survival;
    if (k === "KeyR") this.toolIndex = (this.toolIndex + 1) % TOOLS.length;
    if (k === "KeyP") this.timeRunning = !this.timeRunning;
    const now = performance.now();
    if (k === "Space" && !e.repeat) {
      if (now - this.lastSpace < 280 && !this.survival) this.player.flying = !this.player.flying;
      this.lastSpace = now;
    }
    if (k === "KeyW" && !e.repeat) {
      if (now - this.lastW < 280) this.keys.add("Sprint");
      this.lastW = now;
    }
    if (["Space", "ArrowUp", "ArrowDown"].includes(k)) e.preventDefault();
    this.keys.add(k);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    if (e.code === "KeyW") this.keys.delete("Sprint");
  };
  private onLockChange = () => {
    this.locked = document.pointerLockElement === this.canvas;
    if (!this.locked) {
      this.keys.clear();
      this.mouseDown = [false, false, false];
      this.mining = null;
    }
  };
  private onMouseDown = (e: MouseEvent) => {
    if (!this.locked) {
      if (!this.uiOpen) this.requestLock();
      return;
    }
    this.mouseDown[e.button] = true;
    if (e.button === 0) this.mining = null;
    if (e.button === 2) this.placeCooldown = 0;
    if (e.button === 1 && this.target) {
      const id = this.world.getBlock(this.target.x, this.target.y, this.target.z);
      if (id) this.hotbar[this.selected] = id;
    }
  };
  private onMouseUp = (e: MouseEvent) => {
    this.mouseDown[e.button] = false;
    if (e.button === 0) this.mining = null;
  };
  private onMouseMove = (e: MouseEvent) => {
    if (!this.locked) return;
    this.player.yaw -= e.movementX * 0.12;
    this.player.pitch = Math.max(-89.5, Math.min(89.5, this.player.pitch - e.movementY * 0.12));
  };
  private onWheel = (e: WheelEvent) => {
    this.selected = (this.selected + (e.deltaY > 0 ? 1 : -1) + 9) % 9;
  };

  // ---------------------------------------------------------------- commands
  runCommand(line: string): string[] {
    const a = line.trim().replace(/^\//, "").split(/\s+/);
    const p = this.player;
    const num = (s: string, base: number) => (s.startsWith("~") ? base + (s.length > 1 ? parseFloat(s.slice(1)) : 0) : parseFloat(s));
    switch (a[0]) {
      case "help":
        return ["/gamemode <creative|survival>", "/time set <day|noon|night|midnight|N> · /time query", "/tp <x> <y> <z>", "/give <block>", "/setblock <x> <y> <z> <block>", "/fill x1 y1 z1 x2 y2 z2 <block>", "/fly · /seed · /pos · /view <2-10> · /speed", "/newworld [seed]"];
      case "gamemode":
      case "gm":
        if (a[1] === "creative" || a[1] === "c") this.survival = false;
        else if (a[1] === "survival" || a[1] === "s") this.survival = true;
        else return ["usage: /gamemode <creative|survival>"];
        return ["Game mode: " + (this.survival ? "survival" : "creative")];
      case "time": {
        if (a[1] === "set") {
          const named: Record<string, number> = { day: 1000, noon: 6000, sunset: 12000, night: 13000, midnight: 18000, sunrise: 23000 };
          const v = named[a[2]] ?? parseInt(a[2]);
          if (Number.isNaN(v)) return ["unknown time"];
          this.dayTime = Math.floor(this.dayTime / DAY) * DAY + (v % DAY);
          return ["Time set to " + v];
        }
        return [`day ${Math.floor(this.dayTime / DAY)} · ${Math.floor(this.dayTime % DAY)}`];
      }
      case "tp": {
        if (a.length < 4) return ["usage: /tp x y z"];
        const [x, y, z] = [num(a[1], p.pos.x), num(a[2], p.pos.y), num(a[3], p.pos.z)];
        if ([x, y, z].some(Number.isNaN)) return ["bad coordinates"];
        p.pos = { x, y: Math.max(1, Math.min(H + 20, y)), z };
        p.prev = { ...p.pos };
        p.vel = { x: 0, y: 0, z: 0 };
        this.ready = false;
        return ["Teleported"];
      }
      case "fly":
        if (this.survival) return ["flight needs creative mode"];
        p.flying = !p.flying;
        return ["flying: " + p.flying];
      case "seed":
        return ["Seed: " + this.seed];
      case "pos":
        return [`${p.pos.x.toFixed(2)} ${p.pos.y.toFixed(2)} ${p.pos.z.toFixed(2)}`];
      case "view": {
        const v = parseInt(a[1]);
        if (!(v >= 2 && v <= 10)) return ["usage: /view 2..10"];
        this.setViewDistance(v);
        return ["View distance " + v];
      }
      case "give": {
        const b = blockByName((a[1] ?? "").replace("minecraft:", ""));
        if (!b || b.id === 0) return ["unknown block '" + (a[1] ?? "") + "'"];
        this.hotbar[this.selected] = b.id;
        return ["Gave " + b.name];
      }
      case "setblock": {
        if (a.length < 5) return ["usage: /setblock x y z block"];
        const b = blockByName(a[4].replace("minecraft:", ""));
        if (!b) return ["unknown block"];
        const ok = this.world.setBlock(Math.floor(num(a[1], p.pos.x)), Math.floor(num(a[2], p.pos.y)), Math.floor(num(a[3], p.pos.z)), b.id);
        return [ok ? "Block placed" : "chunk not loaded / out of range"];
      }
      case "fill": {
        if (a.length < 8) return ["usage: /fill x1 y1 z1 x2 y2 z2 block"];
        const c = [1, 2, 3, 4, 5, 6].map((i) => Math.floor(num(a[i], [p.pos.x, p.pos.y, p.pos.z][(i - 1) % 3])));
        const b = blockByName(a[7].replace("minecraft:", ""));
        if (!b) return ["unknown block"];
        const vol = (Math.abs(c[3] - c[0]) + 1) * (Math.abs(c[4] - c[1]) + 1) * (Math.abs(c[5] - c[2]) + 1);
        if (vol > 32768) return ["too many blocks (" + vol + " > 32768)"];
        let n = 0;
        for (let x = Math.min(c[0], c[3]); x <= Math.max(c[0], c[3]); x++)
          for (let y = Math.min(c[1], c[4]); y <= Math.max(c[1], c[4]); y++)
            for (let z = Math.min(c[2], c[5]); z <= Math.max(c[2], c[5]); z++) if (this.world.setBlock(x, y, z, b.id)) n++;
        return [n + " blocks filled"];
      }
      case "newworld": {
        const s = a[1] ? parseInt(a[1]) || [...a[1]].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) | 0, 7) : Math.floor(Math.random() * 1e9);
        this.resetWorld(s);
        return ["New world, seed " + s];
      }
      default:
        return ["unknown command '/" + a[0] + "' — try /help"];
    }
  }

  // ---------------------------------------------------------------- main loop
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(250, now - this.last);
    this.last = now;
    this.frames++;
    this.fpsTimer += dt;
    if (this.fpsTimer >= 500) {
      this.fps = Math.round((this.frames * 1000) / this.fpsTimer);
      this.frames = 0;
      this.fpsTimer = 0;
    }
    this.streamChunks();
    this.acc += dt;
    let steps = 0;
    while (this.acc >= 50 && steps < 5) {
      this.acc -= 50;
      steps++;
      this.tick();
    }
    if (steps === 5) this.acc = 0;
    this.render(this.acc / 50);
    this.hudTimer += dt;
    if (this.hudTimer > 100) {
      this.hudTimer = 0;
      this.emitHud();
    }
  };

  private inputState(): Input {
    const k = this.keys;
    return {
      forward: (k.has("KeyW") ? 1 : 0) - (k.has("KeyS") ? 1 : 0),
      strafe: (k.has("KeyA") ? 1 : 0) - (k.has("KeyD") ? 1 : 0),
      jump: k.has("Space"),
      sneak: k.has("ShiftLeft") || k.has("ShiftRight"),
      sprint: k.has("ControlLeft") || k.has("Sprint"),
    };
  }

  private tick() {
    if (!this.ready) {
      const p = this.player.pos;
      const cx = Math.floor(p.x) >> 4;
      const cz = Math.floor(p.z) >> 4;
      let ok = true;
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) if (!this.world.get(cx + dx, cz + dz)) ok = false;
      const c = this.world.get(cx, cz);
      if (ok && c) {
        // drop the player onto the surface when (re)spawning
        if (this.player.pos.y > c.heights[(Math.floor(p.z) & 15) * CH + (Math.floor(p.x) & 15)] + 3) {
          this.player.pos.y = c.heights[(Math.floor(p.z) & 15) * CH + (Math.floor(p.x) & 15)] + 2;
          this.player.prev = { ...this.player.pos };
        }
        this.ready = true;
      }
      return;
    }
    if (this.timeRunning) this.dayTime += 1;
    this.player.canFly = !this.survival;
    this.player.tick(this.world, this.uiOpen || !this.locked ? { forward: 0, strafe: 0, jump: false, sneak: false, sprint: false } : this.inputState());
    if (this.player.pos.y < -30) {
      this.player.pos.y = SEA + 40;
      this.player.vel.y = 0;
    }
    // fall damage is only reported in the HUD (survival health is out of scope for the demo)
    this.interact();
  }

  private currentTool() {
    return this.survival ? TOOLS[this.toolIndex] : TOOLS[0];
  }

  private interact() {
    const p = this.player;
    const e = p.eye();
    const yaw = (p.yaw * Math.PI) / 180;
    const pitch = (p.pitch * Math.PI) / 180;
    const dir = { x: -Math.sin(yaw) * Math.cos(pitch), y: Math.sin(pitch), z: -Math.cos(yaw) * Math.cos(pitch) };
    this.target = this.locked && !this.uiOpen ? raycast(this.world, e, dir, this.survival ? 4.5 : 5) : null;
    if (this.placeCooldown > 0) this.placeCooldown--;
    const t = this.target;
    if (!t) {
      this.mining = null;
      return;
    }
    // break
    if (this.mouseDown[0]) {
      const id = this.world.getBlock(t.x, t.y, t.z);
      const b = getBlock(id);
      const total = this.survival ? breakTicks(b, this.currentTool(), p.inWater, p.onGround || p.inWater) : b.id === B("bedrock") ? null : 0;
      if (total === null) {
        this.mining = null;
      } else if (total === 0) {
        if (this.placeCooldown === 0) {
          this.world.setBlock(t.x, t.y, t.z, 0);
          this.placeCooldown = 4;
        }
        this.mining = null;
      } else {
        if (!this.mining || this.mining.x !== t.x || this.mining.y !== t.y || this.mining.z !== t.z) this.mining = { x: t.x, y: t.y, z: t.z, ticks: 0, total };
        this.mining.ticks++;
        if (this.mining.ticks >= this.mining.total) {
          this.world.setBlock(t.x, t.y, t.z, 0);
          this.mining = null;
        }
      }
    } else this.mining = null;
    // place
    if (this.mouseDown[2] && this.placeCooldown === 0) {
      const px = t.x + t.nx;
      const py = t.y + t.ny;
      const pz = t.z + t.nz;
      const cur = getBlock(this.world.getBlock(px, py, pz));
      const id = this.hotbar[this.selected];
      if ((cur.id === 0 || cur.liquid || cur.cross) && py >= 0 && py < H) {
        const nb = getBlock(id);
        const pb = p.box();
        const hitsPlayer = nb.solid && px + 1 > pb.x0 && px < pb.x1 && py + 1 > pb.y0 && py < pb.y1 && pz + 1 > pb.z0 && pz < pb.z1;
        if (!hitsPlayer) {
          this.world.setBlock(px, py, pz, id);
          this.placeCooldown = 4;
        }
      }
    }
  }

  private streamChunks() {
    const p = this.player.pos;
    const pcx = Math.floor(p.x) >> 4;
    const pcz = Math.floor(p.z) >> 4;
    const start = performance.now();
    // 1. generate (closest first) within a time budget
    let gen = 0;
    for (const [dx, dz] of this.offsets) {
      const cx = pcx + dx;
      const cz = pcz + dz;
      if (this.world.get(cx, cz)) continue;
      this.world.addChunk(this.world.generate(cx, cz));
      gen++;
      if (performance.now() - start > (this.ready ? 5 : 40) || gen >= (this.ready ? 2 : 12)) break;
    }
    // neighbours of a new chunk need re-meshing (border faces / light)
    // 2. unload far chunks
    const far = this.viewDist + 2;
    const key = pcx + "," + pcz + "," + this.world.chunks.size;
    if (key !== this.lastChunkKey) {
      this.lastChunkKey = key;
      for (const c of [...this.world.chunks.values()]) if (Math.max(Math.abs(c.cx - pcx), Math.abs(c.cz - pcz)) > far) this.world.disposeChunk(c, this.scene);
    }
    // 3. mesh: closest dirty chunk whose 3×3 neighbourhood is loaded
    const t1 = performance.now();
    let meshed = 0;
    for (const [dx, dz] of this.offsets) {
      const c = this.world.get(pcx + dx, pcz + dz);
      if (!c || (!c.dirty && c.meshed)) continue;
      let all = true;
      for (let ax = -1; ax <= 1 && all; ax++) for (let az = -1; az <= 1; az++) if (!this.world.get(c.cx + ax, c.cz + az)) { all = false; break; }
      if (!all) continue;
      this.world.buildMesh(c, this.mats, this.scene);
      meshed++;
      if (performance.now() - t1 > (this.ready ? 6 : 30) || meshed >= (this.ready ? 2 : 8)) break;
    }
  }

  private render(partial: number) {
    const p = this.player;
    const e = p.eye(partial);
    this.camera.position.set(e.x, e.y, e.z);
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = (p.yaw * Math.PI) / 180;
    this.camera.rotation.x = (p.pitch * Math.PI) / 180;
    const targetFov = p.sprinting ? 82 : 75;
    this.camera.fov += (targetFov - this.camera.fov) * 0.2;
    this.camera.updateProjectionMatrix();

    // day / night
    const b = skyBrightness(this.dayTime);
    const day = new THREE.Color(0x8ec5f5);
    const night = new THREE.Color(0x050914);
    const tod = this.dayTime % DAY;
    this.skyColor.copy(night).lerp(day, (b - 0.2) / 0.8);
    const dusk = Math.max(0, 1 - Math.abs(tod - 12800) / 1200, 1 - Math.abs(((tod + 12000) % DAY) - 12800) / 1200);
    if (dusk > 0) this.skyColor.lerp(new THREE.Color(0xf08a4b), dusk * 0.55);
    const under = p.eyesInWater;
    const fog = this.scene.fog as THREE.Fog;
    if (under) {
      this.skyColor.set(0x1c3f8f).multiplyScalar(0.35 + b * 0.65);
      fog.near = 0.1;
      fog.far = 26;
    } else {
      fog.near = Math.max(8, this.viewDist * CH * 0.45);
      fog.far = Math.max(40, this.viewDist * CH * 0.95);
    }
    fog.color.copy(this.skyColor);
    this.scene.background = this.skyColor;
    const tint = 0.24 + 0.76 * ((b - 0.2) / 0.8);
    this.mats.opaque.color.setScalar(tint);
    this.mats.trans.color.setScalar(tint);

    const ang = Math.PI / 2 + (((tod + 18000) % DAY) / DAY) * Math.PI * 2;
    const cp = this.camera.position;
    this.sun.position.set(cp.x + Math.cos(ang) * 320, cp.y + Math.sin(ang) * 320, cp.z + 40);
    this.moon.position.set(cp.x - Math.cos(ang) * 320, cp.y - Math.sin(ang) * 320, cp.z - 40);
    this.sun.lookAt(cp);
    this.moon.lookAt(cp);
    this.sun.visible = !under;
    this.moon.visible = !under;
    this.stars.position.copy(cp);
    (this.stars.material as THREE.PointsMaterial).opacity = under ? 0 : Math.max(0, 1 - (b - 0.2) / 0.5);
    this.stars.rotation.z = ang * 0.5;

    // selection box + crack overlay
    if (this.target) {
      this.highlight.visible = true;
      this.highlight.position.set(this.target.x + 0.5, this.target.y + 0.5, this.target.z + 0.5);
    } else this.highlight.visible = false;
    if (this.mining) {
      this.crack.visible = true;
      this.crack.position.set(this.mining.x + 0.5, this.mining.y + 0.5, this.mining.z + 0.5);
      (this.crack.material as THREE.MeshBasicMaterial).opacity = (this.mining.ticks / this.mining.total) * 0.7;
    } else this.crack.visible = false;

    this.renderer.render(this.scene, this.camera);
  }

  private emitHud() {
    const p = this.player;
    const tod = Math.floor(this.dayTime % DAY);
    const hh = Math.floor(((tod / 1000 + 6) % 24));
    const mm = Math.floor(((tod % 1000) / 1000) * 60);
    const t = this.target ? getBlock(this.world.getBlock(this.target.x, this.target.y, this.target.z)) : null;
    this.hooks.onHud({
      fps: this.fps,
      x: p.pos.x,
      y: p.pos.y,
      z: p.pos.z,
      biome: BIOMES[this.world.biomeAt(Math.floor(p.pos.x), Math.floor(p.pos.z))] ?? "—",
      time: `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`,
      chunks: this.world.chunks.size,
      mode: this.survival ? "survival" : "creative",
      locked: this.locked,
      progress: this.mining ? this.mining.ticks / this.mining.total : 0,
      tool: this.currentTool().label,
      hotbar: [...this.hotbar],
      selected: this.selected,
      flying: p.flying,
      underwater: p.eyesInWater,
      loading: !this.ready,
      target: t ? t.label : "",
      seed: this.seed,
    });
  }

  setHotbarBlock(slot: number, id: number) {
    this.hotbar[slot] = id;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    window.removeEventListener("mouseup", this.onMouseUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    this.ro.disconnect();
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
    for (const c of [...this.world.chunks.values()]) this.world.disposeChunk(c, this.scene);
    this.renderer.dispose();
  }
}

