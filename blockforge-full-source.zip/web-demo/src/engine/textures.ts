// Procedural 16×16 texture atlas (no image assets needed) – every tile is drawn from seeded noise.
import { BLOCKS } from "./blocks";
import { mulberry32 } from "./noise";

export const TILE = 16;
export const ATLAS_COLS = 16;

type RGB = [number, number, number];
type Style =
  | "plain" | "ore" | "grass_side" | "log_side" | "log_top" | "planks" | "bricks" | "leaves" | "glass"
  | "cross" | "tnt_side" | "books" | "crafting_side" | "crafting_top" | "furnace_side" | "furnace_top"
  | "cactus_side" | "water" | "lava" | "ice" | "stripes" | "pumpkin_side" | "melon_side" | "glow" | "deepslate" | "podzol_side" | "sandstone";

interface Def {
  base: RGB;
  v?: number; // brightness variance
  style?: Style;
  spec?: RGB;
  alpha?: number;
}

const D: Record<string, Def> = {
  stone: { base: [125, 125, 125], v: 14 },
  grass_top: { base: [96, 160, 58], v: 16 },
  dirt: { base: [134, 96, 67], v: 14 },
  grass_side: { base: [134, 96, 67], v: 14, style: "grass_side", spec: [96, 160, 58] },
  cobblestone: { base: [118, 118, 118], v: 26 },
  oak_planks: { base: [162, 130, 78], v: 8, style: "planks" },
  spruce_planks: { base: [114, 84, 48], v: 8, style: "planks" },
  birch_planks: { base: [196, 178, 122], v: 8, style: "planks" },
  bedrock: { base: [60, 60, 60], v: 30 },
  water: { base: [48, 92, 220], v: 10, style: "water", alpha: 0.62 },
  sand: { base: [219, 207, 163], v: 9 },
  gravel: { base: [131, 127, 126], v: 30 },
  log_side: { base: [102, 81, 50], v: 10, style: "log_side" },
  log_top: { base: [158, 128, 78], v: 8, style: "log_top" },
  spruce_log: { base: [58, 40, 22], v: 8, style: "log_side" },
  spruce_log_top: { base: [112, 84, 48], v: 8, style: "log_top" },
  birch_log: { base: [216, 214, 205], v: 8, style: "log_side", spec: [40, 40, 40] },
  birch_log_top: { base: [196, 178, 122], v: 8, style: "log_top" },
  oak_leaves: { base: [58, 130, 36], v: 22, style: "leaves" },
  spruce_leaves: { base: [40, 88, 52], v: 18, style: "leaves" },
  birch_leaves: { base: [96, 148, 60], v: 18, style: "leaves" },
  glass: { base: [200, 232, 240], v: 6, style: "glass" },
  deepslate: { base: [74, 74, 80], v: 10, style: "deepslate" },
  deepslate_top: { base: [66, 66, 72], v: 8 },
  snow: { base: [244, 248, 250], v: 5 },
  glowstone: { base: [220, 170, 90], v: 36, style: "glow" },
  coal_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [30, 30, 30] },
  iron_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [214, 170, 140] },
  gold_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [250, 220, 70] },
  diamond_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [90, 230, 230] },
  redstone_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [220, 30, 30] },
  copper_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [200, 110, 70] },
  lapis_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [40, 80, 200] },
  emerald_ore: { base: [125, 125, 125], v: 14, style: "ore", spec: [40, 200, 90] },
  obsidian: { base: [24, 14, 40], v: 10 },
  bricks: { base: [150, 84, 70], v: 8, style: "bricks" },
  sandstone: { base: [216, 202, 150], v: 8, style: "sandstone" },
  sandstone_top: { base: [222, 208, 158], v: 6 },
  sandstone_bottom: { base: [208, 194, 142], v: 6 },
  ice: { base: [150, 190, 250], v: 8, style: "ice", alpha: 0.72 },
  packed_ice: { base: [120, 160, 230], v: 14 },
  cactus_top: { base: [30, 110, 40], v: 10 },
  cactus_side: { base: [20, 120, 40], v: 8, style: "cactus_side" },
  crafting_top: { base: [150, 112, 60], v: 8, style: "crafting_top" },
  crafting_side: { base: [150, 112, 60], v: 8, style: "crafting_side" },
  bookshelf: { base: [162, 130, 78], v: 8, style: "books" },
  tnt_top: { base: [200, 190, 170], v: 6 },
  tnt_bottom: { base: [200, 190, 170], v: 6 },
  tnt_side: { base: [210, 50, 40], v: 8, style: "tnt_side" },
  white_wool: { base: [235, 235, 235], v: 6 },
  red_wool: { base: [168, 40, 36], v: 6 },
  blue_wool: { base: [48, 62, 168], v: 6 },
  green_wool: { base: [80, 112, 30], v: 6 },
  yellow_wool: { base: [230, 200, 50], v: 6 },
  lava: { base: [230, 100, 20], v: 40, style: "lava" },
  mossy_cobblestone: { base: [96, 120, 90], v: 26 },
  granite: { base: [150, 100, 82], v: 16 },
  diorite: { base: [190, 190, 188], v: 18 },
  andesite: { base: [136, 136, 132], v: 12 },
  clay: { base: [160, 166, 178], v: 6 },
  podzol_top: { base: [92, 64, 30], v: 14 },
  podzol_side: { base: [134, 96, 67], v: 14, style: "podzol_side", spec: [92, 64, 30] },
  red_sand: { base: [190, 102, 34], v: 9 },
  terracotta: { base: [152, 94, 68], v: 6 },
  pumpkin_top: { base: [200, 120, 20], v: 10 },
  pumpkin_side: { base: [210, 128, 24], v: 8, style: "pumpkin_side" },
  melon_top: { base: [120, 150, 40], v: 12 },
  melon_side: { base: [100, 160, 50], v: 10, style: "melon_side" },
  hay_top: { base: [190, 160, 40], v: 10 },
  hay_side: { base: [200, 170, 50], v: 10, style: "stripes" },
  sea_lantern: { base: [170, 210, 200], v: 24, style: "glow" },
  furnace_top: { base: [112, 112, 112], v: 12 },
  furnace_side: { base: [118, 118, 118], v: 12, style: "furnace_side" },
  short_grass: { base: [96, 170, 50], v: 18, style: "cross", spec: [0, 0, 0] },
  dandelion: { base: [250, 220, 40], v: 10, style: "cross", spec: [70, 150, 40] },
  poppy: { base: [210, 30, 30], v: 10, style: "cross", spec: [70, 150, 40] },
  dead_bush: { base: [120, 84, 40], v: 10, style: "cross", spec: [0, 0, 0] },
  oak_sapling: { base: [60, 140, 40], v: 12, style: "cross", spec: [0, 0, 0] },
  red_mushroom: { base: [200, 40, 40], v: 10, style: "cross", spec: [220, 220, 210] },
  air: { base: [0, 0, 0] },
};

export const textureNames: string[] = [];
export function texIndex(name: string): number {
  let i = textureNames.indexOf(name);
  if (i < 0) {
    textureNames.push(name);
    i = textureNames.length - 1;
  }
  return i;
}
export function textureIndexMap() {
  for (const b of BLOCKS) for (const t of b.tex) texIndex(t);
}

function drawTile(ctx: CanvasRenderingContext2D, name: string, idx: number) {
  const def = D[name] ?? { base: [255, 0, 255], v: 0 };
  const rnd = mulberry32(idx * 7919 + 13);
  const ox = (idx % ATLAS_COLS) * TILE;
  const oy = Math.floor(idx / ATLAS_COLS) * TILE;
  const img = ctx.createImageData(TILE, TILE);
  const set = (x: number, y: number, c: RGB, a = 255) => {
    const o = (y * TILE + x) * 4;
    img.data[o] = Math.max(0, Math.min(255, c[0]));
    img.data[o + 1] = Math.max(0, Math.min(255, c[1]));
    img.data[o + 2] = Math.max(0, Math.min(255, c[2]));
    img.data[o + 3] = a;
  };
  const style = def.style ?? "plain";
  const spec = def.spec ?? [0, 0, 0];
  const noise = Array.from({ length: TILE * TILE }, () => (rnd() - 0.5) * 2 * (def.v ?? 8));
  const shade = (c: RGB, n: number): RGB => [c[0] + n, c[1] + n, c[2] + n];
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const n = noise[y * TILE + x];
      let c: RGB = shade(def.base, n);
      let a = 255;
      switch (style) {
        case "grass_side":
          if (y < 3 + (x * 7 + idx) % 3) c = shade(spec, n);
          break;
        case "podzol_side":
          if (y < 3) c = shade(spec, n);
          break;
        case "planks":
          if (y % 4 === 3) c = shade(def.base, n - 26);
          if ((x + Math.floor(y / 4) * 5) % 16 === 0) c = shade(def.base, n - 20);
          break;
        case "log_side":
          c = shade(def.base, n + (x % 4 === 0 ? -16 : x % 4 === 2 ? 8 : 0));
          if (spec[0] && rnd() < 0.08) c = shade(spec, 0);
          break;
        case "log_top": {
          const d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5));
          c = shade(def.base, n + (d > 6 ? -50 : Math.floor(d) % 2 === 0 ? -14 : 6));
          break;
        }
        case "bricks":
          if (y % 4 === 3 || (x + (Math.floor(y / 4) % 2) * 8) % 16 === 0) c = [180, 176, 168];
          break;
        case "leaves":
          if (rnd() < 0.18) a = 0;
          else c = shade(def.base, n * 1.2);
          break;
        case "glass":
          a = x === 0 || y === 0 || x === 15 || y === 15 ? 255 : (x + y) % 9 === 0 ? 150 : 40;
          c = a === 255 ? [210, 235, 240] : [190, 225, 235];
          break;
        case "cross":
          a = 0;
          break;
        case "ore":
          if (rnd() < 0.0) c = [0, 0, 0];
          break;
        case "water":
          a = Math.floor((def.alpha ?? 0.6) * 255);
          break;
        case "ice":
          a = Math.floor((def.alpha ?? 0.7) * 255);
          break;
        case "lava":
          c = shade(def.base, n + (Math.sin(x * 0.9 + y * 0.5) > 0.4 ? 40 : -10));
          break;
        case "glow":
          c = shade(def.base, n + ((x * 3 + y * 5) % 7 === 0 ? 40 : 0));
          break;
        case "deepslate":
          c = shade(def.base, n + (y % 5 === 0 ? -14 : 0));
          break;
        case "sandstone":
          if (y < 2 || y > 13) c = shade(def.base, n - 22);
          break;
        case "tnt_side":
          if (y > 5 && y < 10) c = [225, 220, 205];
          break;
        case "books":
          if (y < 2 || y > 13) c = shade([162, 130, 78], n);
          else c = shade(([[170, 40, 40], [40, 90, 170], [50, 130, 50], [180, 150, 40]] as RGB[])[Math.floor(x / 2) % 4], n + (y % 7 === 0 ? -30 : 0));
          break;
        case "crafting_top":
          if (y % 5 === 0 || x % 5 === 0) c = shade(def.base, n - 30);
          break;
        case "crafting_side":
          if (y < 3) c = shade([110, 78, 40], n);
          else if (x > 3 && x < 12 && y > 5 && y < 12) c = shade([90, 70, 50], n);
          break;
        case "furnace_side":
          if (x > 3 && x < 12 && y > 6 && y < 13) c = [30, 30, 30];
          break;
        case "cactus_side":
          if (x % 5 === 2 && y % 4 === 1) c = [230, 240, 200];
          if (x === 0 || x === 15) c = shade(def.base, n - 30);
          break;
        case "stripes":
          if (y % 4 === 0) c = shade(def.base, n - 40);
          break;
        case "pumpkin_side":
          if (x % 4 === 0) c = shade(def.base, n - 28);
          break;
        case "melon_side":
          if (x % 4 < 2) c = shade([60, 130, 40], n);
          break;
        default:
          break;
      }
      set(x, y, c, a);
    }
  }
  // post-pass: ore specks, cross plant shapes
  if (style === "ore") {
    for (let k = 0; k < 9; k++) {
      const sx = Math.floor(rnd() * 13) + 1;
      const sy = Math.floor(rnd() * 13) + 1;
      for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) set(Math.min(15, sx + dx), Math.min(15, sy + dy), shade(spec, (rnd() - 0.5) * 30));
    }
  } else if (style === "cross") {
    img.data.fill(0);
    const stem = spec[0] || spec[1] ? spec : [def.base[0] * 0.8, def.base[1] * 0.9, def.base[2] * 0.6];
    for (let x = 0; x < 16; x++) {
      if (name === "short_grass" || name === "dead_bush") {
        const h = 5 + Math.floor((Math.sin(x * 1.7 + idx) + 1) * 4);
        for (let y = 16 - h; y < 16; y++) set(x, y, shade(def.base, (rnd() - 0.5) * 30), 255);
      }
    }
    if (name === "dandelion" || name === "poppy" || name === "red_mushroom" || name === "oak_sapling") {
      for (let y = 7; y < 16; y++) set(7, y, stem as RGB, 255);
      for (let y = 7; y < 16; y++) if (name === "oak_sapling") set(8, y, stem as RGB, 255);
      const r = name === "oak_sapling" ? 4 : 2;
      for (let dx = -r; dx <= r; dx++) for (let dy = -r; dy <= r; dy++) if (dx * dx + dy * dy <= r * r + 1) set(7 + dx, 5 + dy, shade(def.base, (rnd() - 0.5) * 24), 255);
      if (name === "red_mushroom") for (let k = 0; k < 4; k++) set(5 + k * 2 - 1, 4 + (k % 2), spec as RGB, 255);
    }
  }
  ctx.putImageData(img, ox, oy);
}

let atlasCanvas: HTMLCanvasElement | null = null;
export function getAtlas(): HTMLCanvasElement {
  if (atlasCanvas) return atlasCanvas;
  textureIndexMap();
  const rows = Math.ceil(textureNames.length / ATLAS_COLS);
  const c = document.createElement("canvas");
  c.width = ATLAS_COLS * TILE;
  c.height = rows * TILE;
  const ctx = c.getContext("2d")!;
  textureNames.forEach((n, i) => drawTile(ctx, n, i));
  atlasCanvas = c;
  return c;
}

/** Draws an isometric-ish icon of a block into a canvas (top + two sides). */
export function drawBlockIcon(canvas: HTMLCanvasElement, blockId: number, size = 40) {
  const atlas = getAtlas();
  const b = BLOCKS[blockId];
  const ctx = canvas.getContext("2d")!;
  canvas.width = size;
  canvas.height = size;
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, size, size);
  const tile = (name: string) => {
    const i = textureNames.indexOf(name);
    return { sx: (i % ATLAS_COLS) * TILE, sy: Math.floor(i / ATLAS_COLS) * TILE };
  };
  if (b.cross) {
    const t = tile(b.tex[2]);
    ctx.drawImage(atlas, t.sx, t.sy, TILE, TILE, size * 0.1, size * 0.1, size * 0.8, size * 0.8);
    return;
  }
  const s = size / 2;
  const top = tile(b.tex[0]);
  const side = tile(b.tex[2]);
  // top face
  ctx.save();
  ctx.setTransform(1, 0.5, -1, 0.5, s, 0);
  ctx.drawImage(atlas, top.sx, top.sy, TILE, TILE, 0, 0, s / 1.0, s / 1.0);
  ctx.restore();
  ctx.save();
  ctx.setTransform(1, 0.5, 0, 1, 0, s * 0.5);
  ctx.drawImage(atlas, side.sx, side.sy, TILE, TILE, 0, 0, s, s);
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.fillRect(0, 0, s, s);
  ctx.restore();
  ctx.save();
  ctx.setTransform(1, -0.5, 0, 1, s, s * 1.0);
  ctx.drawImage(atlas, side.sx, side.sy, TILE, TILE, 0, 0, s, s);
  ctx.fillStyle = "rgba(0,0,0,0.42)";
  ctx.fillRect(0, 0, s, s);
  ctx.restore();
}
