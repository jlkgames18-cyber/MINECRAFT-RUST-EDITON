import { useCallback, useEffect, useRef, useState } from "react";
import { BLOCKS } from "../engine/blocks";
import { Game, HudState } from "../engine/Game";
import { BlockIcon } from "./BlockIcon";

export default function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [chat, setChat] = useState<{ open: boolean; text: string }>({ open: false, text: "" });
  const [inv, setInv] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const [view, setView] = useState(6);
  const [seedText, setSeedText] = useState("");
  const [error, setError] = useState("");

  const uiOpen = chat.open || inv;

  useEffect(() => {
    if (!canvasRef.current || !hostRef.current) return;
    let game: Game;
    try {
      game = new Game(canvasRef.current, hostRef.current, {
        onHud: setHud,
        onUi: (w) => {
          if (w === "inventory") setInv(true);
          else setChat({ open: true, text: w === "command" ? "/" : "" });
        },
      });
    } catch (e) {
      setError("تعذّر تشغيل WebGL في هذا المتصفح: " + String(e));
      return;
    }
    gameRef.current = game;
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setUiOpen(uiOpen);
  }, [uiOpen]);

  useEffect(() => {
    if (chat.open) inputRef.current?.focus();
  }, [chat.open]);

  useEffect(() => {
    if (!inv) return;
    const h = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyE") setInv(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [inv]);

  const push = useCallback((lines: string[]) => setLog((l) => [...l, ...lines].slice(-8)), []);

  const submit = () => {
    const t = chat.text.trim();
    if (t) push(t.startsWith("/") ? (gameRef.current?.runCommand(t) ?? []).map((x) => "› " + x) : ["<لاعب> " + t]);
    setChat({ open: false, text: "" });
  };

  const fullscreen = () => hostRef.current?.requestFullscreen?.();

  const newWorld = () => {
    const g = gameRef.current;
    if (!g) return;
    const s = seedText.trim() ? parseInt(seedText) || [...seedText].reduce((h, c) => (h * 31 + c.charCodeAt(0)) | 0, 7) : Math.floor(Math.random() * 1e9);
    g.resetWorld(s);
    push(["عالم جديد — البذرة " + s]);
  };

  const sel = hud ? BLOCKS[hud.hotbar[hud.selected]] : null;

  return (
    <div className="space-y-3">
      <div ref={hostRef} dir="ltr" className="relative w-full aspect-video min-h-[360px] overflow-hidden rounded-2xl border border-emerald-400/30 bg-black shadow-2xl shadow-emerald-900/40 select-none">
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
        {error && <div className="absolute inset-0 grid place-items-center bg-black/80 p-6 text-center text-red-300">{error}</div>}

        {hud?.underwater && <div className="pointer-events-none absolute inset-0 bg-blue-600/30" />}

        {/* crosshair */}
        {hud?.locked && (
          <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="absolute h-[2px] w-5 -translate-x-1/2 bg-white/90 mix-blend-difference" />
            <div className="absolute h-5 w-[2px] -translate-y-1/2 bg-white/90 mix-blend-difference" />
          </div>
        )}

        {/* debug */}
        {hud && (
          <div className="pointer-events-none absolute left-2 top-2 rounded bg-black/55 px-2 py-1 font-mono text-[11px] leading-4 text-white">
            <div>{hud.fps} FPS · chunks {hud.chunks}</div>
            <div>XYZ {hud.x.toFixed(1)} / {hud.y.toFixed(1)} / {hud.z.toFixed(1)}</div>
            <div>{hud.biome} · {hud.time} · seed {hud.seed}</div>
            <div>{hud.mode === "creative" ? "Creative" : "Survival"}{hud.flying ? " · flying" : ""}{hud.mode === "survival" ? ` · ${hud.tool}` : ""}</div>
            {hud.target && <div className="text-emerald-300">▸ {hud.target}</div>}
          </div>
        )}

        {/* log */}
        {log.length > 0 && (
          <div dir="rtl" className="pointer-events-none absolute bottom-20 right-2 max-w-[60%] space-y-0.5 text-sm text-white [text-shadow:0_1px_2px_#000]">
            {log.map((l, i) => (
              <div key={i} className="rounded bg-black/45 px-2 py-0.5">{l}</div>
            ))}
          </div>
        )}

        {/* mining progress */}
        {hud && hud.progress > 0 && (
          <div className="pointer-events-none absolute left-1/2 top-[56%] h-1.5 w-28 -translate-x-1/2 overflow-hidden rounded bg-black/60">
            <div className="h-full bg-emerald-400" style={{ width: `${hud.progress * 100}%` }} />
          </div>
        )}

        {/* hotbar */}
        {hud && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2">
            {sel && sel.id !== 0 && <div dir="rtl" className="mb-1 text-center text-sm font-semibold text-white [text-shadow:0_1px_3px_#000]">{sel.label}</div>}
            <div className="flex gap-0.5 rounded bg-black/55 p-1">
              {hud.hotbar.map((id, i) => (
                <button
                  key={i}
                  onClick={() => gameRef.current && (gameRef.current.selected = i)}
                  className={`relative grid h-11 w-11 place-items-center rounded border-2 ${i === hud.selected ? "border-white bg-white/25" : "border-white/20 bg-white/5"}`}
                >
                  <BlockIcon id={id} size={32} />
                  <span className="absolute left-0.5 top-0 text-[9px] text-white/70">{i + 1}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* click to play */}
        {hud && !hud.locked && !uiOpen && !hud.loading && (
          <button onClick={() => gameRef.current?.requestLock()} className="absolute inset-0 grid place-items-center bg-black/55 text-white backdrop-blur-[1px]">
            <div dir="rtl" className="max-w-md space-y-3 rounded-2xl bg-slate-900/90 p-6 text-center ring-1 ring-white/15">
              <div className="text-2xl font-extrabold text-emerald-300">انقر للعب</div>
              <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-right text-sm text-slate-200">
                <span>W A S D — حركة</span><span>Space — قفز (مرتان = طيران)</span>
                <span>Shift — تسلل / نزول</span><span>Ctrl — ركض</span>
                <span>زر يسار — تكسير</span><span>زر يمين — وضع كتلة</span>
                <span>1‑9 / عجلة — الشريط</span><span>E — كل الكتل</span>
                <span>G — إبداعي/بقاء</span><span>R — أداة (في البقاء)</span>
                <span>/ — أوامر</span><span>P — إيقاف الوقت</span>
              </div>
            </div>
          </button>
        )}
        {(!hud || hud.loading) && <div className="pointer-events-none absolute inset-0 grid place-items-center bg-slate-950/80 text-lg text-emerald-300">جارٍ توليد العالم…</div>}

        {/* chat / command */}
        {chat.open && (
          <div className="absolute inset-x-2 bottom-2 z-20">
            <input
              ref={inputRef}
              dir="auto"
              value={chat.text}
              onChange={(e) => setChat({ open: true, text: e.target.value })}
              onKeyDown={(e) => {
                e.stopPropagation();
                if (e.key === "Enter") submit();
                if (e.key === "Escape") setChat({ open: false, text: "" });
              }}
              placeholder="/help"
              className="w-full rounded bg-black/80 px-3 py-2 font-mono text-white outline-none ring-1 ring-emerald-400/60"
            />
          </div>
        )}

        {/* inventory */}
        {inv && (
          <div className="absolute inset-0 z-20 grid place-items-center bg-black/60 p-3" onClick={() => setInv(false)}>
            <div dir="rtl" className="max-h-full w-full max-w-3xl overflow-auto rounded-2xl bg-slate-900/95 p-4 ring-1 ring-white/20" onClick={(e) => e.stopPropagation()}>
              <div className="mb-3 flex items-center justify-between">
                <div className="text-lg font-bold text-white">كل الكتل — اختر كتلة للخانة {hud ? hud.selected + 1 : 1}</div>
                <button onClick={() => setInv(false)} className="rounded bg-white/10 px-3 py-1 text-sm text-white hover:bg-white/20">إغلاق (Esc)</button>
              </div>
              <div className="grid grid-cols-[repeat(auto-fill,minmax(54px,1fr))] gap-1.5">
                {BLOCKS.filter((b) => b.id !== 0).map((b) => (
                  <button
                    key={b.id}
                    title={b.label}
                    onClick={() => {
                      if (gameRef.current) gameRef.current.setHotbarBlock(gameRef.current.selected, b.id);
                      setInv(false);
                    }}
                    className="group grid place-items-center rounded-lg bg-white/5 p-1.5 ring-1 ring-white/10 hover:bg-emerald-500/25 hover:ring-emerald-400"
                  >
                    <BlockIcon id={b.id} size={36} />
                    <span className="mt-0.5 line-clamp-1 text-[10px] text-slate-300">{b.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div dir="rtl" className="flex flex-wrap items-center gap-3 rounded-xl bg-slate-900/70 p-3 text-sm text-slate-200 ring-1 ring-white/10">
        <label className="flex items-center gap-2">
          مدى الرؤية
          <input type="range" min={2} max={10} value={view} onChange={(e) => { const v = +e.target.value; setView(v); gameRef.current?.setViewDistance(v); }} />
          <span className="w-5 text-emerald-300">{view}</span>
        </label>
        <div className="flex items-center gap-2">
          <input value={seedText} onChange={(e) => setSeedText(e.target.value)} placeholder="بذرة (اختياري)" className="w-36 rounded bg-slate-800 px-2 py-1 text-white outline-none ring-1 ring-white/10 focus:ring-emerald-400" />
          <button onClick={newWorld} className="rounded bg-emerald-500 px-3 py-1 font-semibold text-slate-950 hover:bg-emerald-400">عالم جديد</button>
        </div>
        <button onClick={() => { gameRef.current?.runCommand("/gamemode " + (gameRef.current.survival ? "creative" : "survival")); }} className="rounded bg-white/10 px-3 py-1 hover:bg-white/20">تبديل الوضع</button>
        <button onClick={fullscreen} className="rounded bg-white/10 px-3 py-1 hover:bg-white/20">ملء الشاشة</button>
        <span className="text-xs text-slate-400">المحرك هنا نسخة TypeScript من خوارزميات النواة: الضجيج، التوليد، الفيزياء، صيغة التكسير، سطوع السماء.</span>
      </div>
    </div>
  );
}
