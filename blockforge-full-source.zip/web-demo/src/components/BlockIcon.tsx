import { useEffect, useRef } from "react";
import { drawBlockIcon } from "../engine/textures";

export function BlockIcon({ id, size = 40, className = "" }: { id: number; size?: number; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) drawBlockIcon(ref.current, id, size);
  }, [id, size]);
  return <canvas ref={ref} width={size} height={size} className={className} style={{ imageRendering: "pixelated", width: size, height: size }} />;
}
