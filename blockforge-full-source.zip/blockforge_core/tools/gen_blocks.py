#!/usr/bin/env python3
"""Generates `src/block_table.rs` (the full block registry) for BlockForge Core.

Run:  python3 tools/gen_blocks.py > src/block_table.rs

The first 24 ids are frozen so older saves / tests keep working. Every block gets
flags, light, hardness, blast resistance, friction, speed factor, preferred tool,
minimum tool tier and atlas slots. The texture atlas slot list is emitted as
`TEXTURE_NAMES` so a renderer can build the atlas straight from vanilla texture names.
"""

TOOL = {"none": 0, "pickaxe": 1, "axe": 2, "shovel": 3, "hoe": 4, "sword": 5, "shears": 6}

blocks = []  # dict rows
textures = []


def tex(name):
    if name not in textures:
        textures.append(name)
    return textures.index(name)


def add(name, kind="full", light=0, filt=15, hard=1.0, blast=None, t=None, tool="none", tier=0,
        fric=0.6, speed=1.0, extra=()):
    """kind: air|full|liquid|lava|glass|leaves|cross|ice|cutout"""
    if t is None:
        t = (name, name, name)
    elif isinstance(t, str):
        t = (t, t, t)
    elif len(t) == 2:  # (top/bottom, side)
        t = (t[0], t[0], t[1])
    flags = {
        "air": ["NO_RENDER"],
        "full": ["SOLID", "OPAQUE"],
        "liquid": ["LIQUID", "TRANSLUCENT", "CULL_SAME"],
        "lava": ["LIQUID"],
        "glass": ["SOLID", "TRANSLUCENT", "CULL_SAME"],
        "leaves": ["SOLID", "RANDOM_TICK"],
        "cross": ["CROSS"],
        "ice": ["SOLID", "TRANSLUCENT", "CULL_SAME"],
        "cutout": ["SOLID"],
    }[kind][:]
    flags += [f for f in extra if f not in flags]
    if tool != "none" and tier > 0 and kind == "full":
        flags.append("REQUIRES_TOOL")
    if blast is None:
        blast = max(hard * 5.0 / 3.0, 0.0)
        if hard < 0:
            blast = 3600000.0
    blocks.append(dict(name=name, flags=flags, light=light, filt=filt, hard=hard, blast=blast,
                       fric=fric, speed=speed, tool=tool, tier=tier,
                       t=(tex(t[0]), tex(t[1]), tex(t[2]))))


COLORS = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
          "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"]
WOODS = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"]

# ---------------------------------------------------------------- frozen block 0..23
add("air", "air", filt=0, hard=0.0, t="air")
add("stone", hard=1.5, blast=6.0, t="stone", tool="pickaxe", tier=1)
add("grass_block", hard=0.6, t=("grass_block_top", "dirt", "grass_block_side"), tool="shovel",
    extra=("RANDOM_TICK",))
add("dirt", hard=0.5, tool="shovel")
add("cobblestone", hard=2.0, blast=6.0, tool="pickaxe", tier=1)
add("oak_planks", hard=2.0, blast=3.0, tool="axe", extra=("FLAMMABLE",))
add("bedrock", hard=-1.0)
add("water", "liquid", filt=1, hard=100.0, blast=100.0)
add("lava", "lava", light=15, filt=1, hard=100.0, blast=100.0)
add("sand", hard=0.5, tool="shovel", extra=("GRAVITY",))
add("gravel", hard=0.6, tool="shovel", extra=("GRAVITY",))
add("oak_log", hard=2.0, t=("oak_log_top", "oak_log"), tool="axe", extra=("FLAMMABLE",))
add("oak_leaves", "leaves", filt=1, hard=0.2, tool="hoe", extra=("FLAMMABLE",))
add("glass", "glass", filt=0, hard=0.3)
add("deepslate", hard=3.0, blast=6.0, t=("deepslate_top", "deepslate"), tool="pickaxe", tier=1)
add("snow_block", hard=0.2, tool="shovel")
add("glowstone", light=15, hard=0.3)
add("coal_ore", hard=3.0, blast=3.0, tool="pickaxe", tier=1)
add("iron_ore", hard=3.0, blast=3.0, tool="pickaxe", tier=2)
add("diamond_ore", hard=3.0, blast=3.0, tool="pickaxe", tier=3)
add("obsidian", hard=50.0, blast=1200.0, tool="pickaxe", tier=4)
add("bricks", hard=2.0, blast=6.0, tool="pickaxe", tier=1)
add("ice", "ice", filt=1, hard=0.5, fric=0.98, tool="pickaxe")
add("sandstone", hard=0.8, t=("sandstone_top", "sandstone_bottom", "sandstone"), tool="pickaxe", tier=1)
assert len(blocks) == 24

# ---------------------------------------------------------------- new blocks
STONES = [("granite", 1.5), ("polished_granite", 1.5), ("diorite", 1.5), ("polished_diorite", 1.5),
          ("andesite", 1.5), ("polished_andesite", 1.5), ("smooth_stone", 2.0), ("stone_bricks", 1.5),
          ("mossy_stone_bricks", 1.5), ("cracked_stone_bricks", 1.5), ("chiseled_stone_bricks", 1.5),
          ("mossy_cobblestone", 2.0), ("tuff", 1.5), ("calcite", 0.75), ("dripstone_block", 1.5),
          ("smooth_basalt", 1.25), ("blackstone", 1.5), ("polished_blackstone", 2.0),
          ("polished_blackstone_bricks", 1.5), ("gilded_blackstone", 1.5),
          ("cobbled_deepslate", 3.5), ("polished_deepslate", 3.5), ("deepslate_bricks", 3.5),
          ("deepslate_tiles", 3.5), ("chiseled_deepslate", 3.5), ("tuff_bricks", 1.5),
          ("polished_tuff", 1.5), ("nether_bricks", 2.0), ("red_nether_bricks", 2.0),
          ("end_stone", 3.0), ("end_stone_bricks", 3.0), ("purpur_block", 1.5),
          ("prismarine", 1.5), ("prismarine_bricks", 1.5), ("dark_prismarine", 1.5),
          ("mud_bricks", 1.5), ("red_sandstone", 0.8), ("cut_sandstone", 0.8),
          ("smooth_sandstone", 2.0), ("chiseled_sandstone", 0.8), ("cut_red_sandstone", 0.8),
          ("smooth_red_sandstone", 2.0), ("chiseled_red_sandstone", 0.8), ("quartz_block", 0.8),
          ("quartz_bricks", 0.8), ("smooth_quartz", 2.0), ("chiseled_quartz_block", 0.8),
          ("quartz_pillar", 0.8), ("terracotta", 1.25), ("netherrack", 0.4),
          ("magma_block", 0.5), ("crying_obsidian", 50.0), ("reinforced_deepslate", 55.0),
          ("basalt", 1.25), ("coal_block", 5.0), ("iron_block", 5.0), ("gold_block", 3.0),
          ("diamond_block", 5.0), ("emerald_block", 5.0), ("lapis_block", 3.0),
          ("redstone_block", 5.0), ("copper_block", 3.0), ("raw_iron_block", 5.0),
          ("raw_copper_block", 5.0), ("raw_gold_block", 5.0), ("netherite_block", 50.0),
          ("amethyst_block", 1.5), ("bone_block", 2.0), ("exposed_copper", 3.0),
          ("weathered_copper", 3.0), ("oxidized_copper", 3.0), ("cut_copper", 3.0),
          ("sea_lantern", 0.3), ("ancient_debris", 30.0), ("nether_quartz_ore", 3.0),
          ("nether_gold_ore", 3.0), ("lodestone", 3.5), ("target", 0.5)]
for n, h in STONES:
    tier = 1
    if n in ("iron_block", "gold_block", "diamond_block", "emerald_block", "raw_gold_block"):
        tier = 3
    if n in ("lapis_block", "copper_block", "raw_copper_block", "raw_iron_block"):
        tier = 2
    if n in ("netherite_block", "crying_obsidian", "reinforced_deepslate", "ancient_debris"):
        tier = 4
    if n == "target":
        add(n, hard=h, tool="hoe")
        continue
    light = {"sea_lantern": 15, "magma_block": 3, "crying_obsidian": 10}.get(n, 0)
    t = None
    if n == "quartz_pillar":
        t = ("quartz_pillar_top", "quartz_pillar")
    elif n == "quartz_block":
        t = ("quartz_block_top", "quartz_block_bottom", "quartz_block_side")
    elif n == "basalt":
        t = ("basalt_top", "basalt_side")
    elif n == "red_sandstone":
        t = ("red_sandstone_top", "red_sandstone_bottom", "red_sandstone")
    elif n == "bone_block":
        t = ("bone_block_top", "bone_block_side")
    add(n, light=light, hard=h, t=t, tool="pickaxe", tier=tier,
        blast=(1200.0 if n in ("netherite_block", "crying_obsidian", "reinforced_deepslate") else None))

for n in ["copper_ore", "gold_ore", "lapis_ore", "redstone_ore", "emerald_ore"]:
    add(n, hard=3.0, blast=3.0, tool="pickaxe",
        tier={"copper_ore": 2, "lapis_ore": 2}.get(n, 3))
for n in ["coal", "iron", "copper", "gold", "redstone", "lapis", "diamond", "emerald"]:
    add(f"deepslate_{n}_ore", hard=4.5, blast=3.0, tool="pickaxe",
        tier={"coal": 1, "iron": 2, "copper": 2, "lapis": 2}.get(n, 3))

for n, h, tl in [("coarse_dirt", 0.5, "shovel"), ("rooted_dirt", 0.5, "shovel"),
                 ("podzol", 0.5, "shovel"), ("mycelium", 0.6, "shovel"), ("clay", 0.6, "shovel"),
                 ("mud", 0.5, "shovel"), ("packed_mud", 1.0, "pickaxe"), ("moss_block", 0.1, "hoe"),
                 ("farmland", 0.6, "shovel"), ("dirt_path", 0.65, "shovel"),
                 ("soul_sand", 0.5, "shovel"), ("soul_soil", 0.5, "shovel"),
                 ("red_sand", 0.5, "shovel"), ("suspicious_sand", 0.25, "shovel"),
                 ("packed_ice", 0.5, "pickaxe"), ("blue_ice", 2.8, "pickaxe")]:
    t = None
    if n == "podzol":
        t = ("podzol_top", "dirt", "podzol_side")
    elif n == "mycelium":
        t = ("mycelium_top", "dirt", "mycelium_side")
    elif n == "farmland":
        t = ("farmland", "dirt", "dirt")
    elif n == "dirt_path":
        t = ("dirt_path_top", "dirt", "dirt_path_side")
    kw = {}
    if n == "soul_sand":
        kw["speed"] = 0.4
    if n == "packed_ice":
        kw["fric"] = 0.98
    if n == "blue_ice":
        kw["fric"] = 0.989
    ex = ("GRAVITY",) if n == "red_sand" else ()
    if n in ("mycelium", "podzol"):
        ex += ("RANDOM_TICK",)
    add(n, hard=h, tool=tl, t=t, extra=ex, **kw)

for w in WOODS:
    if w != "oak":
        add(f"{w}_log", hard=2.0, t=(f"{w}_log_top", f"{w}_log"), tool="axe", extra=("FLAMMABLE",))
        add(f"{w}_planks", hard=2.0, blast=3.0, tool="axe", extra=("FLAMMABLE",))
        add(f"{w}_leaves", "leaves", filt=1, hard=0.2, tool="hoe", extra=("FLAMMABLE",))
    add(f"stripped_{w}_log", hard=2.0, t=(f"stripped_{w}_log_top", f"stripped_{w}_log"), tool="axe",
        extra=("FLAMMABLE",))
    add(f"{w}_wood", hard=2.0, t=f"{w}_log", tool="axe", extra=("FLAMMABLE",))
    add(f"stripped_{w}_wood", hard=2.0, t=f"stripped_{w}_log", tool="axe", extra=("FLAMMABLE",))
add("bamboo_planks", hard=2.0, blast=3.0, tool="axe", extra=("FLAMMABLE",))
add("bamboo_block", hard=2.0, t=("bamboo_block_top", "bamboo_block"), tool="axe")
add("crimson_stem", hard=2.0, t=("crimson_stem_top", "crimson_stem"), tool="axe")
add("warped_stem", hard=2.0, t=("warped_stem_top", "warped_stem"), tool="axe")
add("crimson_planks", hard=2.0, blast=3.0, tool="axe")
add("warped_planks", hard=2.0, blast=3.0, tool="axe")
add("azalea_leaves", "leaves", filt=1, hard=0.2, tool="hoe")
add("flowering_azalea_leaves", "leaves", filt=1, hard=0.2, tool="hoe")
add("mangrove_roots", "cutout", filt=1, hard=0.7, tool="axe")
add("nether_wart_block", hard=1.0, tool="hoe")
add("warped_wart_block", hard=1.0, tool="hoe")
add("shroomlight", light=15, hard=1.0, tool="hoe")
add("mushroom_stem", hard=0.2, tool="axe")
add("red_mushroom_block", hard=0.2, tool="axe")
add("brown_mushroom_block", hard=0.2, tool="axe")

for w in WOODS:
    add(f"{w}_sapling", "cross", filt=0, hard=0.0, extra=("RANDOM_TICK", "REPLACEABLE"))
REPL = ("short_grass", "tall_grass", "fern", "large_fern", "dead_bush", "seagrass", "fire")
GROW = ("wheat", "carrots", "potatoes", "beetroots", "sugar_cane", "kelp", "bamboo")
for n in ["short_grass", "tall_grass", "fern", "large_fern", "dead_bush", "dandelion", "poppy",
          "blue_orchid", "allium", "azure_bluet", "red_tulip", "orange_tulip", "white_tulip",
          "pink_tulip", "oxeye_daisy", "cornflower", "lily_of_the_valley", "sunflower", "lilac",
          "rose_bush", "peony", "torchflower", "pink_petals", "brown_mushroom", "red_mushroom",
          "sugar_cane", "bamboo", "sweet_berry_bush", "seagrass", "tall_seagrass", "kelp",
          "sea_pickle", "wheat", "carrots", "potatoes", "beetroots", "melon_stem", "pumpkin_stem",
          "nether_sprouts", "crimson_roots", "warped_roots", "hanging_roots", "glow_lichen",
          "small_dripleaf", "spore_blossom", "fire", "soul_fire"]:
    light = {"fire": 15, "soul_fire": 10, "sea_pickle": 6, "glow_lichen": 7}.get(n, 0)
    ex = (("REPLACEABLE",) if n in REPL else ()) + (("RANDOM_TICK",) if n in GROW else ())
    add(n, "cross", light=light, filt=0, hard=(1.0 if n == "bamboo" else 0.0), extra=ex)
for n, l in [("torch", 14), ("soul_torch", 10), ("redstone_torch", 7), ("lantern", 15),
             ("soul_lantern", 10), ("end_rod", 14), ("candle", 3)]:
    add(n, "cross", light=l, filt=0, hard=0.0)
add("cobweb", "cross", filt=1, hard=4.0, speed=0.05, tool="sword", extra=("REPLACEABLE",))
add("vine", "cross", filt=0, hard=0.2, tool="axe", extra=("CLIMBABLE", "REPLACEABLE", "FLAMMABLE"))
add("ladder", "cross", filt=0, hard=0.4, tool="axe", extra=("CLIMBABLE",))
add("scaffolding", "cross", filt=0, hard=0.0, extra=("CLIMBABLE",))
add("cave_vines", "cross", light=14, filt=0, hard=0.0, extra=("CLIMBABLE",))
add("twisting_vines", "cross", filt=0, hard=0.0, extra=("CLIMBABLE",))
add("weeping_vines", "cross", filt=0, hard=0.0, extra=("CLIMBABLE",))
add("lily_pad", "cross", filt=0, hard=0.0)

add("cactus", "cutout", filt=0, hard=0.4, t=("cactus_top", "cactus_bottom", "cactus_side"), extra=("RANDOM_TICK",))
add("pumpkin", hard=1.0, t=("pumpkin_top", "pumpkin_top", "pumpkin_side"), tool="axe")
add("carved_pumpkin", hard=1.0, t=("pumpkin_top", "pumpkin_top", "carved_pumpkin"), tool="axe")
add("jack_o_lantern", light=15, hard=1.0, t=("pumpkin_top", "pumpkin_top", "jack_o_lantern"), tool="axe")
add("melon", hard=1.0, t=("melon_top", "melon_top", "melon_side"), tool="axe")
add("hay_block", hard=0.5, t=("hay_block_top", "hay_block_side"), tool="hoe")
add("sponge", hard=0.6, tool="hoe")
add("wet_sponge", hard=0.6, tool="hoe")
add("slime_block", "glass", filt=0, hard=0.0, fric=0.8)
add("honey_block", "glass", filt=0, hard=0.0, fric=0.8, speed=0.4)
add("tnt", hard=0.0, t=("tnt_top", "tnt_bottom", "tnt_side"))
add("bookshelf", hard=1.5, t=("oak_planks", "bookshelf"), tool="axe", extra=("FLAMMABLE",))
add("crafting_table", hard=2.5, t=("crafting_table_top", "oak_planks", "crafting_table_side"), tool="axe")
add("furnace", hard=3.5, t=("furnace_top", "furnace_top", "furnace_side"), tool="pickaxe", tier=1)
add("blast_furnace", hard=3.5, t=("blast_furnace_top", "blast_furnace_top", "blast_furnace_side"), tool="pickaxe", tier=1)
add("smoker", hard=3.5, t=("smoker_top", "smoker_bottom", "smoker_side"), tool="pickaxe", tier=1)
add("chest", hard=2.5, t=("oak_planks", "oak_planks", "chest_side"), tool="axe")
add("barrel", hard=2.5, t=("barrel_top", "barrel_bottom", "barrel_side"), tool="axe")
add("jukebox", hard=2.0, t=("jukebox_top", "jukebox_side", "jukebox_side"), tool="axe")
add("note_block", hard=0.8, tool="axe")
add("enchanting_table", hard=5.0, blast=1200.0, t=("enchanting_table_top", "enchanting_table_bottom", "enchanting_table_side"), tool="pickaxe", tier=1)
add("anvil", hard=5.0, blast=1200.0, t=("anvil_top", "anvil", "anvil"), tool="pickaxe", tier=1, extra=("GRAVITY",))
add("beacon", "glass", light=15, filt=0, hard=3.0)
add("redstone_lamp", light=15, hard=0.3)
add("dropper", hard=3.5, tool="pickaxe", tier=1)
add("dispenser", hard=3.5, tool="pickaxe", tier=1)
add("piston", hard=1.5, t=("piston_top", "piston_bottom", "piston_side"), tool="pickaxe")
add("sticky_piston", hard=1.5, t=("piston_top_sticky", "piston_bottom", "piston_side"), tool="pickaxe")
add("observer", hard=3.0, tool="pickaxe", tier=1)
add("spawner", "cutout", filt=0, hard=5.0, blast=25.0, t="spawner", tool="pickaxe", tier=1)
add("end_portal_frame", hard=-1.0, t=("end_portal_frame_top", "end_stone", "end_portal_frame_side"))
add("budding_amethyst", hard=1.5, tool="pickaxe", tier=1)
add("sculk", hard=0.2, tool="hoe")
add("sculk_catalyst", light=6, hard=3.0, tool="hoe")
add("ochre_froglight", light=15, hard=0.3)
add("verdant_froglight", light=15, hard=0.3)
add("pearlescent_froglight", light=15, hard=0.3)
add("respawn_anchor", light=15, hard=50.0, blast=1200.0, tool="pickaxe", tier=4)
add("powder_snow", "cutout", filt=1, hard=0.25, speed=0.9, tool="shovel")
add("snow_layer", "cross", filt=0, hard=0.1, tool="shovel", t="snow_block")
add("barrier", "cutout", filt=0, hard=-1.0, t="barrier")
add("structure_void", "cross", filt=0, hard=0.0)

for c in COLORS:
    add(f"{c}_wool", hard=0.8, tool="shears", extra=("FLAMMABLE",))
for c in COLORS:
    add(f"{c}_concrete", hard=1.8, tool="pickaxe", tier=1)
for c in COLORS:
    add(f"{c}_concrete_powder", hard=0.5, tool="shovel", extra=("GRAVITY",))
for c in COLORS:
    add(f"{c}_terracotta", hard=1.25, blast=4.2, tool="pickaxe", tier=1)
for c in COLORS:
    add(f"{c}_glazed_terracotta", hard=1.4, tool="pickaxe", tier=1)
for c in COLORS:
    add(f"{c}_stained_glass", "glass", filt=0, hard=0.3)
for c in COLORS:
    add(f"{c}_shulker_box", hard=2.0, tool="pickaxe")

names = [b["name"] for b in blocks]
dups = {n for n in names if names.count(n) > 1}
assert not dups, dups

# ---------------------------------------------------------------- emit
out = []
out.append("// @generated by tools/gen_blocks.py — DO NOT EDIT BY HAND.")
out.append("use crate::block::{BlockId, BlockInfo, flags::*};")
out.append("")
out.append("const FULL: u16 = SOLID | OPAQUE;")
out.append("#[allow(clippy::too_many_arguments)]")
out.append("const fn r(name: &'static str, flags: u16, light: u8, filter: u8, hardness: f32, blast: f32,")
out.append("    friction: f32, speed: f32, tool: u8, tier: u8, tex: (u16, u16, u16)) -> BlockInfo {")
out.append("    BlockInfo { name, flags, light_emission: light, light_filter: filter, hardness, blast_resistance: blast,")
out.append("        friction, speed_factor: speed, tool, min_tier: tier, tex_top: tex.0, tex_bottom: tex.1, tex_side: tex.2 }")
out.append("}")
out.append("")
out.append(f"pub const BLOCK_COUNT: usize = {len(blocks)};")
out.append("")
out.append("pub static BLOCKS: [BlockInfo; BLOCK_COUNT] = [")
for b in blocks:
    fl = b["flags"]
    if fl[:2] == ["SOLID", "OPAQUE"]:
        s = " | ".join(["FULL"] + fl[2:])
    else:
        s = " | ".join(fl) if fl else "0"
    out.append(
        f'    r("minecraft:{b["name"]}", {s}, {b["light"]}, {b["filt"]}, {float(b["hard"])!r}, '
        f'{float(b["blast"])!r}, {float(b["fric"])!r}, {float(b["speed"])!r}, {TOOL[b["tool"]]}, {b["tier"]}, '
        f'({b["t"][0]}, {b["t"][1]}, {b["t"][2]})),')
out.append("];")
out.append("")
out.append(f"pub const TEXTURE_COUNT: usize = {len(textures)};")
out.append("/// Vanilla texture names, indexed by atlas slot.")
out.append("pub static TEXTURE_NAMES: [&str; TEXTURE_COUNT] = [")
for t in textures:
    out.append(f'    "{t}",')
out.append("];")
out.append("")
out.append("#[allow(missing_docs)]")
out.append("impl BlockId {")
for i, b in enumerate(blocks):
    out.append(f"    pub const {b['name'].upper()}: BlockId = BlockId({i});")
out.append("}")
print("\n".join(out))
