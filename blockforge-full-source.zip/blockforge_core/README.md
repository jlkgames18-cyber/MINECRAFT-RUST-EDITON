# BlockForge Core 2 — Minecraft Java 1.21.11 engine core (Rust)

نواة محرك مكعبات (Voxel) مكتوبة بالكامل بلغة **Rust** وبدون أي اعتماديات خارجية، تستهدف
**Minecraft: Java Edition 1.21.11** — Protocol `774`، Data Version `4671`.
هذه النسخة (v0.2.0) هي النواة الأصلية بعد تطوير كبير: إصلاح الأخطاء + مئات الإضافات.

```bash
cargo test --release     # 133 tests (126 unit + 7 integration)
cargo run --release      # headless benchmark / self-check of every subsystem
cargo run --release -- --view 12 --threads 8 --seed 42
python3 tools/gen_blocks.py > src/block_table.rs   # regenerate the 415-block registry
```

## What is new in v0.2.0 (vs. the original 0.1.0)

### Bug fixes
| # | bug in 0.1.0 | fix |
|---|--------------|-----|
| 1 | **Lighting**: `light_filter` was inverted – water, leaves, glass and ice blocked *all* light | filter = absorbed light, `max(1)` per step |
| 2 | Sky light lost 1 level per block when travelling straight down through air | vertical sky light is lossless through filter-0 blocks (vanilla rule) |
| 3 | Light never crossed chunk borders (visible dark seams) | `compute_chunk_light_with_neighbours` + `World::relight_chunk`, used by the manager after every load / edit |
| 4 | `fall_distance` ignored the final tick of a fall; no landing event | exact accumulation + `landed_fall` event, water / ladders / flight cancel it |
| 5 | Lava behaved exactly like water for the player | separate `in_lava`, lava physics (0.5 drag, slow sink) |
| 6 | Trees were clipped to a 2-block margin → gaps at chunk borders, never a full canopy | placement RNG of the 3×3 neighbourhood is replayed per chunk → seamless trees of any size |
| 7 | Block edit re-lit only the edited chunk | border chunks are re-lit and re-meshed too |
| 8 | Mesher merged quads regardless of light | key now carries light + AO; vertices carry packed `sky<<4 \| block` |
| 9 | Block flags were `u8` (full) → impossible to add behaviours | `u16` flags: CROSS, GRAVITY, REPLACEABLE, CLIMBABLE, FLAMMABLE, REQUIRES_TOOL, RANDOM_TICK |
| 10 | Ore veins were 1-wide random walks | ellipsoid veins, deepslate variants, vanilla height bands |

### New systems (all dependency free, all unit-tested)
`biome` (42 biomes) · `trees` (13 generators) · `structures` · caves (cheese + spaghetti, lava below −54, lush /
dripstone) · rivers & oceans · `ticking` (water + lava flow, infinite water, obsidian / cobblestone, falling
blocks, random ticks: grass spread, leaf decay, saplings → trees, crops, ice) · `item` (1168 items) · `recipe`
(515 crafting + 68 smelting recipes) · `inventory` · `mining` (vanilla destroy-speed formula) · `effects`
(33 effects, 42 enchantments) · `game` (game modes, hunger, drowning, armour, fall damage, XP) · `entity`
(64 mobs with AI + spawn rules) · `explosion` · `time` (day/night, moon, weather) · `commands`
(17 slash commands) · `save` (palette + CRC-32 chunk files) · physics v2 (flying, swimming, ladders, ice, soul
sand, cobweb, honey).

### Numbers
415 blocks · 452 texture slots · 1168 items · 515 + 68 recipes · 42 biomes · 64 mobs · 33 effects · 42 enchantments.

## Modules
See the table at the top of `src/lib.rs` (`cargo doc --open`).

## Fidelity — what is matched, what is not
Matched to vanilla (covered by tests): `java.util.Random`, BlockPos / ChunkPos packing, VarInt, handshake / status,
paletted-container wire layout, heightmaps, 20 TPS, world height −64..320, hitbox, jump height ≈ 1.2522, walking
speed ≈ 4.317 b/s, collision axis order, step-up, destroy-speed formula (stone: 150 / 23 / 8 / 6 ticks for hand /
wood / iron / diamond pickaxe), explosion algorithm, armour & fall-damage formulas, XP curve.

**Not** 1:1: block-state ids are internal (no block-state properties yet: stairs / slabs / doors are *items* until
the renderer gets sub-block shapes), world generation is a noise approximation (seeds do not reproduce vanilla
terrain), no Nether / End, no redstone, no play-state network packets.

## License
MIT
