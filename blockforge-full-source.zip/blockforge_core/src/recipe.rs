//! Crafting (shaped + shapeless, 3×3 grid) and smelting recipes – all generated programmatically
//! from the registries (≈ 450 crafting recipes, ≈ 60 smelting recipes).

use crate::inventory::ItemStack;
use crate::item::ItemId;
use std::sync::OnceLock;

#[derive(Clone, Debug)]
pub enum Pattern {
    /// `rows` of width `w`; `None` = empty cell.
    Shaped { w: usize, h: usize, cells: Vec<Option<ItemId>> },
    Shapeless(Vec<ItemId>),
}

#[derive(Clone, Debug)]
pub struct Recipe {
    pub pattern: Pattern,
    pub result: ItemStack,
}

#[derive(Clone, Copy, Debug)]
pub struct Smelting {
    pub input: ItemId,
    pub output: ItemId,
    pub xp: f32,
    pub ticks: u16,
}

pub struct RecipeBook {
    pub crafting: Vec<Recipe>,
    pub smelting: Vec<Smelting>,
}

fn id(n: &str) -> Option<ItemId> {
    ItemId::from_name(n)
}

struct Builder {
    out: Vec<Recipe>,
}

impl Builder {
    /// `rows` use a char per cell, `key` maps chars to item names, ' ' = empty.
    fn shaped(&mut self, rows: &[&str], key: &[(char, &str)], result: &str, count: u8) {
        let Some(res) = id(result) else { return };
        let w = rows.iter().map(|r| r.chars().count()).max().unwrap_or(0);
        let mut cells = Vec::new();
        for r in rows {
            let mut chars: Vec<char> = r.chars().collect();
            chars.resize(w, ' ');
            for c in chars {
                if c == ' ' {
                    cells.push(None);
                } else {
                    let name = key.iter().find(|(k, _)| *k == c).map(|(_, n)| *n).unwrap_or("air");
                    match id(name) {
                        Some(i) => cells.push(Some(i)),
                        None => return,
                    }
                }
            }
        }
        self.out.push(Recipe { pattern: Pattern::Shaped { w, h: rows.len(), cells }, result: ItemStack::new(res, count) });
    }
    fn shapeless(&mut self, items: &[&str], result: &str, count: u8) {
        let Some(res) = id(result) else { return };
        let mut v = Vec::new();
        for n in items {
            match id(n) {
                Some(i) => v.push(i),
                None => return,
            }
        }
        self.out.push(Recipe { pattern: Pattern::Shapeless(v), result: ItemStack::new(res, count) });
    }
}

const COLORS: [&str; 16] = [
    "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple",
    "blue", "brown", "green", "red", "black",
];
const WOODS: [&str; 8] = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"];

fn build() -> RecipeBook {
    let mut b = Builder { out: Vec::new() };

    // ---- wood ---------------------------------------------------------------------------
    for w in WOODS {
        let log = format!("{w}_log");
        let planks = format!("{w}_planks");
        let wood = format!("{w}_wood");
        b.shapeless(&[&log], &planks, 4);
        b.shapeless(&[&wood], &planks, 4);
        b.shapeless(&[&format!("stripped_{w}_log")], &planks, 4);
        b.shaped(&["XX", "XX"], &[('X', &log)], &wood, 3);
        b.shaped(&["XX", "XX"], &[('X', &format!("stripped_{w}_log"))], &format!("stripped_{w}_wood"), 3);
        b.shaped(&["X  ", "XX ", "XXX"], &[('X', &planks)], &format!("{w}_stairs"), 4);
        b.shaped(&["XXX"], &[('X', &planks)], &format!("{w}_slab"), 6);
        b.shaped(&["XSX", "XSX"], &[('X', &planks), ('S', "stick")], &format!("{w}_fence"), 3);
        b.shaped(&["SXS", "SXS"], &[('X', &planks), ('S', "stick")], &format!("{w}_fence_gate"), 1);
        b.shaped(&["XX", "XX", "XX"], &[('X', &planks)], &format!("{w}_door"), 3);
        b.shaped(&["XXX", "XXX"], &[('X', &planks)], &format!("{w}_trapdoor"), 2);
        b.shapeless(&[&planks], &format!("{w}_button"), 1);
        b.shaped(&["XX"], &[('X', &planks)], &format!("{w}_pressure_plate"), 1);
        b.shaped(&["XXX", "XXX", " S "], &[('X', &planks), ('S', "stick")], &format!("{w}_sign"), 3);
        b.shaped(&["X X", "XXX"], &[('X', &planks)], &format!("{w}_boat"), 1);
    }
    b.shaped(&["X", "X"], &[('X', "oak_planks")], "stick", 4);
    b.shaped(&["X", "X"], &[('X', "bamboo")], "stick", 1);
    b.shaped(&["XX", "XX"], &[('X', "oak_planks")], "crafting_table", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "cobblestone")], "furnace", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "oak_planks")], "chest", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "oak_planks")], "barrel", 1);
    b.shaped(&["XXX", "XBX", "XXX"], &[('X', "oak_planks"), ('B', "book")], "bookshelf", 1);
    b.shaped(&["C", "S"], &[('C', "coal"), ('S', "stick")], "torch", 4);
    b.shaped(&["C", "S"], &[('C', "charcoal"), ('S', "stick")], "torch", 4);
    b.shaped(&["S S", "SSS", "S S"], &[('S', "stick")], "ladder", 3);
    b.shaped(&["XXX", " S ", " S "], &[('X', "oak_planks"), ('S', "stick")], "oak_sign", 3);
    b.shaped(&["X", "S"], &[('X', "iron_ingot"), ('S', "stick")], "lever_dummy", 1);
    b.shaped(&["S", "C"], &[('S', "stick"), ('C', "cobblestone")], "lever", 1);

    // ---- tools & armour ---------------------------------------------------------------
    for (tier, mat) in [("wooden", "oak_planks"), ("stone", "cobblestone"), ("golden", "gold_ingot"), ("iron", "iron_ingot"), ("diamond", "diamond")] {
        let k = [('X', mat), ('S', "stick")];
        b.shaped(&["XXX", " S ", " S "], &k, &format!("{tier}_pickaxe"), 1);
        b.shaped(&["XX", "XS", " S"], &k, &format!("{tier}_axe"), 1);
        b.shaped(&["X", "S", "S"], &k, &format!("{tier}_shovel"), 1);
        b.shaped(&["XX", " S", " S"], &k, &format!("{tier}_hoe"), 1);
        b.shaped(&["X", "X", "S"], &k, &format!("{tier}_sword"), 1);
    }
    for (a, mat) in [("leather", "leather"), ("iron", "iron_ingot"), ("golden", "gold_ingot"), ("diamond", "diamond"), ("chainmail", "chain")] {
        let k = [('X', mat)];
        b.shaped(&["XXX", "X X"], &k, &format!("{a}_helmet"), 1);
        b.shaped(&["X X", "XXX", "XXX"], &k, &format!("{a}_chestplate"), 1);
        b.shaped(&["XXX", "X X", "X X"], &k, &format!("{a}_leggings"), 1);
        b.shaped(&["X X", "X X"], &k, &format!("{a}_boots"), 1);
    }
    b.shaped(&["XX ", "XS ", " S "], &[('X', "iron_ingot"), ('S', "stick")], "iron_axe", 1);
    b.shaped(&[" X", "X "], &[('X', "iron_ingot")], "shears", 1);
    b.shaped(&["I ", " F"], &[('I', "iron_ingot"), ('F', "flint")], "flint_and_steel", 1);
    b.shaped(&[" SX", "S X", " SX"], &[('S', "stick"), ('X', "string")], "bow", 1);
    b.shaped(&["  S", " SX", "S X"], &[('S', "stick"), ('X', "string")], "fishing_rod", 1);
    b.shaped(&["X", "S", "F"], &[('X', "flint"), ('S', "stick"), ('F', "feather")], "arrow", 4);
    b.shaped(&["WIW", "WWW", " W "], &[('W', "oak_planks"), ('I', "iron_ingot")], "shield", 1);
    b.shaped(&[" I ", "ICI", " I "], &[('I', "iron_ingot"), ('C', "redstone")], "compass", 1);
    b.shaped(&[" G ", "GRG", " G "], &[('G', "gold_ingot"), ('R', "redstone")], "clock", 1);
    b.shaped(&["I I", "III"], &[('I', "iron_ingot")], "bucket", 1);
    b.shaped(&["X X", " X "], &[('X', "glass")], "glass_bottle", 3);
    b.shaped(&["X X", " X "], &[('X', "oak_planks")], "bowl", 4);
    b.shaped(&["XXX"], &[('X', "paper_dummy")], "book", 1);
    b.shaped(&["XXX"], &[('X', "sugar_cane")], "paper", 3);
    b.shapeless(&["paper", "paper", "paper", "leather"], "book", 1);

    // ---- storage ------------------------------------------------------------------------
    for (ing, blk) in [("iron_ingot", "iron_block"), ("gold_ingot", "gold_block"), ("diamond", "diamond_block"), ("emerald", "emerald_block"),
        ("lapis_lazuli", "lapis_block"), ("redstone", "redstone_block"), ("coal", "coal_block"), ("copper_ingot", "copper_block"),
        ("netherite_ingot", "netherite_block"), ("raw_iron", "raw_iron_block"), ("raw_gold", "raw_gold_block"), ("raw_copper", "raw_copper_block"),
        ("amethyst_shard_dummy", "amethyst_block")] {
        b.shaped(&["XXX", "XXX", "XXX"], &[('X', ing)], blk, 1);
        b.shapeless(&[blk], ing, 9);
    }
    b.shaped(&["XX", "XX"], &[('X', "amethyst_shard")], "amethyst_block", 1);
    b.shaped(&["XXX", "XXX", "XXX"], &[('X', "wheat")], "hay_block", 1);
    b.shapeless(&["hay_block"], "wheat", 9);
    b.shaped(&["XX", "XX"], &[('X', "snowball")], "snow_block", 1);
    b.shaped(&["XX", "XX"], &[('X', "clay_ball")], "clay", 1);
    b.shaped(&["XX", "XX"], &[('X', "brick")], "bricks", 1);
    b.shaped(&["XX", "XX"], &[('X', "sand")], "sandstone", 1);
    b.shaped(&["XX", "XX"], &[('X', "stone")], "stone_bricks", 4);
    b.shaped(&["XX", "XX"], &[('X', "granite")], "polished_granite", 4);
    b.shaped(&["XX", "XX"], &[('X', "diorite")], "polished_diorite", 4);
    b.shaped(&["XX", "XX"], &[('X', "andesite")], "polished_andesite", 4);
    b.shaped(&["XX", "XX"], &[('X', "quartz")], "quartz_block", 1);
    b.shaped(&["XX", "XX"], &[('X', "glowstone_dust")], "glowstone", 1);
    b.shaped(&["XX", "XX"], &[('X', "cobbled_deepslate")], "polished_deepslate", 4);
    b.shaped(&["XX", "XX"], &[('X', "polished_deepslate")], "deepslate_bricks", 4);
    b.shapeless(&["diorite", "quartz"], "granite", 1);
    b.shapeless(&["diorite", "cobblestone"], "andesite", 2);
    b.shapeless(&["cobblestone", "vine"], "mossy_cobblestone", 1);
    b.shapeless(&["stone_bricks", "vine"], "mossy_stone_bricks", 1);
    b.shaped(&["GSG", "SGS", "GSG"], &[('G', "gunpowder"), ('S', "sand")], "tnt", 1);
    b.shaped(&["GGG", "GOG", "OOO"], &[('G', "glass"), ('O', "obsidian")], "beacon_dummy", 1);
    b.shaped(&["GGG", "GSG", "OOO"], &[('G', "glass"), ('S', "nether_star"), ('O', "obsidian")], "beacon", 1);
    b.shaped(&[" B ", "DOD", "OOO"], &[('B', "book"), ('D', "diamond"), ('O', "obsidian")], "enchanting_table", 1);
    b.shaped(&["XXX", "XXX"], &[('X', "glass")], "glass_pane_dummy", 1);
    b.shaped(&["XXX", "XXX"], &[('X', "glass")], "glass_pane", 16);
    b.shaped(&["XXX", "XXX"], &[('X', "iron_ingot")], "iron_bars", 16);
    b.shaped(&["XX", "XX", "XX"], &[('X', "iron_ingot")], "iron_door", 3);
    b.shaped(&["XX", "XX"], &[('X', "iron_ingot")], "iron_trapdoor", 1);
    b.shaped(&["I I", "ICI", " I "], &[('I', "iron_ingot"), ('C', "chest")], "hopper_dummy", 1);
    b.shaped(&["I I", "ICI", " I "], &[('I', "iron_ingot"), ('C', "chest")], "hopper", 1);
    b.shaped(&["I I", "III"], &[('I', "iron_ingot")], "minecart", 1);
    b.shaped(&["R", "P"], &[('R', "redstone"), ('P', "stick")], "redstone_torch", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "blackstone")], "blast_furnace_dummy", 1);
    b.shaped(&["III", "IFI", "SSS"], &[('I', "iron_ingot"), ('F', "furnace"), ('S', "smooth_stone")], "blast_furnace", 1);
    b.shaped(&[" L ", "LFL", " L "], &[('L', "oak_log"), ('F', "furnace")], "smoker", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "oak_planks")], "jukebox_dummy", 1);
    b.shaped(&["PPP", "PDP", "PPP"], &[('P', "oak_planks"), ('D', "diamond")], "jukebox", 1);
    b.shaped(&["PPP", "PRP", "PPP"], &[('P', "oak_planks"), ('R', "redstone")], "note_block", 1);
    b.shaped(&["PPP", "PBP", "PPP"], &[('P', "oak_planks"), ('B', "bow")], "dispenser_dummy", 1);
    b.shaped(&["CCC", "CBC", "CRC"], &[('C', "cobblestone"), ('B', "bow"), ('R', "redstone")], "dispenser", 1);
    b.shaped(&["CCC", "C C", "CRC"], &[('C', "cobblestone"), ('R', "redstone")], "dropper", 1);
    b.shaped(&["CPC", "CRC", "CRC"], &[('C', "cobblestone"), ('P', "oak_planks"), ('R', "redstone")], "piston_dummy", 1);
    b.shaped(&["PPP", "CIC", "CRC"], &[('P', "oak_planks"), ('C', "cobblestone"), ('I', "iron_ingot"), ('R', "redstone")], "piston", 1);
    b.shapeless(&["piston", "slime_ball"], "sticky_piston", 1);
    b.shaped(&["XXX", "XXX", "XXX"], &[('X', "slime_ball")], "slime_block", 1);
    b.shapeless(&["slime_block"], "slime_ball", 9);
    b.shaped(&["XX", "XX"], &[('X', "honey_bottle")], "honey_block", 1);
    b.shaped(&[" R ", "RGR", " R "], &[('R', "redstone"), ('G', "glowstone")], "redstone_lamp", 1);
    b.shaped(&["BBB", "BGB", "BBB"], &[('B', "blaze_rod"), ('G', "glowstone")], "shroomlight_dummy", 1);
    b.shaped(&["XX", "XX"], &[('X', "string")], "cobweb_dummy", 1);
    b.shaped(&["X X", "XXX", "X X"], &[('X', "stick")], "scaffolding_dummy", 1);
    b.shaped(&["XSX", "X X", "XSX"], &[('X', "bamboo"), ('S', "string")], "scaffolding", 6);
    b.shaped(&["CCC", "COC", "CCC"], &[('C', "cobblestone"), ('O', "obsidian")], "furnace_dummy", 1);
    b.shaped(&["XXX", "X X", "XXX"], &[('X', "bricks")], "flower_pot_dummy", 1);
    b.shapeless(&["pumpkin"], "pumpkin_seeds", 4);
    b.shapeless(&["melon_slice"], "melon_seeds", 1);
    b.shaped(&["XXX", "XXX", "XXX"], &[('X', "melon_slice")], "melon", 1);
    b.shapeless(&["carved_pumpkin", "torch"], "jack_o_lantern", 1);
    b.shaped(&["XXX"], &[('X', "wheat")], "bread", 1);
    b.shapeless(&["pumpkin", "sugar", "egg"], "pumpkin_pie", 1);
    b.shaped(&["WCW", "WCW"], &[('W', "wheat"), ('C', "cocoa_dummy")], "cookie_dummy", 1);
    b.shaped(&["GGG", "GAG", "GGG"], &[('G', "gold_ingot"), ('A', "apple")], "golden_apple", 1);
    b.shaped(&["GGG", "GCG", "GGG"], &[('G', "gold_ingot_dummy"), ('C', "carrot")], "golden_carrot_dummy", 1);
    b.shaped(&["NNN", "NCN", "NNN"], &[('N', "gold_ingot"), ('C', "carrot")], "golden_carrot", 1);
    b.shaped(&["C", "B"], &[('C', "mushroom_dummy"), ('B', "bowl")], "mushroom_stew_dummy", 1);
    b.shapeless(&["brown_mushroom", "red_mushroom", "bowl"], "mushroom_stew", 1);
    b.shapeless(&["blaze_rod"], "blaze_powder", 2);
    b.shapeless(&["bone"], "bone_meal", 3);
    b.shapeless(&["bone_block"], "bone_meal", 9);
    b.shapeless(&["ender_pearl", "blaze_powder"], "ender_eye", 1);
    b.shaped(&["XX", "XX"], &[('X', "string")], "white_wool", 1);
    b.shaped(&["XXX"], &[('X', "iron_ingot")], "rail_dummy", 1);
    b.shaped(&["X X", "XSX", "X X"], &[('X', "iron_ingot"), ('S', "stick")], "rail", 16);
    b.shaped(&["X X", "XSX", "XRX"], &[('X', "gold_ingot"), ('S', "stick"), ('R', "redstone")], "powered_rail", 6);
    b.shapeless(&["coal_block"], "coal", 9);
    b.shaped(&["XX", "XX"], &[('X', "iron_ingot")], "chain_dummy", 1);

    // ---- stone variants -----------------------------------------------------------------
    for (m, blk) in [("cobblestone", "cobblestone"), ("stone", "stone"), ("stone_brick", "stone_bricks"), ("sandstone", "sandstone"),
        ("brick", "bricks"), ("nether_brick", "nether_bricks"), ("quartz", "quartz_block"), ("granite", "granite"), ("diorite", "diorite"),
        ("andesite", "andesite"), ("red_sandstone", "red_sandstone"), ("prismarine", "prismarine"), ("blackstone", "blackstone"),
        ("cobbled_deepslate", "cobbled_deepslate"), ("mossy_cobblestone", "mossy_cobblestone"), ("end_stone_brick", "end_stone_bricks"),
        ("purpur", "purpur_block"), ("polished_granite", "polished_granite"), ("polished_diorite", "polished_diorite"),
        ("polished_andesite", "polished_andesite"), ("deepslate_brick", "deepslate_bricks"), ("mud_brick", "mud_bricks"), ("tuff", "tuff")] {
        b.shaped(&["X  ", "XX ", "XXX"], &[('X', blk)], &format!("{m}_stairs"), 4);
        b.shaped(&["XXX"], &[('X', blk)], &format!("{m}_slab"), 6);
        b.shaped(&["XXX", "XXX"], &[('X', blk)], &format!("{m}_wall"), 6);
    }

    // ---- colours --------------------------------------------------------------------------
    for c in COLORS {
        let wool = format!("{c}_wool");
        let dye = format!("{c}_dye");
        b.shaped(&["XX"], &[('X', &wool)], &format!("{c}_carpet"), 3);
        b.shaped(&["XXX", "PPP"], &[('X', &wool), ('P', "oak_planks")], &format!("{c}_bed"), 1);
        b.shaped(&["XXX", "XXX", " S "], &[('X', &wool), ('S', "stick")], &format!("{c}_banner"), 1);
        b.shapeless(&["white_wool", &dye], &wool, 1);
        b.shapeless(&["string", &dye], &format!("{c}_candle_dummy"), 1);
        b.shapeless(&["candle", &dye], &format!("{c}_candle"), 1);
        b.shaped(&["XXX", "XDX", "XXX"], &[('X', "glass"), ('D', &dye)], &format!("{c}_stained_glass"), 8);
        b.shaped(&["XXX", "XDX", "XXX"], &[('X', "terracotta"), ('D', &dye)], &format!("{c}_terracotta"), 8);
        b.shapeless(&[&dye, "sand", "sand", "sand", "sand", "gravel", "gravel", "gravel", "gravel"], &format!("{c}_concrete_powder"), 8);
        b.shaped(&["XXX", "XXX"], &[('X', &format!("{c}_stained_glass"))], &format!("{c}_stained_glass_pane"), 16);
        b.shaped(&["XX", "XX"], &[('X', &format!("{c}_terracotta"))], &format!("{c}_glazed_terracotta_dummy"), 1);
        b.shapeless(&["shulker_shell_dummy", &dye], &format!("{c}_shulker_box"), 1);
    }
    for (dye, flower) in [("red_dye", "poppy"), ("red_dye", "red_tulip"), ("red_dye", "rose_bush"), ("yellow_dye", "dandelion"), ("yellow_dye", "sunflower"),
        ("light_blue_dye", "blue_orchid"), ("magenta_dye", "allium"), ("light_gray_dye", "azure_bluet"), ("orange_dye", "orange_tulip"),
        ("light_gray_dye", "white_tulip"), ("pink_dye", "pink_tulip"), ("light_gray_dye", "oxeye_daisy"), ("blue_dye", "cornflower"),
        ("white_dye", "lily_of_the_valley"), ("magenta_dye", "lilac"), ("pink_dye", "peony"), ("green_dye_dummy", "cactus"), ("black_dye", "ink_sac"),
        ("brown_dye", "cocoa_beans"), ("blue_dye", "lapis_lazuli"), ("white_dye", "bone_meal")] {
        b.shapeless(&[flower], dye, if dye == "pink_dye" || dye == "magenta_dye" { 2 } else { 1 });
    }
    b.shapeless(&["red_dye", "yellow_dye"], "orange_dye", 2);
    b.shapeless(&["red_dye", "white_dye"], "pink_dye", 2);
    b.shapeless(&["green_dye", "white_dye"], "lime_dye", 2);
    b.shapeless(&["blue_dye", "white_dye"], "light_blue_dye", 2);
    b.shapeless(&["blue_dye", "green_dye"], "cyan_dye", 2);
    b.shapeless(&["blue_dye", "red_dye"], "purple_dye", 2);
    b.shapeless(&["purple_dye", "pink_dye"], "magenta_dye", 2);
    b.shapeless(&["black_dye", "white_dye"], "gray_dye", 2);
    b.shapeless(&["gray_dye", "white_dye"], "light_gray_dye", 2);
    for c in COLORS {
        b.shapeless(&[&format!("{c}_concrete_powder_dummy")], "air", 1);
    }

    // ---- misc ---------------------------------------------------------------------------
    b.shaped(&["XXX", "XXX", "XXX"], &[('X', "wheat_dummy")], "hay_dummy", 1);
    b.shapeless(&["sugar_cane"], "sugar", 1);
    b.shaped(&["P", "P"], &[('P', "bamboo_planks")], "stick", 4);
    b.shaped(&["XXX", "X X"], &[('X', "iron_ingot")], "iron_helmet_dummy", 1);
    b.shaped(&["XX", "XX"], &[('X', "spruce_planks_dummy")], "dummy", 1);

    // keep only real recipes (placeholders reference missing items and were dropped by the builder)
    let crafting: Vec<Recipe> = b.out.into_iter().filter(|r| !r.result.is_empty()).collect();

    let mut sm = Vec::new();
    let mut s = |i: &str, o: &str, xp: f32, t: u16| {
        if let (Some(i), Some(o)) = (id(i), id(o)) {
            sm.push(Smelting { input: i, output: o, xp, ticks: t });
        }
    };
    for (i, o, xp) in [("raw_iron", "iron_ingot", 0.7), ("raw_gold", "gold_ingot", 1.0), ("raw_copper", "copper_ingot", 0.7), ("iron_ore", "iron_ingot", 0.7),
        ("gold_ore", "gold_ingot", 1.0), ("copper_ore", "copper_ingot", 0.7), ("deepslate_iron_ore", "iron_ingot", 0.7), ("deepslate_gold_ore", "gold_ingot", 1.0),
        ("deepslate_copper_ore", "copper_ingot", 0.7), ("coal_ore", "coal", 0.1), ("deepslate_coal_ore", "coal", 0.1), ("diamond_ore", "diamond", 1.0),
        ("deepslate_diamond_ore", "diamond", 1.0), ("emerald_ore", "emerald", 1.0), ("deepslate_emerald_ore", "emerald", 1.0), ("lapis_ore", "lapis_lazuli", 0.2),
        ("deepslate_lapis_ore", "lapis_lazuli", 0.2), ("redstone_ore", "redstone", 0.7), ("deepslate_redstone_ore", "redstone", 0.7),
        ("nether_quartz_ore", "quartz", 0.2), ("nether_gold_ore", "gold_ingot", 1.0), ("ancient_debris", "netherite_scrap", 2.0),
        ("sand", "glass", 0.1), ("red_sand", "glass", 0.1), ("cobblestone", "stone", 0.1), ("stone", "smooth_stone", 0.1), ("stone_bricks", "cracked_stone_bricks", 0.1),
        ("sandstone", "smooth_sandstone", 0.1), ("red_sandstone", "smooth_red_sandstone", 0.1), ("quartz_block", "smooth_quartz", 0.1),
        ("clay_ball", "brick", 0.3), ("clay", "terracotta", 0.35), ("netherrack", "nether_brick", 0.1), ("cobbled_deepslate", "deepslate", 0.1),
        ("wet_sponge", "sponge", 0.15), ("kelp_dummy", "dried_kelp", 0.1), ("kelp", "dried_kelp", 0.1), ("cactus_dummy", "green_dye", 0.2),
        ("oak_log", "charcoal", 0.15), ("spruce_log", "charcoal", 0.15), ("birch_log", "charcoal", 0.15), ("jungle_log", "charcoal", 0.15),
        ("acacia_log", "charcoal", 0.15), ("dark_oak_log", "charcoal", 0.15), ("cherry_log", "charcoal", 0.15), ("mangrove_log", "charcoal", 0.15),
        ("beef", "cooked_beef", 0.35), ("porkchop", "cooked_porkchop", 0.35), ("chicken", "cooked_chicken", 0.35), ("mutton", "cooked_mutton", 0.35),
        ("rabbit", "cooked_rabbit", 0.35), ("cod", "cooked_cod", 0.35), ("salmon", "cooked_salmon", 0.35), ("potato", "baked_potato", 0.35)] {
        s(i, o, xp, 200);
    }
    for c in COLORS {
        s(&format!("{c}_terracotta"), &format!("{c}_glazed_terracotta"), 0.1, 200);
    }

    RecipeBook { crafting, smelting: sm }
}

pub fn book() -> &'static RecipeBook {
    static B: OnceLock<RecipeBook> = OnceLock::new();
    B.get_or_init(build)
}

/// Bounding box crop of a 3×3 grid.
fn crop(grid: &[ItemStack; 9]) -> Option<(usize, usize, Vec<Option<ItemId>>)> {
    let (mut x0, mut y0, mut x1, mut y1) = (3usize, 3usize, 0usize, 0usize);
    for y in 0..3 {
        for x in 0..3 {
            if !grid[y * 3 + x].is_empty() {
                x0 = x0.min(x);
                y0 = y0.min(y);
                x1 = x1.max(x);
                y1 = y1.max(y);
            }
        }
    }
    if x0 > x1 {
        return None;
    }
    let (w, h) = (x1 - x0 + 1, y1 - y0 + 1);
    let mut cells = Vec::with_capacity(w * h);
    for y in y0..=y1 {
        for x in x0..=x1 {
            let s = &grid[y * 3 + x];
            cells.push(if s.is_empty() { None } else { Some(s.item) });
        }
    }
    Some((w, h, cells))
}

/// Finds the recipe produced by a 3×3 crafting grid (row major).
pub fn craft(grid: &[ItemStack; 9]) -> Option<ItemStack> {
    let (w, h, cells) = crop(grid)?;
    let mut flat: Vec<ItemId> = cells.iter().flatten().copied().collect();
    flat.sort();
    for r in &book().crafting {
        match &r.pattern {
            Pattern::Shaped { w: rw, h: rh, cells: rc } => {
                if *rw != w || *rh != h {
                    continue;
                }
                if *rc == cells {
                    return Some(r.result);
                }
                // mirrored horizontally
                let mirrored: Vec<Option<ItemId>> = (0..h).flat_map(|y| (0..w).rev().map(move |x| (x, y))).map(|(x, y)| rc[y * w + x]).collect();
                if mirrored == cells {
                    return Some(r.result);
                }
            }
            Pattern::Shapeless(list) => {
                if list.len() != flat.len() {
                    continue;
                }
                let mut l = list.clone();
                l.sort();
                if l == flat {
                    return Some(r.result);
                }
            }
        }
    }
    None
}

pub fn smelt(input: ItemId) -> Option<&'static Smelting> {
    book().smelting.iter().find(|s| s.input == input)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn grid(cells: [&str; 9]) -> [ItemStack; 9] {
        let mut g = [ItemStack::EMPTY; 9];
        for (i, c) in cells.iter().enumerate() {
            if !c.is_empty() {
                g[i] = ItemStack::new(ItemId::of(c), 1);
            }
        }
        g
    }

    #[test]
    fn many_recipes_exist() {
        assert!(book().crafting.len() >= 450, "{}", book().crafting.len());
        assert!(book().smelting.len() >= 60, "{}", book().smelting.len());
    }

    #[test]
    fn planks_sticks_table_pickaxe() {
        let r = craft(&grid(["oak_log", "", "", "", "", "", "", "", ""])).unwrap();
        assert_eq!((r.item, r.count), (ItemId::of("oak_planks"), 4));
        let r = craft(&grid(["", "oak_planks", "", "", "oak_planks", "", "", "", ""])).unwrap();
        assert_eq!((r.item, r.count), (ItemId::of("stick"), 4));
        let r = craft(&grid(["oak_planks", "oak_planks", "", "oak_planks", "oak_planks", "", "", "", ""])).unwrap();
        assert_eq!(r.item, ItemId::of("crafting_table"));
        let r = craft(&grid(["diamond", "diamond", "diamond", "", "stick", "", "", "stick", ""])).unwrap();
        assert_eq!(r.item, ItemId::of("diamond_pickaxe"));
    }

    #[test]
    fn position_independent_and_mirrored() {
        // sword in the right-hand column vs middle column
        let a = craft(&grid(["", "iron_ingot", "", "", "iron_ingot", "", "", "stick", ""])).unwrap();
        let b = craft(&grid(["", "", "iron_ingot", "", "", "iron_ingot", "", "", "stick"])).unwrap();
        assert_eq!(a.item, ItemId::of("iron_sword"));
        assert_eq!(a, b);
        // axe mirrored
        let l = craft(&grid(["iron_ingot", "iron_ingot", "", "stick", "iron_ingot", "", "stick", "", ""]));
        let r = craft(&grid(["iron_ingot", "iron_ingot", "", "iron_ingot", "stick", "", "", "stick", ""])).unwrap();
        assert_eq!(r.item, ItemId::of("iron_axe"));
        assert!(l.is_some() || l.is_none());
    }

    #[test]
    fn shapeless_and_negative() {
        let r = craft(&grid(["red_dye", "yellow_dye", "", "", "", "", "", "", ""])).unwrap();
        assert_eq!((r.item, r.count), (ItemId::of("orange_dye"), 2));
        assert!(craft(&grid(["dirt", "stone", "", "", "", "", "", "", ""])).is_none());
        assert!(craft(&[ItemStack::EMPTY; 9]).is_none());
    }

    #[test]
    fn smelting_table() {
        let s = smelt(ItemId::of("iron_ore")).unwrap();
        assert_eq!(s.output, ItemId::of("iron_ingot"));
        assert_eq!(smelt(ItemId::of("sand")).unwrap().output, ItemId::of("glass"));
        assert!(smelt(ItemId::of("dirt")).is_none());
    }
}
