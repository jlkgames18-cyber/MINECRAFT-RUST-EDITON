//! Random number generators.
//!
//! * [`JavaRandom`]  – bit-exact port of the `java.util.Random` 48-bit LCG
//!   (used by legacy world generation, slime chunks, structures placement, ...).
//! * [`Xoroshiro128pp`] – Xoroshiro128++ with the same seeding scheme (Stafford mix 13)
//!   used by the modern (1.18+) world generator.

pub trait RandomSource {
    fn next_i32(&mut self) -> i32;
    fn next_i32_bounded(&mut self, bound: i32) -> i32;
    fn next_i64(&mut self) -> i64;
    fn next_bool(&mut self) -> bool;
    fn next_f32(&mut self) -> f32;
    fn next_f64(&mut self) -> f64;

    fn next_i32_between(&mut self, min_inclusive: i32, max_inclusive: i32) -> i32 {
        self.next_i32_bounded(max_inclusive - min_inclusive + 1) + min_inclusive
    }
}

const MULTIPLIER: i64 = 0x5DEE_CE66D;
const ADDEND: i64 = 0xB;
const MASK: i64 = (1i64 << 48) - 1;

#[derive(Clone, Debug)]
pub struct JavaRandom {
    seed: i64,
    next_next_gaussian: f64,
    have_next_next_gaussian: bool,
}

impl JavaRandom {
    pub fn new(seed: i64) -> Self {
        Self { seed: (seed ^ MULTIPLIER) & MASK, next_next_gaussian: 0.0, have_next_next_gaussian: false }
    }

    pub fn set_seed(&mut self, seed: i64) {
        self.seed = (seed ^ MULTIPLIER) & MASK;
        self.have_next_next_gaussian = false;
    }

    #[inline]
    fn next(&mut self, bits: u32) -> i32 {
        self.seed = self.seed.wrapping_mul(MULTIPLIER).wrapping_add(ADDEND) & MASK;
        (self.seed >> (48 - bits)) as i32
    }

    pub fn next_gaussian(&mut self) -> f64 {
        if self.have_next_next_gaussian {
            self.have_next_next_gaussian = false;
            return self.next_next_gaussian;
        }
        loop {
            let v1 = 2.0 * self.next_f64() - 1.0;
            let v2 = 2.0 * self.next_f64() - 1.0;
            let s = v1 * v1 + v2 * v2;
            if s < 1.0 && s != 0.0 {
                let mul = (-2.0 * s.ln() / s).sqrt();
                self.next_next_gaussian = v2 * mul;
                self.have_next_next_gaussian = true;
                return v1 * mul;
            }
        }
    }
}

impl RandomSource for JavaRandom {
    #[inline]
    fn next_i32(&mut self) -> i32 {
        self.next(32)
    }

    #[inline]
    fn next_i32_bounded(&mut self, bound: i32) -> i32 {
        assert!(bound > 0, "bound must be positive");
        if (bound & (bound - 1)) == 0 {
            return ((bound as i64).wrapping_mul(self.next(31) as i64) >> 31) as i32;
        }
        loop {
            let bits = self.next(31);
            let val = bits % bound;
            // Java detects int overflow of `bits - val + (bound - 1)`.
            if bits.wrapping_sub(val).wrapping_add(bound - 1) >= 0 {
                return val;
            }
        }
    }

    #[inline]
    fn next_i64(&mut self) -> i64 {
        ((self.next(32) as i64) << 32).wrapping_add(self.next(32) as i64)
    }

    #[inline]
    fn next_bool(&mut self) -> bool {
        self.next(1) != 0
    }

    #[inline]
    fn next_f32(&mut self) -> f32 {
        self.next(24) as f32 / (1 << 24) as f32
    }

    #[inline]
    fn next_f64(&mut self) -> f64 {
        let hi = (self.next(26) as i64) << 27;
        let lo = self.next(27) as i64;
        (hi + lo) as f64 * (1.0 / (1u64 << 53) as f64)
    }
}

// --------------------------------------------------------------------------------------------

const GOLDEN_RATIO_64: u64 = 0x9E37_79B9_7F4A_7C15;
const SILVER_RATIO_64: u64 = 0x6A09_E667_F3BC_C909;

#[inline]
pub fn mix_stafford13(mut z: u64) -> u64 {
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

#[derive(Clone, Debug)]
pub struct Xoroshiro128pp {
    lo: u64,
    hi: u64,
}

impl Xoroshiro128pp {
    pub fn new(lo: u64, hi: u64) -> Self {
        if (lo | hi) == 0 {
            Self { lo: GOLDEN_RATIO_64, hi: SILVER_RATIO_64 }
        } else {
            Self { lo, hi }
        }
    }

    pub fn from_seed(seed: i64) -> Self {
        let l = (seed as u64) ^ SILVER_RATIO_64;
        let m = l.wrapping_add(GOLDEN_RATIO_64);
        Self::new(mix_stafford13(l), mix_stafford13(m))
    }

    #[inline]
    fn next_u64(&mut self) -> u64 {
        let l = self.lo;
        let mut m = self.hi;
        let n = l.wrapping_add(m).rotate_left(17).wrapping_add(l);
        m ^= l;
        self.lo = l.rotate_left(49) ^ m ^ (m << 21);
        self.hi = m.rotate_left(28);
        n
    }

    #[inline]
    fn next_bits(&mut self, bits: u32) -> i64 {
        (self.next_u64() >> (64 - bits)) as i64
    }
}

impl RandomSource for Xoroshiro128pp {
    #[inline]
    fn next_i32(&mut self) -> i32 {
        self.next_u64() as i32
    }

    #[inline]
    fn next_i32_bounded(&mut self, bound: i32) -> i32 {
        assert!(bound > 0, "bound must be positive");
        let bound_u = bound as u64;
        let mut l = (self.next_u64() as u32) as u64;
        let mut m = l * bound_u;
        let mut n = m & 0xFFFF_FFFF;
        if n < bound_u {
            let threshold = ((!(bound as u32)).wrapping_add(1) % (bound as u32)) as u64;
            while n < threshold {
                l = (self.next_u64() as u32) as u64;
                m = l * bound_u;
                n = m & 0xFFFF_FFFF;
            }
        }
        (m >> 32) as i32
    }

    #[inline]
    fn next_i64(&mut self) -> i64 {
        self.next_u64() as i64
    }

    #[inline]
    fn next_bool(&mut self) -> bool {
        (self.next_u64() & 1) != 0
    }

    #[inline]
    fn next_f32(&mut self) -> f32 {
        self.next_bits(24) as f32 * (1.0 / (1u32 << 24) as f32)
    }

    #[inline]
    fn next_f64(&mut self) -> f64 {
        self.next_bits(53) as f64 * (1.0 / (1u64 << 53) as f64)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn java_random_known_vectors() {
        // Reference values produced by the real java.util.Random.
        assert_eq!(JavaRandom::new(42).next_i32(), -1170105035);
        assert_eq!(JavaRandom::new(0).next_i32(), -1155484576);
        assert_eq!(JavaRandom::new(0).next_i64(), -4962768465676381896);
    }

    #[test]
    fn java_random_bounded_in_range() {
        let mut r = JavaRandom::new(123);
        for _ in 0..10_000 {
            let v = r.next_i32_bounded(100);
            assert!((0..100).contains(&v));
            let p = r.next_i32_bounded(16);
            assert!((0..16).contains(&p));
        }
    }

    #[test]
    fn java_random_double_in_unit_interval() {
        let mut r = JavaRandom::new(7);
        for _ in 0..10_000 {
            let d = r.next_f64();
            assert!((0.0..1.0).contains(&d));
        }
    }

    #[test]
    fn xoroshiro_deterministic_and_bounded() {
        let mut a = Xoroshiro128pp::from_seed(12345);
        let mut b = Xoroshiro128pp::from_seed(12345);
        for _ in 0..1000 {
            assert_eq!(a.next_i64(), b.next_i64());
        }
        let mut c = Xoroshiro128pp::from_seed(1);
        for _ in 0..10_000 {
            assert!((0..7).contains(&c.next_i32_bounded(7)));
        }
    }

    #[test]
    fn xoroshiro_zero_state_is_fixed() {
        let mut r = Xoroshiro128pp::new(0, 0);
        assert_ne!(r.next_i64(), 0);
    }
}
