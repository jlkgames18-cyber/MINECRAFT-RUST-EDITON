//! Chunk persistence: compact palette format with CRC-32 (`.bfc` files, one per chunk).
//!
//! Layout (little endian): `"BFC1"` · version u8 · chunk x i32 · chunk z i32 · 24 × section ·
//! crc32 u32 of everything before it. A section is `0, u16 value` (uniform) or
//! `1, u16 palette_len, palette u16…, bits u8, longs u32 count, i64…` followed by 64 biome bytes.
//! Light is not stored – it is recomputed on load.

use crate::block::BlockId;
use crate::chunk::{pack_values, unpack_values, Chunk, SECTION_VOLUME};
use crate::math::{ChunkPos, SECTION_COUNT};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

pub const MAGIC: &[u8; 4] = b"BFC1";
pub const VERSION: u8 = 1;

#[derive(Debug)]
pub enum SaveError {
    BadMagic,
    BadVersion(u8),
    Truncated,
    Checksum { expected: u32, found: u32 },
    Corrupt(&'static str),
    Io(std::io::Error),
}

impl std::fmt::Display for SaveError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{self:?}")
    }
}
impl std::error::Error for SaveError {}
impl From<std::io::Error> for SaveError {
    fn from(e: std::io::Error) -> Self {
        SaveError::Io(e)
    }
}

pub fn crc32(data: &[u8]) -> u32 {
    let mut table = [0u32; 256];
    for (i, t) in table.iter_mut().enumerate() {
        let mut c = i as u32;
        for _ in 0..8 {
            c = if c & 1 != 0 { 0xEDB8_8320 ^ (c >> 1) } else { c >> 1 };
        }
        *t = c;
    }
    let mut crc = 0xFFFF_FFFFu32;
    for &b in data {
        crc = table[((crc ^ b as u32) & 0xFF) as usize] ^ (crc >> 8);
    }
    !crc
}

pub fn serialize_chunk(chunk: &Chunk) -> Vec<u8> {
    let mut out = Vec::with_capacity(8192);
    out.extend_from_slice(MAGIC);
    out.push(VERSION);
    out.extend_from_slice(&chunk.pos.x.to_le_bytes());
    out.extend_from_slice(&chunk.pos.z.to_le_bytes());
    for s in &chunk.sections {
        match s.uniform_value() {
            Some(v) => {
                out.push(0);
                out.extend_from_slice(&v.0.to_le_bytes());
            }
            None => {
                let mut palette: Vec<u16> = Vec::new();
                let mut lookup: HashMap<u16, u16> = HashMap::new();
                let mut idx = Vec::with_capacity(SECTION_VOLUME);
                for y in 0..16 {
                    for z in 0..16 {
                        for x in 0..16 {
                            let id = s.get(x, y, z).0;
                            let i = *lookup.entry(id).or_insert_with(|| {
                                palette.push(id);
                                (palette.len() - 1) as u16
                            });
                            idx.push(i);
                        }
                    }
                }
                let bits = (usize::BITS - (palette.len().max(2) - 1).leading_zeros()).max(1) as u8;
                out.push(1);
                out.extend_from_slice(&(palette.len() as u16).to_le_bytes());
                for p in &palette {
                    out.extend_from_slice(&p.to_le_bytes());
                }
                out.push(bits);
                let longs = pack_values(&idx, bits);
                out.extend_from_slice(&(longs.len() as u32).to_le_bytes());
                for l in longs {
                    out.extend_from_slice(&l.to_le_bytes());
                }
            }
        }
        out.extend_from_slice(&s.biomes);
    }
    let crc = crc32(&out);
    out.extend_from_slice(&crc.to_le_bytes());
    out
}

struct Reader<'a> {
    d: &'a [u8],
    p: usize,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> Result<&'a [u8], SaveError> {
        let end = self.p.checked_add(n).ok_or(SaveError::Truncated)?;
        let s = self.d.get(self.p..end).ok_or(SaveError::Truncated)?;
        self.p = end;
        Ok(s)
    }
    fn u8(&mut self) -> Result<u8, SaveError> {
        Ok(self.take(1)?[0])
    }
    fn u16(&mut self) -> Result<u16, SaveError> {
        Ok(u16::from_le_bytes(self.take(2)?.try_into().unwrap()))
    }
    fn u32(&mut self) -> Result<u32, SaveError> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn i32(&mut self) -> Result<i32, SaveError> {
        Ok(self.u32()? as i32)
    }
    fn i64(&mut self) -> Result<i64, SaveError> {
        Ok(i64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
}

/// Parses a chunk; light is recomputed (without neighbours – call `World::relight_chunk` later).
pub fn deserialize_chunk(data: &[u8]) -> Result<Chunk, SaveError> {
    if data.len() < 4 + 1 + 8 + 4 {
        return Err(SaveError::Truncated);
    }
    let (body, tail) = data.split_at(data.len() - 4);
    let expected = u32::from_le_bytes(tail.try_into().unwrap());
    let found = crc32(body);
    if &body[..4] != MAGIC {
        return Err(SaveError::BadMagic);
    }
    if expected != found {
        return Err(SaveError::Checksum { expected, found });
    }
    let mut r = Reader { d: body, p: 4 };
    let v = r.u8()?;
    if v != VERSION {
        return Err(SaveError::BadVersion(v));
    }
    let pos = ChunkPos::new(r.i32()?, r.i32()?);
    let mut chunk = Chunk::new(pos);
    for si in 0..SECTION_COUNT {
        match r.u8()? {
            0 => {
                let id = r.u16()?;
                chunk.sections[si].fill(BlockId(id));
            }
            1 => {
                let n = r.u16()? as usize;
                if n == 0 || n > SECTION_VOLUME {
                    return Err(SaveError::Corrupt("palette size"));
                }
                let mut palette = Vec::with_capacity(n);
                for _ in 0..n {
                    palette.push(r.u16()?);
                }
                let bits = r.u8()?;
                if !(1..=16).contains(&bits) {
                    return Err(SaveError::Corrupt("bits"));
                }
                let count = r.u32()? as usize;
                if count > SECTION_VOLUME {
                    return Err(SaveError::Corrupt("long count"));
                }
                let mut longs = Vec::with_capacity(count);
                for _ in 0..count {
                    longs.push(r.i64()?);
                }
                if count < SECTION_VOLUME.div_ceil(64 / bits as usize) {
                    return Err(SaveError::Corrupt("short data"));
                }
                let idx = unpack_values(&longs, bits, SECTION_VOLUME);
                let sec = &mut chunk.sections[si];
                for (i, &pi) in idx.iter().enumerate() {
                    let id = *palette.get(pi as usize).ok_or(SaveError::Corrupt("palette index"))?;
                    sec.set(i & 15, i >> 8, (i >> 4) & 15, BlockId(id));
                }
            }
            _ => return Err(SaveError::Corrupt("section tag")),
        }
        chunk.sections[si].biomes.copy_from_slice(r.take(64)?);
    }
    chunk.rebuild_heightmaps();
    chunk.compact();
    crate::lighting::compute_chunk_light(&mut chunk);
    chunk.dirty = false;
    Ok(chunk)
}

pub fn chunk_path(dir: &Path, pos: ChunkPos) -> PathBuf {
    dir.join(format!("c.{}.{}.bfc", pos.x, pos.z))
}

pub fn save_chunk(dir: &Path, chunk: &Chunk) -> Result<(), SaveError> {
    std::fs::create_dir_all(dir)?;
    let tmp = chunk_path(dir, chunk.pos).with_extension("tmp");
    std::fs::write(&tmp, serialize_chunk(chunk))?;
    std::fs::rename(tmp, chunk_path(dir, chunk.pos))?; // atomic replace
    Ok(())
}

pub fn load_chunk(dir: &Path, pos: ChunkPos) -> Result<Option<Chunk>, SaveError> {
    match std::fs::read(chunk_path(dir, pos)) {
        Ok(d) => deserialize_chunk(&d).map(Some),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(e) => Err(e.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::worldgen::WorldGenerator;

    #[test]
    fn crc_known_value() {
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    }

    #[test]
    fn roundtrip_generated_chunk_and_detect_corruption() {
        let g = WorldGenerator::new(77);
        let c = g.generate_chunk(ChunkPos::new(-3, 4));
        let bytes = serialize_chunk(&c);
        assert!(bytes.len() < 80_000, "{} bytes", bytes.len());
        let back = deserialize_chunk(&bytes).unwrap();
        assert_eq!(back.pos, c.pos);
        for y in (-64..320).step_by(3) {
            for x in 0..16 {
                for z in 0..16 {
                    assert_eq!(back.get_block(x, y, z), c.get_block(x, y, z));
                }
            }
        }
        assert_eq!(back.biome_at(5, 70, 5), c.biome_at(5, 70, 5));
        let mut bad = bytes.clone();
        bad[100] ^= 0x55;
        assert!(matches!(deserialize_chunk(&bad), Err(SaveError::Checksum { .. })));
        assert!(matches!(deserialize_chunk(&bytes[..50]), Err(_)));
        assert!(matches!(deserialize_chunk(b"nope-not-a-chunk-at-all"), Err(SaveError::BadMagic) | Err(SaveError::Checksum { .. })));
    }

    #[test]
    fn disk_roundtrip() {
        let dir = std::env::temp_dir().join(format!("bf_save_test_{}", std::process::id()));
        let g = WorldGenerator::new(5);
        let c = g.generate_chunk(ChunkPos::new(1, 1));
        save_chunk(&dir, &c).unwrap();
        let back = load_chunk(&dir, ChunkPos::new(1, 1)).unwrap().unwrap();
        assert_eq!(back.get_block(3, 64, 3), c.get_block(3, 64, 3));
        assert!(load_chunk(&dir, ChunkPos::new(9, 9)).unwrap().is_none());
        let _ = std::fs::remove_dir_all(dir);
    }
}
