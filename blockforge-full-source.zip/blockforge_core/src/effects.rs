//! Status effects (33) and enchantments (42) with their gameplay modifiers.

macro_rules! effects {
    ($( $v:ident $name:literal $good:literal ;)*) => {
        #[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
        pub enum Effect { $($v),* }
        impl Effect {
            pub const ALL: &'static [Effect] = &[ $(Effect::$v),* ];
            pub fn name(self) -> &'static str { match self { $(Effect::$v => $name),* } }
            pub fn beneficial(self) -> bool { match self { $(Effect::$v => $good),* } }
        }
    };
}

effects! {
    Speed "speed" true; Slowness "slowness" false; Haste "haste" true; MiningFatigue "mining_fatigue" false;
    Strength "strength" true; InstantHealth "instant_health" true; InstantDamage "instant_damage" false;
    JumpBoost "jump_boost" true; Nausea "nausea" false; Regeneration "regeneration" true;
    Resistance "resistance" true; FireResistance "fire_resistance" true; WaterBreathing "water_breathing" true;
    Invisibility "invisibility" true; Blindness "blindness" false; NightVision "night_vision" true;
    Hunger "hunger" false; Weakness "weakness" false; Poison "poison" false; Wither "wither" false;
    HealthBoost "health_boost" true; Absorption "absorption" true; Saturation "saturation" true;
    Glowing "glowing" true; Levitation "levitation" false; Luck "luck" true; BadLuck "unluck" false;
    SlowFalling "slow_falling" true; ConduitPower "conduit_power" true; DolphinsGrace "dolphins_grace" true;
    BadOmen "bad_omen" false; HeroOfTheVillage "hero_of_the_village" true; Darkness "darkness" false;
}

#[derive(Clone, Copy, Debug)]
pub struct EffectInstance {
    pub effect: Effect,
    pub amplifier: u8,
    pub duration: i32, // ticks
}

#[derive(Clone, Debug, Default)]
pub struct ActiveEffects {
    list: Vec<EffectInstance>,
}

impl ActiveEffects {
    pub fn add(&mut self, effect: Effect, amplifier: u8, duration: i32) {
        if let Some(e) = self.list.iter_mut().find(|e| e.effect == effect) {
            if amplifier > e.amplifier || (amplifier == e.amplifier && duration > e.duration) {
                e.amplifier = amplifier;
                e.duration = duration;
            }
        } else {
            self.list.push(EffectInstance { effect, amplifier, duration });
        }
    }
    pub fn remove(&mut self, effect: Effect) {
        self.list.retain(|e| e.effect != effect);
    }
    pub fn clear(&mut self) {
        self.list.clear();
    }
    pub fn level(&self, effect: Effect) -> i32 {
        self.list.iter().find(|e| e.effect == effect).map_or(0, |e| e.amplifier as i32 + 1)
    }
    pub fn has(&self, effect: Effect) -> bool {
        self.level(effect) > 0
    }
    pub fn iter(&self) -> impl Iterator<Item = &EffectInstance> {
        self.list.iter()
    }
    pub fn tick(&mut self) {
        for e in &mut self.list {
            e.duration -= 1;
        }
        self.list.retain(|e| e.duration > 0);
    }
    /// Movement speed multiplier (+20 % per Speed level, −15 % per Slowness level).
    pub fn speed_multiplier(&self) -> f64 {
        (1.0 + 0.2 * self.level(Effect::Speed) as f64) * (1.0 - 0.15 * self.level(Effect::Slowness) as f64).max(0.0)
    }
    pub fn jump_bonus(&self) -> f64 {
        0.1 * self.level(Effect::JumpBoost) as f64
    }
    pub fn haste_level(&self) -> i32 {
        self.level(Effect::Haste).max(self.level(Effect::ConduitPower))
    }
    pub fn fatigue_level(&self) -> i32 {
        self.level(Effect::MiningFatigue)
    }
    pub fn damage_multiplier(&self) -> f32 {
        1.0 + 0.3 * self.level(Effect::Strength) as f32 - 0.2 * self.level(Effect::Weakness) as f32
    }
    pub fn resistance_factor(&self) -> f32 {
        (1.0 - 0.2 * self.level(Effect::Resistance) as f32).max(0.0)
    }
    /// Gravity per tick (slow falling / levitation).
    pub fn gravity(&self) -> f64 {
        if self.has(Effect::SlowFalling) { 0.01 } else { 0.08 }
    }
}

macro_rules! enchants {
    ($( $v:ident $name:literal $max:literal ;)*) => {
        #[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
        pub enum Enchantment { $($v),* }
        impl Enchantment {
            pub const ALL: &'static [Enchantment] = &[ $(Enchantment::$v),* ];
            pub fn name(self) -> &'static str { match self { $(Enchantment::$v => $name),* } }
            pub fn max_level(self) -> u8 { match self { $(Enchantment::$v => $max),* } }
        }
    };
}

enchants! {
    Protection "protection" 4; FireProtection "fire_protection" 4; FeatherFalling "feather_falling" 4;
    BlastProtection "blast_protection" 4; ProjectileProtection "projectile_protection" 4;
    Respiration "respiration" 3; AquaAffinity "aqua_affinity" 1; Thorns "thorns" 3; DepthStrider "depth_strider" 3;
    FrostWalker "frost_walker" 2; BindingCurse "binding_curse" 1; SoulSpeed "soul_speed" 3;
    SwiftSneak "swift_sneak" 3; Sharpness "sharpness" 5; Smite "smite" 5; BaneOfArthropods "bane_of_arthropods" 5;
    Knockback "knockback" 2; FireAspect "fire_aspect" 2; Looting "looting" 3; SweepingEdge "sweeping_edge" 3;
    Efficiency "efficiency" 5; SilkTouch "silk_touch" 1; Unbreaking "unbreaking" 3; Fortune "fortune" 3;
    Power "power" 5; Punch "punch" 2; Flame "flame" 1; Infinity "infinity" 1; LuckOfTheSea "luck_of_the_sea" 3;
    Lure "lure" 3; Loyalty "loyalty" 3; Impaling "impaling" 5; Riptide "riptide" 3; Channeling "channeling" 1;
    Multishot "multishot" 1; QuickCharge "quick_charge" 3; Piercing "piercing" 4; Density "density" 5;
    Breach "breach" 4; WindBurst "wind_burst" 3; Mending "mending" 1; VanishingCurse "vanishing_curse" 1;
}

impl Enchantment {
    pub fn from_name(n: &str) -> Option<Enchantment> {
        Enchantment::ALL.iter().copied().find(|e| e.name() == n.trim_start_matches("minecraft:"))
    }
}

/// Sharpness bonus damage (vanilla 1.9+: 0.5 × level + 0.5).
pub fn sharpness_bonus(level: u8) -> f32 {
    if level == 0 { 0.0 } else { 0.5 * level as f32 + 0.5 }
}

/// Chance (0..1) that a durability point is NOT consumed with Unbreaking `level` on a tool.
pub fn unbreaking_save_chance(level: u8) -> f32 {
    level as f32 / (level as f32 + 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn registries_are_big_enough() {
        assert!(Effect::ALL.len() >= 33);
        assert!(Enchantment::ALL.len() >= 40);
        assert_eq!(Enchantment::from_name("minecraft:sharpness"), Some(Enchantment::Sharpness));
        assert_eq!(Enchantment::Sharpness.max_level(), 5);
    }

    #[test]
    fn modifiers() {
        let mut e = ActiveEffects::default();
        e.add(Effect::Speed, 1, 100);
        assert!((e.speed_multiplier() - 1.4).abs() < 1e-9);
        e.add(Effect::Slowness, 0, 5);
        assert!(e.speed_multiplier() < 1.4);
        for _ in 0..5 {
            e.tick();
        }
        assert!(!e.has(Effect::Slowness) && e.has(Effect::Speed));
        assert_eq!(sharpness_bonus(5), 3.0);
    }
}
