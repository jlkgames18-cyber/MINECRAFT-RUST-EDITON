//! World = sparse map of loaded chunks with fast integer hashing.

use crate::block::BlockId;
use crate::chunk::{Chunk, HeightmapKind};
use crate::lighting::compute_chunk_light_with_neighbours;
use crate::math::{BlockPos, ChunkPos, MAX_Y, MIN_Y};
use std::collections::HashMap;
use std::hash::{BuildHasherDefault, Hasher};

/// Tiny multiplicative hasher (FxHash style). Chunk keys are already well distributed 64-bit
/// integers, so SipHash would only burn cycles.
#[derive(Default, Clone, Copy)]
pub struct FxHasher {
    hash: u64,
}

const SEED: u64 = 0x51_7c_c1_b7_27_22_0a_95;

impl Hasher for FxHasher {
    #[inline]
    fn write(&mut self, bytes: &[u8]) {
        for &b in bytes {
            self.hash = (self.hash.rotate_left(5) ^ b as u64).wrapping_mul(SEED);
        }
    }
    #[inline]
    fn write_i64(&mut self, i: i64) {
        self.hash = (self.hash.rotate_left(5) ^ i as u64).wrapping_mul(SEED);
    }
    #[inline]
    fn write_u64(&mut self, i: u64) {
        self.hash = (self.hash.rotate_left(5) ^ i).wrapping_mul(SEED);
    }
    #[inline]
    fn finish(&self) -> u64 {
        self.hash
    }
}

pub type FxBuild = BuildHasherDefault<FxHasher>;
pub type FxHashMap<K, V> = HashMap<K, V, FxBuild>;

pub struct World {
    pub seed: i64,
    chunks: FxHashMap<i64, Box<Chunk>>,
    /// Game time in ticks (increments once per server tick).
    pub game_time: u64,
}

impl World {
    pub fn new(seed: i64) -> Self {
        Self { seed, chunks: FxHashMap::default(), game_time: 0 }
    }

    #[inline]
    pub fn chunk(&self, pos: ChunkPos) -> Option<&Chunk> {
        self.chunks.get(&pos.pack()).map(|b| &**b)
    }
    #[inline]
    pub fn chunk_mut(&mut self, pos: ChunkPos) -> Option<&mut Chunk> {
        self.chunks.get_mut(&pos.pack()).map(|b| &mut **b)
    }
    #[inline]
    pub fn is_loaded(&self, pos: ChunkPos) -> bool {
        self.chunks.contains_key(&pos.pack())
    }
    pub fn insert_chunk(&mut self, chunk: Chunk) {
        self.chunks.insert(chunk.pos.pack(), Box::new(chunk));
    }
    pub fn unload_chunk(&mut self, pos: ChunkPos) -> Option<Box<Chunk>> {
        self.chunks.remove(&pos.pack())
    }
    pub fn loaded_count(&self) -> usize {
        self.chunks.len()
    }
    pub fn loaded_positions(&self) -> impl Iterator<Item = ChunkPos> + '_ {
        self.chunks.keys().map(|&k| ChunkPos::unpack(k))
    }
    pub fn chunks(&self) -> impl Iterator<Item = &Chunk> {
        self.chunks.values().map(|b| &**b)
    }
    pub fn heap_bytes(&self) -> usize {
        self.chunks.values().map(|c| c.heap_bytes()).sum()
    }

    /// Returns air outside the build height *and* in unloaded chunks.
    #[inline]
    pub fn get_block(&self, x: i32, y: i32, z: i32) -> BlockId {
        if y < MIN_Y || y >= MAX_Y {
            return BlockId::AIR;
        }
        match self.chunks.get(&ChunkPos::new(x >> 4, z >> 4).pack()) {
            Some(c) => c.get_block((x & 15) as usize, y, (z & 15) as usize),
            None => BlockId::AIR,
        }
    }

    #[inline]
    pub fn get_block_pos(&self, p: BlockPos) -> BlockId {
        self.get_block(p.x, p.y, p.z)
    }

    /// Sets a block. Returns the previous block, or `None` if the chunk is not loaded
    /// or the position is out of range.
    pub fn set_block(&mut self, x: i32, y: i32, z: i32, id: BlockId) -> Option<BlockId> {
        if y < MIN_Y || y >= MAX_Y {
            return None;
        }
        let c = self.chunks.get_mut(&ChunkPos::new(x >> 4, z >> 4).pack())?;
        Some(c.set_block((x & 15) as usize, y, (z & 15) as usize, id))
    }

    /// Recomputes light for one chunk, stitching in light from its four loaded neighbours.
    pub fn relight_chunk(&mut self, pos: ChunkPos) {
        let Some(mut chunk) = self.chunks.remove(&pos.pack()) else { return };
        {
            let g = |dx: i32, dz: i32| self.chunk(ChunkPos::new(pos.x + dx, pos.z + dz));
            compute_chunk_light_with_neighbours(&mut chunk, [g(1, 0), g(-1, 0), g(0, 1), g(0, -1)]);
        }
        self.chunks.insert(pos.pack(), chunk);
    }

    /// Sky light at a world position (15 above the world, 0 in unloaded chunks).
    pub fn sky_light(&self, x: i32, y: i32, z: i32) -> u8 {
        if y >= MAX_Y {
            return 15;
        }
        self.chunk(ChunkPos::new(x >> 4, z >> 4)).map_or(0, |c| c.sky_light_at((x & 15) as usize, y, (z & 15) as usize))
    }

    /// Block light at a world position.
    pub fn block_light(&self, x: i32, y: i32, z: i32) -> u8 {
        self.chunk(ChunkPos::new(x >> 4, z >> 4)).map_or(0, |c| c.block_light_at((x & 15) as usize, y, (z & 15) as usize))
    }

    pub fn height_at(&self, x: i32, z: i32, kind: HeightmapKind) -> Option<i32> {
        let c = self.chunk(ChunkPos::new(x >> 4, z >> 4))?;
        Some(c.height_at((x & 15) as usize, (z & 15) as usize, kind))
    }

    /// Collision test with the "unloaded chunks are solid" rule used for entities.
    #[inline]
    pub fn is_solid_for_collision(&self, x: i32, y: i32, z: i32) -> bool {
        if y < MIN_Y {
            return true; // void floor so nobody falls into unloaded space
        }
        if y >= MAX_Y {
            return false;
        }
        match self.chunks.get(&ChunkPos::new(x >> 4, z >> 4).pack()) {
            Some(c) => c.get_block((x & 15) as usize, y, (z & 15) as usize).is_solid(),
            None => true,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_get_across_chunks() {
        let mut w = World::new(0);
        for cx in -1..=1 {
            for cz in -1..=1 {
                w.insert_chunk(Chunk::new(ChunkPos::new(cx, cz)));
            }
        }
        assert_eq!(w.set_block(-1, 5, -16, BlockId::STONE), Some(BlockId::AIR));
        assert_eq!(w.get_block(-1, 5, -16), BlockId::STONE);
        assert_eq!(w.set_block(-1, 5, -17, BlockId::STONE), None); // chunk (-1,-2) not loaded
        assert_eq!(w.set_block(100, 5, 100, BlockId::STONE), None);
        assert_eq!(w.get_block(0, 400, 0), BlockId::AIR);
    }

    #[test]
    fn unloaded_chunks_are_solid_for_collision() {
        let w = World::new(0);
        assert!(w.is_solid_for_collision(0, 5, 0));
        assert!(w.is_solid_for_collision(0, -100, 0));
    }

    #[test]
    fn hasher_distributes() {
        let mut w = World::new(1);
        for i in 0..100 {
            w.insert_chunk(Chunk::new(ChunkPos::new(i, -i)));
        }
        assert_eq!(w.loaded_count(), 100);
        assert!(w.is_loaded(ChunkPos::new(50, -50)));
        assert!(w.unload_chunk(ChunkPos::new(50, -50)).is_some());
        assert!(!w.is_loaded(ChunkPos::new(50, -50)));
    }
}
