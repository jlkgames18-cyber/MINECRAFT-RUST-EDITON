//! Fixed-timestep game clock (20 TPS, 50 ms per tick) with render interpolation,
//! plus a lightweight frame statistics collector.

use std::time::{Duration, Instant};

pub const TICK_RATE: u32 = 20;
pub const TICK_DURATION: Duration = Duration::from_millis(50);
/// Vanilla drops time instead of running unbounded catch-up ("Can't keep up!").
pub const MAX_CATCHUP_TICKS: u32 = 10;

pub struct TickClock {
    last: Instant,
    accumulator: f64, // in ticks
    pub total_ticks: u64,
    pub tick_rate: f32,
}

impl TickClock {
    pub fn new(now: Instant) -> Self {
        Self { last: now, accumulator: 0.0, total_ticks: 0, tick_rate: TICK_RATE as f32 }
    }

    /// Returns `(ticks_to_run, partial_tick)` where `partial_tick` is in `[0, 1)`.
    pub fn advance(&mut self, now: Instant) -> (u32, f32) {
        let dt = now.saturating_duration_since(self.last).as_secs_f64();
        self.last = now;
        self.accumulator += dt * self.tick_rate as f64;
        let mut ticks = self.accumulator.floor() as u32;
        self.accumulator -= ticks as f64;
        if ticks > MAX_CATCHUP_TICKS {
            ticks = MAX_CATCHUP_TICKS; // skipped time is dropped, not replayed
        }
        self.total_ticks += ticks as u64;
        (ticks, self.accumulator as f32)
    }
}

/// Ring buffer of the last N frame times.
pub struct FrameStats {
    samples: [f32; 240],
    idx: usize,
    filled: usize,
    last: Option<Instant>,
}

impl Default for FrameStats {
    fn default() -> Self {
        Self::new()
    }
}

impl FrameStats {
    pub fn new() -> Self {
        Self { samples: [0.0; 240], idx: 0, filled: 0, last: None }
    }

    pub fn begin_frame(&mut self, now: Instant) {
        if let Some(l) = self.last {
            self.push(now.saturating_duration_since(l).as_secs_f32() * 1000.0);
        }
        self.last = Some(now);
    }

    pub fn push(&mut self, ms: f32) {
        self.samples[self.idx] = ms;
        self.idx = (self.idx + 1) % self.samples.len();
        self.filled = (self.filled + 1).min(self.samples.len());
    }

    pub fn avg_ms(&self) -> f32 {
        if self.filled == 0 {
            return 0.0;
        }
        self.samples[..self.filled].iter().sum::<f32>() / self.filled as f32
    }
    pub fn fps(&self) -> f32 {
        let a = self.avg_ms();
        if a > 0.0 {
            1000.0 / a
        } else {
            0.0
        }
    }
    pub fn max_ms(&self) -> f32 {
        self.samples[..self.filled].iter().cloned().fold(0.0, f32::max)
    }
    /// "1% low" FPS: average of the worst 1 % frames.
    pub fn one_percent_low_fps(&self) -> f32 {
        if self.filled == 0 {
            return 0.0;
        }
        let mut v = self.samples[..self.filled].to_vec();
        v.sort_by(|a, b| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
        let n = (v.len() / 100).max(1);
        let avg = v[..n].iter().sum::<f32>() / n as f32;
        if avg > 0.0 {
            1000.0 / avg
        } else {
            0.0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn one_second_is_twenty_ticks() {
        let t0 = Instant::now();
        let mut c = TickClock::new(t0);
        let mut total = 0;
        for i in 1..=100 {
            let (n, p) = c.advance(t0 + Duration::from_millis(i * 10));
            total += n;
            assert!((0.0..1.0).contains(&p));
        }
        assert_eq!(total, 20);
    }

    #[test]
    fn catchup_is_capped() {
        let t0 = Instant::now();
        let mut c = TickClock::new(t0);
        let (n, _) = c.advance(t0 + Duration::from_secs(30));
        assert_eq!(n, MAX_CATCHUP_TICKS);
    }

    #[test]
    fn partial_tick_interpolates() {
        let t0 = Instant::now();
        let mut c = TickClock::new(t0);
        let (n, p) = c.advance(t0 + Duration::from_millis(75));
        assert_eq!(n, 1);
        assert!((p - 0.5).abs() < 1e-3);
    }

    #[test]
    fn frame_stats_fps() {
        let mut s = FrameStats::new();
        for _ in 0..100 {
            s.push(8.0);
        }
        assert!((s.fps() - 125.0).abs() < 0.1);
        s.push(100.0);
        assert!(s.one_percent_low_fps() < s.fps());
    }
}
