//! Item registry (≈ 1000 entries).
//!
//! * ids `0..BLOCK_COUNT` are the block items (id == block id),
//! * everything above is generated at start-up: materials, 30 tools, 24 armour pieces, 40 foods,
//!   wooden / stone variants (stairs, slabs, doors, fences …), 16-colour families (dyes, beds,
//!   banners, candles, carpets), music discs, spawn eggs, buckets, …

use crate::block::{tool, BlockId, BLOCKS, BLOCK_COUNT};
use std::collections::HashMap;
use std::sync::OnceLock;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, Default, PartialOrd, Ord)]
pub struct ItemId(pub u16);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ItemKind {
    Block,
    Material,
    Tool,
    Weapon,
    Armor,
    Food,
    Variant, // placeable shape variants (stairs, slabs …) – shapes are renderer work
    Spawn,
    Disc,
    Misc,
}

#[derive(Clone, Debug)]
pub struct ItemInfo {
    pub name: String,
    pub max_stack: u8,
    pub kind: ItemKind,
    pub tool: u8,
    pub tier: u8,
    pub durability: u16,
    pub mining_speed: f32,
    pub attack_damage: f32,
    pub attack_speed: f32,
    /// armour slot 0 = boots … 3 = helmet; `None` for non armour
    pub armor_slot: Option<u8>,
    pub armor_points: u8,
    pub toughness: f32,
    pub food: Option<(u8, f32)>,
    pub fuel_ticks: u16,
}

impl ItemInfo {
    fn new(name: &str, kind: ItemKind) -> Self {
        Self {
            name: format!("minecraft:{name}"), max_stack: 64, kind, tool: 0, tier: 0, durability: 0, mining_speed: 1.0,
            attack_damage: 1.0, attack_speed: 4.0, armor_slot: None, armor_points: 0, toughness: 0.0, food: None, fuel_ticks: 0,
        }
    }
    pub fn short_name(&self) -> &str {
        self.name.trim_start_matches("minecraft:")
    }
}

pub struct Registry {
    pub items: Vec<ItemInfo>,
    by_name: HashMap<String, u16>,
}

const COLORS: [&str; 16] = [
    "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple",
    "blue", "brown", "green", "red", "black",
];
const WOODS: [&str; 10] = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "bamboo", "crimson"];
const TIERS: [&str; 6] = ["wooden", "stone", "golden", "iron", "diamond", "netherite"];

pub const MOB_EGGS: &[&str] = &[
    "zombie", "skeleton", "creeper", "spider", "enderman", "witch", "slime", "cow", "pig", "sheep", "chicken", "horse",
    "wolf", "cat", "fox", "rabbit", "villager", "iron_golem", "bee", "squid", "dolphin", "turtle", "panda", "llama",
    "parrot", "axolotl", "frog", "goat", "camel", "sniffer", "bat", "drowned", "husk", "stray", "phantom", "pillager",
    "ravager", "blaze", "ghast", "piglin", "hoglin", "strider", "guardian", "shulker", "silverfish", "cave_spider",
    "zombie_villager", "mooshroom", "ocelot", "polar_bear", "salmon", "cod", "tropical_fish", "pufferfish", "glow_squid",
    "wandering_trader", "vindicator", "evoker", "vex", "warden", "allay", "armadillo", "breeze", "creaking",
];

fn build() -> Registry {
    let mut items: Vec<ItemInfo> = BLOCKS
        .iter()
        .map(|b| {
            let mut i = ItemInfo::new(b.name.trim_start_matches("minecraft:"), ItemKind::Block);
            if b.name.contains("log") || b.name.contains("planks") || b.name.contains("wood") || b.name.contains("bookshelf") {
                i.fuel_ticks = if b.name.contains("planks") || b.name.contains("log") { 300 } else { 300 };
            }
            if b.name == "minecraft:coal_block" { i.fuel_ticks = 16000; }
            if b.name == "minecraft:lava" || b.name == "minecraft:water" { i.max_stack = 1; }
            i
        })
        .collect();
    assert_eq!(items.len(), BLOCK_COUNT);
    let mut add = |i: ItemInfo| items.push(i);
    let mat = |n: &str| ItemInfo::new(n, ItemKind::Material);

    for n in [
        "stick", "coal", "charcoal", "iron_ingot", "gold_ingot", "copper_ingot", "netherite_ingot", "netherite_scrap",
        "diamond", "emerald", "lapis_lazuli", "redstone", "quartz", "amethyst_shard", "raw_iron", "raw_gold", "raw_copper",
        "flint", "clay_ball", "brick", "nether_brick", "string", "feather", "leather", "paper", "book", "bone", "bone_meal",
        "slime_ball", "gunpowder", "blaze_rod", "blaze_powder", "ender_pearl", "ender_eye", "ghast_tear", "glowstone_dust",
        "sugar", "bowl", "glass_bottle", "magma_cream", "nether_star", "prismarine_shard", "prismarine_crystals",
        "nautilus_shell", "heart_of_the_sea", "scute", "phantom_membrane", "rabbit_hide", "rabbit_foot", "honeycomb",
        "ink_sac", "glow_ink_sac", "wheat_seeds", "melon_seeds", "pumpkin_seeds", "beetroot_seeds", "torchflower_seeds",
        "wheat", "popped_chorus_fruit", "shulker_shell", "echo_shard", "disc_fragment_5", "dragon_breath", "fire_charge",
        "firework_star", "firework_rocket", "armadillo_scute", "breeze_rod", "wind_charge", "trial_key", "ominous_trial_key",
        "netherite_upgrade_smithing_template", "name_tag", "lead", "saddle", "map", "filled_map", "compass", "clock",
        "recovery_compass", "spyglass", "totem_of_undying", "experience_bottle", "writable_book", "written_book",
        "item_frame", "painting", "armor_stand", "minecart", "chest_minecart", "hopper_minecart", "furnace_minecart",
        "tnt_minecart", "command_block_minecart", "carrot_on_a_stick", "warped_fungus_on_a_stick", "elytra", "trident",
        "arrow", "spectral_arrow", "tipped_arrow", "egg", "enchanted_book", "potion", "splash_potion", "lingering_potion",
        "wolf_armor", "horse_armor_iron", "horse_armor_golden", "horse_armor_diamond", "leather_horse_armor", "mace",
    ] {
        let mut i = mat(n);
        if n == "coal" || n == "charcoal" { i.fuel_ticks = 1600; }
        if n == "stick" { i.fuel_ticks = 100; }
        if n == "blaze_rod" { i.fuel_ticks = 2400; }
        if matches!(n, "ender_pearl" | "egg" | "experience_bottle") { i.max_stack = 16; }
        if matches!(n, "elytra" | "trident" | "totem_of_undying" | "potion" | "mace" | "saddle" | "written_book" | "enchanted_book") { i.max_stack = 1; }
        if n == "trident" { i.durability = 250; i.attack_damage = 9.0; i.attack_speed = 1.1; i.kind = ItemKind::Weapon; }
        if n == "mace" { i.durability = 500; i.attack_damage = 6.0; i.attack_speed = 0.6; i.kind = ItemKind::Weapon; }
        if n == "elytra" { i.durability = 432; i.armor_slot = Some(2); i.kind = ItemKind::Armor; }
        add(i);
    }
    for n in ["snowball", "ender_pearl_dummy_never_used"] {
        if n == "snowball" {
            let mut i = mat(n);
            i.max_stack = 16;
            add(i);
        }
    }
    // buckets
    for n in ["bucket", "water_bucket", "lava_bucket", "milk_bucket", "powder_snow_bucket", "pufferfish_bucket", "salmon_bucket", "cod_bucket", "axolotl_bucket", "tadpole_bucket"] {
        let mut i = ItemInfo::new(n, ItemKind::Misc);
        i.max_stack = if n == "bucket" { 16 } else { 1 };
        if n == "lava_bucket" { i.fuel_ticks = 20000; }
        add(i);
    }

    // tools -------------------------------------------------------------------------------
    let dur = [59u16, 131, 32, 250, 1561, 2031];
    let speed = [2.0f32, 4.0, 12.0, 6.0, 8.0, 9.0];
    let level = [1u8, 2, 1, 3, 4, 5];
    let sword = [4.0f32, 5.0, 4.0, 6.0, 7.0, 8.0];
    let axe = [7.0f32, 9.0, 7.0, 9.0, 9.0, 10.0];
    let pick = [2.0f32, 3.0, 2.0, 4.0, 5.0, 6.0];
    let shovel = [2.5f32, 3.5, 2.5, 4.5, 5.5, 6.5];
    for (t, tn) in TIERS.iter().enumerate() {
        for (kind, tl, dmg, spd) in [
            ("sword", tool::SWORD, sword[t], 1.6f32),
            ("pickaxe", tool::PICKAXE, pick[t], 1.2),
            ("axe", tool::AXE, axe[t], if t <= 1 { 0.8 } else if t < 4 { 0.9 } else { 1.0 }),
            ("shovel", tool::SHOVEL, shovel[t], 1.0),
            ("hoe", tool::HOE, 1.0, [1.0, 2.0, 1.0, 3.0, 4.0, 4.0][t]),
        ] {
            let mut i = ItemInfo::new(&format!("{tn}_{kind}"), if kind == "sword" { ItemKind::Weapon } else { ItemKind::Tool });
            i.max_stack = 1;
            i.tool = tl;
            i.tier = level[t];
            i.durability = dur[t];
            i.mining_speed = speed[t];
            i.attack_damage = dmg;
            i.attack_speed = spd;
            if *tn == "wooden" { i.fuel_ticks = 200; }
            add(i);
        }
    }
    for (n, d, tl, sp) in [("shears", 238u16, tool::SHEARS, 1.5f32), ("flint_and_steel", 64, 0, 1.0), ("fishing_rod", 64, 0, 1.0),
        ("bow", 384, 0, 1.0), ("crossbow", 465, 0, 1.0), ("shield", 336, 0, 1.0), ("brush", 64, 0, 1.0)] {
        let mut i = ItemInfo::new(n, ItemKind::Tool);
        i.max_stack = 1;
        i.durability = d;
        i.tool = tl;
        i.mining_speed = sp;
        if tl == tool::SHEARS { i.tier = 1; }
        add(i);
    }

    // armour ------------------------------------------------------------------------------
    let a_names = ["leather", "chainmail", "iron", "golden", "diamond", "netherite"];
    let pts: [[u8; 4]; 6] = [[1, 2, 3, 1], [1, 4, 5, 2], [2, 5, 6, 2], [1, 3, 5, 2], [3, 6, 8, 3], [3, 6, 8, 3]];
    let mult = [5u16, 15, 15, 7, 33, 37];
    for (m, an) in a_names.iter().enumerate() {
        for (slot, (piece, base)) in [("boots", 13u16), ("leggings", 15), ("chestplate", 16), ("helmet", 11)].iter().enumerate() {
            let mut i = ItemInfo::new(&format!("{an}_{piece}"), ItemKind::Armor);
            i.max_stack = 1;
            i.armor_slot = Some(slot as u8);
            i.armor_points = pts[m][slot];
            i.durability = base * mult[m];
            i.toughness = match m { 4 => 2.0, 5 => 3.0, _ => 0.0 };
            add(i);
        }
    }
    let mut turtle = ItemInfo::new("turtle_helmet", ItemKind::Armor);
    turtle.max_stack = 1; turtle.armor_slot = Some(3); turtle.armor_points = 2; turtle.durability = 275;
    add(turtle);

    // food --------------------------------------------------------------------------------
    for (n, h, s) in [
        ("apple", 4u8, 2.4f32), ("golden_apple", 4, 9.6), ("enchanted_golden_apple", 4, 9.6), ("bread", 5, 6.0),
        ("beef", 3, 1.8), ("cooked_beef", 8, 12.8), ("porkchop", 3, 1.8), ("cooked_porkchop", 8, 12.8),
        ("chicken", 2, 1.2), ("cooked_chicken", 6, 7.2), ("mutton", 2, 1.2), ("cooked_mutton", 6, 9.6),
        ("rabbit", 3, 1.8), ("cooked_rabbit", 5, 6.0), ("cod", 2, 0.4), ("cooked_cod", 5, 6.0), ("salmon", 2, 0.4),
        ("cooked_salmon", 6, 9.6), ("tropical_fish", 1, 0.2), ("pufferfish", 1, 0.2), ("carrot", 3, 3.6),
        ("golden_carrot", 6, 14.4), ("potato", 1, 0.6), ("baked_potato", 5, 6.0), ("poisonous_potato", 2, 1.2),
        ("beetroot", 1, 1.2), ("beetroot_soup", 6, 7.2), ("mushroom_stew", 6, 7.2), ("rabbit_stew", 10, 12.0),
        ("cookie", 2, 0.4), ("melon_slice", 2, 1.2), ("dried_kelp", 1, 0.6), ("pumpkin_pie", 8, 4.8),
        ("sweet_berries", 2, 0.4), ("glow_berries", 2, 0.4), ("honey_bottle", 6, 1.2), ("rotten_flesh", 4, 0.8),
        ("spider_eye", 2, 3.2), ("chorus_fruit", 4, 2.4), ("suspicious_stew", 6, 7.2), ("cake_slice", 2, 0.4),
    ] {
        let mut i = ItemInfo::new(n, ItemKind::Food);
        i.food = Some((h, s));
        if n.ends_with("stew") || n.ends_with("soup") || n == "honey_bottle" { i.max_stack = 1; }
        add(i);
    }

    // variants ----------------------------------------------------------------------------
    for w in WOODS {
        for v in ["stairs", "slab", "fence", "fence_gate", "door", "trapdoor", "button", "pressure_plate", "sign", "hanging_sign", "boat", "chest_boat"] {
            let mut i = ItemInfo::new(&format!("{w}_{v}"), ItemKind::Variant);
            if matches!(v, "door" | "sign" | "hanging_sign" | "boat" | "chest_boat") { i.max_stack = if v.contains("boat") { 1 } else { 16 }; }
            if matches!(v, "stairs" | "slab" | "fence" | "fence_gate" | "door" | "trapdoor" | "button" | "pressure_plate") { i.fuel_ticks = 300; }
            add(i);
        }
    }
    for m in ["cobblestone", "stone", "stone_brick", "mossy_cobblestone", "mossy_stone_brick", "sandstone", "red_sandstone",
        "brick", "nether_brick", "red_nether_brick", "quartz", "purpur", "prismarine", "prismarine_brick", "dark_prismarine",
        "granite", "diorite", "andesite", "polished_granite", "polished_diorite", "polished_andesite", "cobbled_deepslate",
        "polished_deepslate", "deepslate_brick", "deepslate_tile", "blackstone", "polished_blackstone", "polished_blackstone_brick",
        "end_stone_brick", "mud_brick", "tuff", "polished_tuff", "tuff_brick", "smooth_stone", "smooth_sandstone", "smooth_quartz",
        "cut_sandstone", "cut_red_sandstone", "smooth_red_sandstone", "cut_copper", "exposed_cut_copper", "weathered_cut_copper"] {
        add(ItemInfo::new(&format!("{m}_stairs"), ItemKind::Variant));
        add(ItemInfo::new(&format!("{m}_slab"), ItemKind::Variant));
        if !m.starts_with("smooth") && !m.starts_with("cut") && !m.contains("copper") && !m.contains("purpur") && !m.contains("quartz") {
            add(ItemInfo::new(&format!("{m}_wall"), ItemKind::Variant));
        }
    }
    for c in COLORS {
        for v in ["dye", "bed", "banner", "candle", "carpet", "stained_glass_pane", "bundle", "harness"] {
            let mut i = ItemInfo::new(&format!("{c}_{v}"), if v == "dye" { ItemKind::Material } else { ItemKind::Variant });
            if matches!(v, "bed" | "banner" | "bundle" | "harness") { i.max_stack = if v == "bed" || v == "banner" { 16 } else { 1 }; }
            add(i);
        }
    }
    for n in ["iron_door", "iron_trapdoor", "iron_bars", "glass_pane", "chain", "hopper", "rail", "powered_rail", "detector_rail",
        "activator_rail", "lever", "stone_button", "stone_pressure_plate", "heavy_weighted_pressure_plate", "light_weighted_pressure_plate",
        "tripwire_hook", "repeater", "comparator", "daylight_detector", "cauldron", "brewing_stand", "flower_pot", "bell", "campfire",
        "soul_campfire", "grindstone", "stonecutter", "loom", "smithing_table", "fletching_table", "cartography_table", "lectern",
        "composter", "ender_chest", "trapped_chest", "cake", "bed", "oak_sign", "lightning_rod", "conduit", "end_crystal",
        "dragon_egg", "end_portal", "respawn_anchor_item", "copper_door", "copper_bulb", "crafter", "vault", "trial_spawner",
        "decorated_pot", "chiseled_bookshelf", "sculk_sensor", "sculk_shrieker", "calibrated_sculk_sensor", "pointed_dripstone",
        "big_dripleaf", "azalea", "flowering_azalea", "moss_carpet", "frogspawn", "turtle_egg", "sniffer_egg", "dried_ghast"] {
        let mut i = ItemInfo::new(n, ItemKind::Variant);
        if matches!(n, "iron_door" | "cake" | "bed" | "oak_sign" | "rail" | "powered_rail") { i.max_stack = if n == "rail" || n == "powered_rail" { 64 } else { 16 }; }
        add(i);
    }
    for d in ["13", "cat", "blocks", "chirp", "far", "mall", "mellohi", "stal", "strad", "ward", "11", "wait", "pigstep", "otherside", "relic", "5", "creator", "creator_music_box", "precipice"] {
        let mut i = ItemInfo::new(&format!("music_disc_{d}"), ItemKind::Disc);
        i.max_stack = 1;
        add(i);
    }
    for m in MOB_EGGS {
        add(ItemInfo::new(&format!("{m}_spawn_egg"), ItemKind::Spawn));
    }
    for p in ["sentry", "dune", "coast", "wild", "ward", "eye", "vex", "tide", "snout", "rib", "spire", "wayfinder", "shaper", "silence", "raiser", "host", "flow", "bolt"] {
        add(ItemInfo::new(&format!("{p}_armor_trim_smithing_template"), ItemKind::Misc));
    }

    // de-duplicate names (block items win), build lookup
    let mut seen: HashMap<String, u16> = HashMap::new();
    let mut out: Vec<ItemInfo> = Vec::with_capacity(items.len());
    let mut by_name: HashMap<String, u16> = HashMap::new();
    for (idx, i) in items.into_iter().enumerate() {
        if idx < BLOCK_COUNT {
            by_name.insert(i.name.clone(), idx as u16);
            out.push(i);
            continue;
        }
        if seen.contains_key(&i.name) || by_name.contains_key(&i.name) {
            // keep ids stable: replace duplicates with an unobtainable placeholder
            let mut p = ItemInfo::new("air", ItemKind::Misc);
            p.name = format!("minecraft:duplicate_{idx}");
            out.push(p);
            continue;
        }
        seen.insert(i.name.clone(), idx as u16);
        by_name.insert(i.name.clone(), idx as u16);
        out.push(i);
    }
    Registry { items: out, by_name }
}

pub fn registry() -> &'static Registry {
    static R: OnceLock<Registry> = OnceLock::new();
    R.get_or_init(build)
}

pub fn item_count() -> usize {
    registry().items.len()
}

impl ItemId {
    pub const AIR: ItemId = ItemId(0);

    #[inline]
    pub fn info(self) -> &'static ItemInfo {
        let r = registry();
        r.items.get(self.0 as usize).unwrap_or(&r.items[0])
    }
    pub fn name(self) -> &'static str {
        &self.info().name
    }
    pub fn is_air(self) -> bool {
        self.0 == 0
    }
    pub fn from_name(n: &str) -> Option<ItemId> {
        let full;
        let key = if n.contains(':') { n } else { full = format!("minecraft:{n}"); &full };
        registry().by_name.get(key).map(|&i| ItemId(i))
    }
    /// Shorthand that panics on typos – used by recipe tables and tests.
    pub fn of(n: &str) -> ItemId {
        ItemId::from_name(n).unwrap_or_else(|| panic!("unknown item {n}"))
    }
    pub fn from_block(b: BlockId) -> ItemId {
        ItemId(b.0)
    }
    /// Block placed by this item (block items only).
    pub fn as_block(self) -> Option<BlockId> {
        ((self.0 as usize) < BLOCK_COUNT && self.0 != 0).then_some(BlockId(self.0))
    }
    pub fn max_stack(self) -> u8 {
        self.info().max_stack
    }
    pub fn all() -> impl Iterator<Item = ItemId> {
        (0..item_count() as u16).map(ItemId)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn registry_is_huge_and_lookup_works() {
        assert!(item_count() > 900, "{}", item_count());
        assert_eq!(ItemId::of("stone"), ItemId(BlockId::STONE.0));
        assert_eq!(ItemId::of("diamond_pickaxe").info().tier, 4);
        assert_eq!(ItemId::of("netherite_chestplate").info().armor_points, 8);
        assert_eq!(ItemId::of("cooked_beef").info().food, Some((8, 12.8)));
        assert!(ItemId::from_name("zombie_spawn_egg").is_some());
        assert_eq!(ItemId::from_name("minecraft:nope"), None);
        assert_eq!(ItemId::of("ender_pearl").max_stack(), 16);
        assert_eq!(ItemId::of("stone").as_block(), Some(BlockId::STONE));
        assert_eq!(ItemId::of("stick").as_block(), None);
    }

    #[test]
    fn names_are_unique() {
        let mut names: Vec<_> = ItemId::all().map(|i| i.name().to_string()).collect();
        let n = names.len();
        names.sort();
        names.dedup();
        assert_eq!(n, names.len());
    }
}
