//! # BlockForge Core
//!
//! A dependency-free, performance-first voxel engine core targeting
//! **Minecraft: Java Edition 1.21.11** (protocol 774, data version 4671).
//!
//! The crate is the *core* only: data structures, algorithms and the simulation primitives.
//! A renderer (wgpu / Vulkan / OpenGL), audio, input and gameplay systems plug on top of it.
//!
//! | module        | purpose                                                              |
//! |---------------|----------------------------------------------------------------------|
//! | [`math`]      | `Vec3`, `BlockPos`, `ChunkPos`, `Aabb`, `Face`, world-height consts   |
//! | [`rng`]       | bit-exact `java.util.Random` + Xoroshiro128++                         |
//! | [`noise`]     | improved Perlin + octaves                                             |
//! | [`block`]     | 415 blocks: flags, light, hardness, blast, friction, tools, textures  |
//! | [`biome`]     | 40 biomes + climate based biome source                                |
//! | [`chunk`]     | 16³ sections, heightmaps, biomes, paletted-container serialisation    |
//! | [`world`]     | sparse chunk map, cross-chunk relighting                              |
//! | [`worldgen`]  | caves, rivers, oceans, biomes, ores, vegetation, seamless trees       |
//! | [`trees`]     | 13 tree / mushroom / ice-spike generators over a `BlockSink`          |
//! | [`structures`]| desert wells, dungeons                                                |
//! | [`lighting`]  | sky + block light BFS with cross-chunk stitching, day/night curve     |
//! | [`mesher`]    | greedy meshing, AO, per-vertex light, cross plants                    |
//! | [`manager`]   | threaded generate → light → mesh pipeline + world ticking             |
//! | [`ticking`]   | fluids, falling blocks, random ticks (growth, spread, decay)          |
//! | [`physics`]   | vanilla movement + swimming, lava, ladders, flight, ice, soul sand    |
//! | [`raycast`]   | DDA block picking                                                     |
//! | [`item`]      | ~1000 items (tools, armour, food, variants, spawn eggs …)             |
//! | [`recipe`]    | 450+ crafting recipes (shaped / shapeless / mirrored) + smelting      |
//! | [`inventory`] | 36 slots, armour, stacking, durability                                |
//! | [`mining`]    | vanilla destroy-speed formula, tiers, drops, enchantment hooks        |
//! | [`effects`]   | 33 status effects, 40 enchantments                                    |
//! | [`game`]      | game modes, hunger / health / drowning, armour & fall damage          |
//! | [`entity`]    | 60 mobs, mob physics + AI, spawn rules                                |
//! | [`explosion`] | vanilla ray-cast explosions + damage                                  |
//! | [`time`]      | day / night clock, moon phases, weather state machine                 |
//! | [`commands`]  | `/gamemode /time /weather /tp /give /setblock /fill /effect …`         |
//! | [`save`]      | chunk persistence (palette + CRC-32, atomic writes)                   |
//! | [`tick`]      | 20 TPS fixed-step clock + frame statistics                            |
//! | [`protocol`]  | VarInt/VarLong, framing, handshake, status ping                       |

#![forbid(unsafe_code)]
#![warn(rust_2018_idioms)]

pub mod biome;
pub mod block;
pub mod block_table;
pub mod chunk;
pub mod commands;
pub mod effects;
pub mod entity;
pub mod explosion;
pub mod game;
pub mod inventory;
pub mod item;
pub mod lighting;
pub mod manager;
pub mod math;
pub mod mining;
pub mod mesher;
pub mod noise;
pub mod physics;
pub mod protocol;
pub mod raycast;
pub mod recipe;
pub mod rng;
pub mod save;
pub mod structures;
pub mod tick;
pub mod ticking;
pub mod time;
pub mod trees;
pub mod world;
pub mod worldgen;

pub mod prelude {
    pub use crate::block::BlockId;
    pub use crate::chunk::{Chunk, HeightmapKind, Section};
    pub use crate::manager::ChunkManager;
    pub use crate::math::{Aabb, BlockPos, ChunkPos, Face, Vec3};
    pub use crate::mesher::{ChunkMesh, MeshInput, Vertex};
    pub use crate::physics::{Input, Player};
    pub use crate::protocol::{DATA_VERSION, PROTOCOL_VERSION, VERSION_NAME};
    pub use crate::tick::{FrameStats, TickClock};
    pub use crate::item::ItemId;
    pub use crate::inventory::{Inventory, ItemStack};
    pub use crate::biome::BiomeId;
    pub use crate::world::World;
    pub use crate::worldgen::WorldGenerator;
}

/// Minecraft version this core targets.
pub const TARGET_VERSION: &str = protocol::VERSION_NAME;
