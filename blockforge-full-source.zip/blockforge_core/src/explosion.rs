//! Vanilla explosion algorithm: 16×16×16 surface rays, per-block blast resistance, drop chance
//! `1 / power`, and the exposure based entity damage formula.

use crate::block::BlockId;
use crate::math::{floor, BlockPos, Vec3};
use crate::rng::{JavaRandom, RandomSource};
use crate::world::World;

pub const TNT_POWER: f32 = 4.0;
pub const CREEPER_POWER: f32 = 3.0;
pub const CHARGED_CREEPER_POWER: f32 = 6.0;
pub const BED_POWER: f32 = 5.0;
pub const CRYSTAL_POWER: f32 = 6.0;

#[derive(Debug, Default)]
pub struct Explosion {
    pub destroyed: Vec<BlockPos>,
    /// Blocks that should drop their items (the rest is destroyed silently).
    pub dropping: Vec<BlockPos>,
}

/// Computes (does not apply) an explosion at `center`.
pub fn explode(world: &World, center: Vec3, power: f32, rng: &mut JavaRandom) -> Explosion {
    let mut hit: std::collections::HashSet<BlockPos> = std::collections::HashSet::new();
    for i in 0..16 {
        for j in 0..16 {
            for k in 0..16 {
                if !(i == 0 || i == 15 || j == 0 || j == 15 || k == 0 || k == 15) {
                    continue;
                }
                let mut d = Vec3::new(i as f64 / 15.0 * 2.0 - 1.0, j as f64 / 15.0 * 2.0 - 1.0, k as f64 / 15.0 * 2.0 - 1.0);
                d = d.normalize() * 0.3;
                let mut strength = power * (0.7 + rng.next_f32() * 0.6);
                let mut p = center;
                while strength > 0.0 {
                    let bp = BlockPos::from_vec3(p);
                    let b = world.get_block_pos(bp);
                    if !b.is_air() {
                        let res = b.info().blast_resistance.min(3_600_000.0);
                        strength -= (res + 0.3) * 0.3;
                        if strength > 0.0 && b.hardness() >= 0.0 {
                            hit.insert(bp);
                        }
                    }
                    strength -= 0.225;
                    p += d;
                }
            }
        }
    }
    let mut out = Explosion::default();
    let mut v: Vec<BlockPos> = hit.into_iter().collect();
    v.sort_by_key(|p| (p.y, p.x, p.z));
    for p in v {
        let b = world.get_block_pos(p);
        if b.is_air() || b == BlockId::BEDROCK {
            continue;
        }
        out.destroyed.push(p);
        if rng.next_f32() < 1.0 / power {
            out.dropping.push(p);
        }
    }
    out
}

/// Applies the destruction to the world, returns the number of removed blocks.
pub fn apply(world: &mut World, e: &Explosion) -> usize {
    let mut n = 0;
    for p in &e.destroyed {
        if world.set_block(p.x, p.y, p.z, BlockId::AIR).is_some() {
            n += 1;
        }
    }
    n
}

/// Fraction (0..1) of sample points on the entity box visible from the explosion centre.
pub fn exposure(world: &World, center: Vec3, min: Vec3, max: Vec3) -> f32 {
    let (mut seen, mut total) = (0, 0);
    for ix in 0..3 {
        for iy in 0..3 {
            for iz in 0..3 {
                let t = |a: f64, b: f64, i: i32| a + (b - a) * i as f64 / 2.0;
                let target = Vec3::new(t(min.x, max.x, ix), t(min.y, max.y, iy), t(min.z, max.z, iz));
                total += 1;
                let dir = target - center;
                let len = dir.length();
                if len < 1e-6 {
                    seen += 1;
                    continue;
                }
                let hit = crate::raycast::raycast_solid(world, center, dir.normalize(), len);
                if hit.is_none() {
                    seen += 1;
                }
            }
        }
    }
    seen as f32 / total as f32
}

/// Vanilla damage at `dist` blocks for an entity with the given exposure.
pub fn damage(power: f32, dist: f32, exposure: f32) -> f32 {
    let radius = power * 2.0;
    if dist >= radius {
        return 0.0;
    }
    let impact = (1.0 - dist / radius) * exposure;
    ((impact * impact + impact) / 2.0 * 7.0 * radius + 1.0).floor()
}

#[allow(dead_code)]
fn _unused(v: f64) -> i32 {
    floor(v)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::Chunk;
    use crate::math::ChunkPos;

    fn world() -> World {
        let mut w = World::new(1);
        for cx in -2..=2 {
            for cz in -2..=2 {
                let mut c = Chunk::new(ChunkPos::new(cx, cz));
                for x in 0..16 {
                    for z in 0..16 {
                        for y in -64..=60 {
                            c.set_block(x, y, z, if y == -64 { BlockId::BEDROCK } else { BlockId::STONE });
                        }
                    }
                }
                w.insert_chunk(c);
            }
        }
        w
    }

    #[test]
    fn tnt_digs_a_crater_but_not_obsidian() {
        let mut w = world();
        w.set_block(0, 60, 0, BlockId::OBSIDIAN);
        let mut rng = JavaRandom::new(4);
        let e = explode(&w, Vec3::new(0.5, 62.5, 0.5), TNT_POWER, &mut rng);
        assert!(e.destroyed.len() > 15, "crater too small: {}", e.destroyed.len());
        let n = apply(&mut w, &e);
        assert_eq!(n, e.destroyed.len());
        assert_eq!(w.get_block(0, 60, 0), BlockId::OBSIDIAN);
        assert_eq!(w.get_block(2, 60, 2), BlockId::AIR);
        assert!(e.dropping.len() < e.destroyed.len());
    }

    #[test]
    fn damage_falls_off_with_distance_and_cover() {
        let near = damage(4.0, 1.0, 1.0);
        let far = damage(4.0, 6.0, 1.0);
        assert!(near > far && far > 0.0);
        assert_eq!(damage(4.0, 8.0, 1.0), 0.0);
        assert!(damage(4.0, 1.0, 0.5) < near);
        let w = world();
        // buried in stone → no exposure; in the open → full
        let buried = exposure(&w, Vec3::new(0.5, 61.5, 0.5), Vec3::new(5.0, 20.0, 5.0), Vec3::new(5.6, 21.8, 5.6));
        let open = exposure(&w, Vec3::new(0.5, 70.5, 0.5), Vec3::new(3.0, 70.0, 3.0), Vec3::new(3.6, 71.8, 3.6));
        assert_eq!(buried, 0.0);
        assert!(open > 0.9);
    }
}
