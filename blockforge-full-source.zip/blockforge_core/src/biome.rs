//! Biome registry (40 biomes) and a climate based [`BiomeSource`].
//!
//! The vanilla multi-noise biome source is far more elaborate; this one keeps the same inputs
//! (temperature, humidity, continentalness/height, rivers, peaks) but resolves them with a compact
//! decision table. Biome ids are stored per 4×4×4 cell in every [`Section`](crate::chunk::Section)
//! exactly like the vanilla chunk format.

use crate::noise::OctaveNoise;
use crate::rng::Xoroshiro128pp;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Precip {
    None,
    Rain,
    Snow,
}

#[derive(Clone, Copy, Debug)]
pub struct Biome {
    pub name: &'static str,
    pub temperature: f32,
    pub downfall: f32,
    pub precipitation: Precip,
    pub grass: u32,
    pub foliage: u32,
    pub water: u32,
}

macro_rules! biomes {
    ($( $v:ident $name:literal $t:literal $d:literal $p:ident $g:literal $f:literal $w:literal ;)*) => {
        #[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
        #[repr(u8)]
        pub enum BiomeId { $($v),* }
        pub static BIOMES: &[Biome] = &[
            $( Biome { name: $name, temperature: $t, downfall: $d, precipitation: Precip::$p,
                       grass: $g, foliage: $f, water: $w } ),*
        ];
        impl BiomeId {
            pub const ALL: &'static [BiomeId] = &[ $(BiomeId::$v),* ];
        }
    };
}

biomes! {
    Plains            "minecraft:plains"             0.8  0.4 Rain 0x91BD59 0x77AB2F 0x3F76E4;
    SunflowerPlains   "minecraft:sunflower_plains"   0.8  0.4 Rain 0x91BD59 0x77AB2F 0x3F76E4;
    Forest            "minecraft:forest"             0.7  0.8 Rain 0x79C05A 0x59AE30 0x3F76E4;
    FlowerForest      "minecraft:flower_forest"      0.7  0.8 Rain 0x79C05A 0x59AE30 0x3F76E4;
    BirchForest       "minecraft:birch_forest"       0.6  0.6 Rain 0x88BB67 0x6BA941 0x3F76E4;
    DarkForest        "minecraft:dark_forest"        0.7  0.8 Rain 0x507A32 0x59AE30 0x3F76E4;
    Taiga             "minecraft:taiga"              0.25 0.8 Rain 0x86B783 0x68A464 0x3D57D6;
    OldGrowthPineTaiga "minecraft:old_growth_pine_taiga" 0.3 0.8 Rain 0x86B87F 0x68A55F 0x3D57D6;
    SnowyTaiga        "minecraft:snowy_taiga"        -0.5 0.4 Snow 0x80B497 0x60A17B 0x3D57D6;
    SnowyPlains       "minecraft:snowy_plains"       0.0  0.5 Snow 0x80B497 0x60A17B 0x3D57D6;
    IceSpikes         "minecraft:ice_spikes"         0.0  0.5 Snow 0x80B497 0x60A17B 0x3D57D6;
    Desert            "minecraft:desert"             2.0  0.0 None 0xBFB755 0xAEA42A 0x32A598;
    Savanna           "minecraft:savanna"            2.0  0.0 None 0xBFB755 0xAEA42A 0x2C8B9C;
    SavannaPlateau    "minecraft:savanna_plateau"    1.0  0.0 None 0xBFB755 0xAEA42A 0x2C8B9C;
    Badlands          "minecraft:badlands"           2.0  0.0 None 0x90814D 0x9E814D 0x4E7F81;
    Jungle            "minecraft:jungle"             0.95 0.9 Rain 0x59C93C 0x30BB0B 0x14A2C5;
    SparseJungle      "minecraft:sparse_jungle"      0.95 0.8 Rain 0x64C73F 0x3EB80F 0x14A2C5;
    BambooJungle      "minecraft:bamboo_jungle"      0.95 0.9 Rain 0x59C93C 0x30BB0B 0x14A2C5;
    Swamp             "minecraft:swamp"              0.8  0.9 Rain 0x6A7039 0x6A7039 0x617B64;
    MangroveSwamp     "minecraft:mangrove_swamp"     0.8  0.9 Rain 0x8DB127 0x8DB127 0x3A7A6A;
    Meadow            "minecraft:meadow"             0.5  0.8 Rain 0x83BB6D 0x63A948 0x0E4ECF;
    CherryGrove       "minecraft:cherry_grove"       0.5  0.8 Rain 0xB6DB61 0xB6DB61 0x5DB7EF;
    Grove             "minecraft:grove"              -0.2 0.8 Snow 0x80B497 0x60A17B 0x3D57D6;
    SnowySlopes       "minecraft:snowy_slopes"       -0.3 0.9 Snow 0x80B497 0x60A17B 0x3D57D6;
    FrozenPeaks       "minecraft:frozen_peaks"       -0.7 0.9 Snow 0x80B497 0x60A17B 0x3D57D6;
    JaggedPeaks       "minecraft:jagged_peaks"       -0.7 0.9 Snow 0x80B497 0x60A17B 0x3D57D6;
    StonyPeaks        "minecraft:stony_peaks"        1.0  0.3 Rain 0x9ABE4B 0x82AC1E 0x3F76E4;
    WindsweptHills    "minecraft:windswept_hills"    0.2  0.3 Rain 0x8AB689 0x6DA36B 0x3F76E4;
    WindsweptForest   "minecraft:windswept_forest"   0.2  0.3 Rain 0x8AB689 0x6DA36B 0x3F76E4;
    Beach             "minecraft:beach"              0.8  0.4 Rain 0x91BD59 0x77AB2F 0x3F76E4;
    SnowyBeach        "minecraft:snowy_beach"        0.05 0.3 Snow 0x83B593 0x64A278 0x3D57D6;
    StonyShore        "minecraft:stony_shore"        0.2  0.3 Rain 0x8AB689 0x6DA36B 0x3F76E4;
    River             "minecraft:river"              0.5  0.5 Rain 0x79C05A 0x59AE30 0x3F76E4;
    FrozenRiver       "minecraft:frozen_river"       0.0  0.5 Snow 0x80B497 0x60A17B 0x3938C9;
    Ocean             "minecraft:ocean"              0.5  0.5 Rain 0x8EB971 0x71A74D 0x3F76E4;
    DeepOcean         "minecraft:deep_ocean"         0.5  0.5 Rain 0x8EB971 0x71A74D 0x3F76E4;
    WarmOcean         "minecraft:warm_ocean"         0.5  0.5 Rain 0x8EB971 0x71A74D 0x43D5EE;
    ColdOcean         "minecraft:cold_ocean"         0.5  0.5 Rain 0x8EB971 0x71A74D 0x3D57D6;
    FrozenOcean       "minecraft:frozen_ocean"       0.0  0.5 Snow 0x80B497 0x60A17B 0x3938C9;
    MushroomFields    "minecraft:mushroom_fields"    0.9  1.0 Rain 0x55C93F 0x2BBB0F 0x3F76E4;
    LushCaves         "minecraft:lush_caves"         0.5  0.5 Rain 0x7CBD6B 0x5AAB39 0x3F76E4;
    DripstoneCaves    "minecraft:dripstone_caves"    0.8  0.4 Rain 0x91BD59 0x77AB2F 0x3F76E4;
}

impl BiomeId {
    #[inline]
    pub fn info(self) -> &'static Biome {
        &BIOMES[self as usize]
    }
    #[inline]
    pub fn from_u8(v: u8) -> BiomeId {
        BiomeId::ALL.get(v as usize).copied().unwrap_or(BiomeId::Plains)
    }
    pub fn name(self) -> &'static str {
        self.info().name
    }
    pub fn from_name(n: &str) -> Option<BiomeId> {
        BIOMES.iter().position(|b| b.name == n || b.name.trim_start_matches("minecraft:") == n).map(|i| BiomeId::ALL[i])
    }
    pub fn is_ocean(self) -> bool {
        matches!(self, BiomeId::Ocean | BiomeId::DeepOcean | BiomeId::WarmOcean | BiomeId::ColdOcean | BiomeId::FrozenOcean)
    }
    pub fn is_cold(self) -> bool {
        self.info().precipitation == Precip::Snow
    }
    pub fn is_mountain(self) -> bool {
        matches!(
            self,
            BiomeId::FrozenPeaks | BiomeId::JaggedPeaks | BiomeId::StonyPeaks | BiomeId::SnowySlopes | BiomeId::Grove
                | BiomeId::WindsweptHills | BiomeId::WindsweptForest
        )
    }
    pub fn is_forest(self) -> bool {
        matches!(self, BiomeId::Forest | BiomeId::FlowerForest | BiomeId::BirchForest | BiomeId::DarkForest)
    }
    /// Precipitation that actually falls at world height `y` (snow above ~ y 160 even in warm biomes).
    pub fn precipitation_at(self, y: i32) -> Precip {
        let p = self.info().precipitation;
        if p == Precip::None {
            Precip::None
        } else if p == Precip::Rain && y > 200 {
            Precip::Snow
        } else {
            p
        }
    }
}

/// Climate sampler. All inputs are in `-1..=1`.
pub struct BiomeSource {
    temperature: OctaveNoise,
    humidity: OctaveNoise,
    weirdness: OctaveNoise,
    river: OctaveNoise,
}

/// Terrain facts the biome decision needs about a column.
#[derive(Clone, Copy, Debug)]
pub struct ColumnInfo {
    pub height: i32,
    pub sea_level: i32,
    pub river: bool,
}

impl BiomeSource {
    pub fn new(seed: i64) -> Self {
        let mut r = Xoroshiro128pp::from_seed(seed ^ 0x0B10_4E5);
        Self {
            temperature: OctaveNoise::new(&mut r, 4),
            humidity: OctaveNoise::new(&mut r, 4),
            weirdness: OctaveNoise::new(&mut r, 3),
            river: OctaveNoise::new(&mut r, 3),
        }
    }

    pub fn temperature(&self, x: i32, z: i32) -> f64 {
        (self.temperature.sample2d(x as f64 / 380.0, z as f64 / 380.0) * 2.3).clamp(-1.0, 1.0)
    }
    pub fn humidity(&self, x: i32, z: i32) -> f64 {
        (self.humidity.sample2d(x as f64 / 320.0 + 500.0, z as f64 / 320.0 - 500.0) * 2.3).clamp(-1.0, 1.0)
    }
    pub fn weirdness(&self, x: i32, z: i32) -> f64 {
        self.weirdness.sample2d(x as f64 / 90.0, z as f64 / 90.0)
    }
    /// 0 on the river centre line, grows to 1 away from it.
    pub fn river_distance(&self, x: i32, z: i32) -> f64 {
        (self.river.sample2d(x as f64 / 600.0 + 77.0, z as f64 / 600.0 - 31.0) * 5.0).abs().min(1.0) / 1.0
    }

    pub fn biome(&self, x: i32, z: i32, c: ColumnInfo) -> BiomeId {
        let t = self.temperature(x, z);
        let h = self.humidity(x, z);
        let w = self.weirdness(x, z);
        let above = c.height - c.sea_level;

        if c.river && above < 6 {
            return if t < -0.45 { BiomeId::FrozenRiver } else { BiomeId::River };
        }
        if above < -1 {
            // below sea level -> oceans
            let deep = above < -24;
            if t > 0.55 && !deep {
                return BiomeId::WarmOcean;
            }
            if t < -0.5 {
                return BiomeId::FrozenOcean;
            }
            if w > 0.75 && deep && h > 0.3 {
                return BiomeId::MushroomFields;
            }
            if t < -0.15 {
                return BiomeId::ColdOcean;
            }
            return if deep { BiomeId::DeepOcean } else { BiomeId::Ocean };
        }
        if above <= 1 {
            return if t < -0.45 {
                BiomeId::SnowyBeach
            } else if w > 0.5 && t < 0.3 {
                BiomeId::StonyShore
            } else if t > 0.55 && h < -0.25 {
                BiomeId::Desert
            } else {
                BiomeId::Beach
            };
        }
        // mountains
        if above > 75 {
            return if t < -0.25 {
                if w > 0.1 { BiomeId::JaggedPeaks } else { BiomeId::FrozenPeaks }
            } else if t > 0.4 {
                BiomeId::StonyPeaks
            } else if h > 0.0 {
                BiomeId::SnowySlopes
            } else {
                BiomeId::JaggedPeaks
            };
        }
        if above > 48 {
            return if t < -0.3 {
                BiomeId::Grove
            } else if t < 0.15 && h > 0.1 {
                BiomeId::CherryGrove
            } else if t < 0.5 {
                if h > 0.15 { BiomeId::WindsweptForest } else { BiomeId::WindsweptHills }
            } else {
                BiomeId::Meadow
            };
        }
        // land
        if t < -0.45 {
            if h > 0.15 {
                BiomeId::SnowyTaiga
            } else if w > 0.62 {
                BiomeId::IceSpikes
            } else {
                BiomeId::SnowyPlains
            }
        } else if t < -0.1 {
            if h > 0.5 {
                BiomeId::OldGrowthPineTaiga
            } else if h > -0.2 {
                BiomeId::Taiga
            } else {
                BiomeId::Plains
            }
        } else if t < 0.25 {
            if h < -0.35 {
                BiomeId::Plains
            } else if h < -0.05 {
                if w > 0.55 { BiomeId::SunflowerPlains } else { BiomeId::Meadow }
            } else if h < 0.3 {
                if w > 0.5 { BiomeId::FlowerForest } else { BiomeId::Forest }
            } else if h < 0.55 {
                BiomeId::BirchForest
            } else if above <= 8 && w < -0.2 {
                BiomeId::Swamp
            } else {
                BiomeId::DarkForest
            }
        } else if t < 0.55 {
            if h < -0.3 {
                if above > 20 { BiomeId::SavannaPlateau } else { BiomeId::Savanna }
            } else if h < 0.2 {
                BiomeId::Plains
            } else if h < 0.45 {
                BiomeId::Forest
            } else if above <= 6 {
                if w < -0.3 { BiomeId::MangroveSwamp } else { BiomeId::Swamp }
            } else {
                BiomeId::SparseJungle
            }
        } else if h < -0.35 {
            BiomeId::Desert
        } else if h < -0.05 {
            if w > 0.2 { BiomeId::Badlands } else { BiomeId::Savanna }
        } else if h < 0.35 {
            BiomeId::SparseJungle
        } else if h < 0.65 {
            BiomeId::Jungle
        } else {
            BiomeId::BambooJungle
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn registry_is_consistent() {
        assert_eq!(BIOMES.len(), BiomeId::ALL.len());
        assert!(BIOMES.len() >= 40);
        for (i, b) in BiomeId::ALL.iter().enumerate() {
            assert_eq!(*b as usize, i);
            assert_eq!(BiomeId::from_name(b.name()), Some(*b));
        }
        assert!(BiomeId::Desert.info().precipitation == Precip::None);
        assert_eq!(BiomeId::from_u8(250), BiomeId::Plains);
    }

    #[test]
    fn oceans_and_peaks_follow_height() {
        let s = BiomeSource::new(5);
        let c = |height| ColumnInfo { height, sea_level: 63, river: false };
        assert!(s.biome(100, 100, c(30)).is_ocean());
        assert!(s.biome(100, 100, c(150)).is_mountain());
        assert!(!s.biome(100, 100, c(70)).is_ocean());
        assert!(matches!(s.biome(0, 0, ColumnInfo { height: 64, sea_level: 63, river: true }), BiomeId::River | BiomeId::FrozenRiver));
    }

    #[test]
    fn many_distinct_biomes_appear() {
        let s = BiomeSource::new(99);
        let mut seen = std::collections::HashSet::new();
        for i in 0..160 {
            for j in 0..160 {
                let (x, z) = (i * 97, j * 97);
                let h = 64 + ((i * 13 + j * 7) % 60) - 10;
                seen.insert(s.biome(x, z, ColumnInfo { height: h, sea_level: 63, river: false }));
            }
        }
        assert!(seen.len() >= 18, "only {} biomes", seen.len());
    }
}
