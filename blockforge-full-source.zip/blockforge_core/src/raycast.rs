//! Voxel ray traversal (Amanatides & Woo DDA).

use crate::block::BlockId;
use crate::math::{floor, BlockPos, Face, Vec3};
use crate::world::World;

pub const REACH_SURVIVAL: f64 = 4.5; // block interaction range in 1.21
pub const REACH_CREATIVE: f64 = 5.0;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BlockHit {
    pub pos: BlockPos,
    /// Face of `pos` that was hit.
    pub face: Face,
    pub point: Vec3,
    pub distance: f64,
    pub block: BlockId,
}

impl BlockHit {
    /// Position where a new block would be placed.
    pub fn placement_pos(&self) -> BlockPos {
        self.pos.relative(self.face)
    }
}

/// Casts a ray through the world and returns the first block for which `hit(block)` is true.
pub fn raycast<F: Fn(BlockId) -> bool>(world: &World, origin: Vec3, dir: Vec3, max_dist: f64, hit: F) -> Option<BlockHit> {
    let dir = dir.normalize();
    if dir.length_sqr() == 0.0 {
        return None;
    }
    let mut x = floor(origin.x);
    let mut y = floor(origin.y);
    let mut z = floor(origin.z);

    let step_x = if dir.x > 0.0 { 1 } else { -1 };
    let step_y = if dir.y > 0.0 { 1 } else { -1 };
    let step_z = if dir.z > 0.0 { 1 } else { -1 };

    let inv = |d: f64| if d == 0.0 { f64::INFINITY } else { (1.0 / d).abs() };
    let (dx, dy, dz) = (inv(dir.x), inv(dir.y), inv(dir.z));

    let next = |o: f64, cell: i32, step: i32, d: f64| -> f64 {
        if d.is_infinite() {
            f64::INFINITY
        } else if step > 0 {
            ((cell + 1) as f64 - o) * d
        } else {
            (o - cell as f64) * d
        }
    };
    let mut tx = next(origin.x, x, step_x, dx);
    let mut ty = next(origin.y, y, step_y, dy);
    let mut tz = next(origin.z, z, step_z, dz);

    // starting inside a matching block
    let b = world.get_block(x, y, z);
    if hit(b) {
        return Some(BlockHit { pos: BlockPos::new(x, y, z), face: Face::Up, point: origin, distance: 0.0, block: b });
    }

    loop {
        let (t, face) = if tx <= ty && tx <= tz {
            x += step_x;
            let t = tx;
            tx += dx;
            (t, if step_x > 0 { Face::West } else { Face::East })
        } else if ty <= tz {
            y += step_y;
            let t = ty;
            ty += dy;
            (t, if step_y > 0 { Face::Down } else { Face::Up })
        } else {
            z += step_z;
            let t = tz;
            tz += dz;
            (t, if step_z > 0 { Face::North } else { Face::South })
        };
        if t > max_dist {
            return None;
        }
        let b = world.get_block(x, y, z);
        if hit(b) {
            return Some(BlockHit { pos: BlockPos::new(x, y, z), face, point: origin + dir * t, distance: t, block: b });
        }
    }
}

/// Convenience: first non-air, non-liquid block (what the player can mine).
pub fn raycast_solid(world: &World, origin: Vec3, dir: Vec3, max_dist: f64) -> Option<BlockHit> {
    raycast(world, origin, dir, max_dist, |b| !b.is_air() && !b.is_liquid())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::Chunk;
    use crate::math::ChunkPos;

    fn world_with(blocks: &[(i32, i32, i32)]) -> World {
        let mut w = World::new(0);
        for cx in -1..=1 {
            for cz in -1..=1 {
                w.insert_chunk(Chunk::new(ChunkPos::new(cx, cz)));
            }
        }
        for &(x, y, z) in blocks {
            w.set_block(x, y, z, BlockId::STONE);
        }
        w
    }

    #[test]
    fn hits_block_straight_ahead() {
        let w = world_with(&[(5, 64, 0)]);
        let h = raycast_solid(&w, Vec3::new(0.5, 64.5, 0.5), Vec3::new(1.0, 0.0, 0.0), 10.0).unwrap();
        assert_eq!(h.pos, BlockPos::new(5, 64, 0));
        assert_eq!(h.face, Face::West);
        assert!((h.distance - 4.5).abs() < 1e-9);
        assert_eq!(h.placement_pos(), BlockPos::new(4, 64, 0));
    }

    #[test]
    fn respects_max_distance() {
        let w = world_with(&[(9, 64, 0)]);
        assert!(raycast_solid(&w, Vec3::new(0.5, 64.5, 0.5), Vec3::new(1.0, 0.0, 0.0), 4.5).is_none());
    }

    #[test]
    fn hits_floor_from_above() {
        let w = world_with(&[(0, 60, 0)]);
        let h = raycast_solid(&w, Vec3::new(0.5, 64.0, 0.5), Vec3::new(0.0, -1.0, 0.0), 10.0).unwrap();
        assert_eq!(h.face, Face::Up);
        assert_eq!(h.pos.y, 60);
    }

    #[test]
    fn diagonal_ray() {
        let w = world_with(&[(3, 67, 3)]);
        let h = raycast_solid(&w, Vec3::new(0.5, 64.5, 0.5), Vec3::new(1.0, 1.0, 1.0), 10.0).unwrap();
        assert_eq!(h.pos, BlockPos::new(3, 67, 3));
    }

    #[test]
    fn negative_direction() {
        let w = world_with(&[(-4, 64, -4)]);
        let h = raycast_solid(&w, Vec3::new(0.5, 64.5, 0.5), Vec3::new(-1.0, 0.0, -1.0), 10.0);
        assert!(h.is_some());
    }
}
