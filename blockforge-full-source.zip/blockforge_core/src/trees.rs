//! Tree, giant-mushroom and ice-spike generators.
//!
//! Every generator writes through the [`BlockSink`] trait, so the same code serves terrain
//! generation (clipped to the chunk that is being built — see [`ChunkSink`]), sapling growth
//! in a live [`World`](crate::world::World) and `/place`-style commands.
//!
//! World generation re-runs the placement RNG of the 3×3 neighbouring chunks for every chunk
//! it builds, so a canopy that crosses a chunk border is always complete (no cut trees).

use crate::block::BlockId;
use crate::chunk::Chunk;
use crate::rng::{JavaRandom, RandomSource};
use crate::world::World;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum TreeKind {
    Oak,
    BigOak,
    Birch,
    Spruce,
    Pine,
    Jungle,
    Acacia,
    DarkOak,
    Cherry,
    Mangrove,
    BrownMushroom,
    RedMushroom,
    IceSpike,
}

pub trait BlockSink {
    fn get(&self, x: i32, y: i32, z: i32) -> BlockId;
    fn set(&mut self, x: i32, y: i32, z: i32, id: BlockId);
}

impl BlockSink for World {
    fn get(&self, x: i32, y: i32, z: i32) -> BlockId {
        self.get_block(x, y, z)
    }
    fn set(&mut self, x: i32, y: i32, z: i32, id: BlockId) {
        self.set_block(x, y, z, id);
    }
}

/// Writes world coordinates into one chunk and silently drops everything outside it.
pub struct ChunkSink<'a> {
    pub chunk: &'a mut Chunk,
}

impl ChunkSink<'_> {
    #[inline]
    fn local(&self, x: i32, z: i32) -> Option<(usize, usize)> {
        let (lx, lz) = (x - self.chunk.pos.min_block_x(), z - self.chunk.pos.min_block_z());
        ((0..16).contains(&lx) && (0..16).contains(&lz)).then_some((lx as usize, lz as usize))
    }
}

impl BlockSink for ChunkSink<'_> {
    fn get(&self, x: i32, y: i32, z: i32) -> BlockId {
        match self.local(x, z) {
            Some((lx, lz)) => self.chunk.get_block(lx, y, lz),
            None => BlockId::STONE, // "solid" so nothing is ever placed against it
        }
    }
    fn set(&mut self, x: i32, y: i32, z: i32, id: BlockId) {
        if let Some((lx, lz)) = self.local(x, z) {
            self.chunk.set_block(lx, y, lz, id);
        }
    }
}

#[inline]
fn soft(b: BlockId) -> bool {
    b.is_air() || b.is_leaves() || (b.is_cross() && !b.is_climbable())
}

fn log<S: BlockSink>(s: &mut S, x: i32, y: i32, z: i32, id: BlockId) {
    if soft(s.get(x, y, z)) {
        s.set(x, y, z, id);
    }
}

fn leaf<S: BlockSink>(s: &mut S, x: i32, y: i32, z: i32, id: BlockId) {
    let b = s.get(x, y, z);
    if b.is_air() || (b.is_cross() && !b.is_climbable()) {
        s.set(x, y, z, id);
    }
}

/// Square-ish disc of leaves with optional random corner removal.
#[allow(clippy::too_many_arguments)]
fn disc<S: BlockSink>(s: &mut S, cx: i32, y: i32, cz: i32, r: i32, id: BlockId, rng: &mut JavaRandom, trim: bool) {
    for dx in -r..=r {
        for dz in -r..=r {
            if trim && r >= 2 && dx.abs() == r && dz.abs() == r && rng.next_bool() {
                continue;
            }
            leaf(s, cx + dx, y, cz + dz, id);
        }
    }
}

fn round_disc<S: BlockSink>(s: &mut S, cx: i32, y: i32, cz: i32, r: i32, id: BlockId) {
    for dx in -r..=r {
        for dz in -r..=r {
            if dx * dx + dz * dz <= r * r + r / 2 {
                leaf(s, cx + dx, y, cz + dz, id);
            }
        }
    }
}

/// How far a tree can reach horizontally from its trunk (for callers that clip to borders).
pub fn max_radius(kind: TreeKind) -> i32 {
    match kind {
        TreeKind::BigOak | TreeKind::Pine => 4,
        TreeKind::Oak | TreeKind::Birch => 2,
        _ => 3,
    }
}

/// Logs / leaves used by [`grow`] for a kind.
pub fn blocks_for(kind: TreeKind) -> (BlockId, BlockId) {
    match kind {
        TreeKind::Oak | TreeKind::BigOak => (BlockId::OAK_LOG, BlockId::OAK_LEAVES),
        TreeKind::Birch => (BlockId::BIRCH_LOG, BlockId::BIRCH_LEAVES),
        TreeKind::Spruce | TreeKind::Pine => (BlockId::SPRUCE_LOG, BlockId::SPRUCE_LEAVES),
        TreeKind::Jungle => (BlockId::JUNGLE_LOG, BlockId::JUNGLE_LEAVES),
        TreeKind::Acacia => (BlockId::ACACIA_LOG, BlockId::ACACIA_LEAVES),
        TreeKind::DarkOak => (BlockId::DARK_OAK_LOG, BlockId::DARK_OAK_LEAVES),
        TreeKind::Cherry => (BlockId::CHERRY_LOG, BlockId::CHERRY_LEAVES),
        TreeKind::Mangrove => (BlockId::MANGROVE_LOG, BlockId::MANGROVE_LEAVES),
        TreeKind::BrownMushroom => (BlockId::MUSHROOM_STEM, BlockId::BROWN_MUSHROOM_BLOCK),
        TreeKind::RedMushroom => (BlockId::MUSHROOM_STEM, BlockId::RED_MUSHROOM_BLOCK),
        TreeKind::IceSpike => (BlockId::PACKED_ICE, BlockId::PACKED_ICE),
    }
}

/// Grows a tree whose trunk stands on the soil block at `(x, ground, z)`.
pub fn grow<S: BlockSink>(s: &mut S, kind: TreeKind, x: i32, ground: i32, z: i32, rng: &mut JavaRandom) {
    let (lg, lf) = blocks_for(kind);
    let y0 = ground + 1;
    match kind {
        TreeKind::Oak | TreeKind::Birch => {
            let h = if kind == TreeKind::Birch { 5 + rng.next_i32_bounded(3) } else { 4 + rng.next_i32_bounded(3) };
            let top = ground + h;
            for dy in -1..=2 {
                let r = if dy >= 1 { 1 } else { 2 };
                disc(s, x, top + dy, z, r, lf, rng, true);
            }
            for y in y0..=top + 1 {
                log(s, x, y, z, lg);
            }
        }
        TreeKind::BigOak => {
            let h = 8 + rng.next_i32_bounded(5);
            let top = ground + h;
            for y in y0..=top {
                log(s, x, y, z, lg);
            }
            // branch blobs
            let mut blobs = vec![(0, top, 0)];
            for _ in 0..4 {
                let a = rng.next_i32_bounded(3) - 1;
                let b = rng.next_i32_bounded(3) - 1;
                let by = top - 2 - rng.next_i32_bounded(3);
                let (bx, bz) = (a * 2, b * 2);
                for i in 1..=2 {
                    log(s, x + bx * i / 2, by + i - 1, z + bz * i / 2, lg);
                }
                blobs.push((bx, by + 2, bz));
            }
            for (bx, by, bz) in blobs {
                for dy in -2..=2i32 {
                    let r = 3 - dy.abs() / 2 - if dy.abs() == 2 { 1 } else { 0 };
                    round_disc(s, x + bx, by + dy, z + bz, r.max(1), lf);
                }
            }
        }
        TreeKind::Spruce | TreeKind::Pine => {
            let h = if kind == TreeKind::Pine { 10 + rng.next_i32_bounded(7) } else { 6 + rng.next_i32_bounded(4) };
            let top = ground + h;
            for y in y0..=top {
                log(s, x, y, z, lg);
            }
            leaf(s, x, top + 1, z, lf);
            let seq: [i32; 9] = if kind == TreeKind::Pine { [1, 2, 2, 3, 2, 3, 3, 4, 3] } else { [1, 2, 1, 2, 3, 2, 3, 2, 3] };
            let layers = h - 2;
            for i in 0..layers {
                let r = seq[(i as usize).min(8)];
                let y = top - i;
                for dx in -r..=r {
                    for dz in -r..=r {
                        if (dx * dx + dz * dz) <= r * r + 1 && !(dx == 0 && dz == 0) {
                            leaf(s, x + dx, y, z + dz, lf);
                        }
                    }
                }
            }
        }
        TreeKind::Jungle => {
            let h = 8 + rng.next_i32_bounded(7);
            let top = ground + h;
            for y in y0..=top {
                log(s, x, y, z, lg);
            }
            for (i, r) in [3, 3, 2, 1].iter().enumerate() {
                disc(s, x, top - 1 + i as i32, z, *r, lf, rng, true);
            }
            // a few vines hanging from the trunk
            for dir in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
                if rng.next_i32_bounded(3) == 0 {
                    for k in 0..(2 + rng.next_i32_bounded(4)) {
                        let (vx, vy, vz) = (x + dir.0, y0 + 2 + k, z + dir.1);
                        if s.get(vx, vy, vz).is_air() {
                            s.set(vx, vy, vz, BlockId::VINE);
                        }
                    }
                }
            }
        }
        TreeKind::Acacia => {
            let h = 5 + rng.next_i32_bounded(2);
            let dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)];
            let d = dirs[rng.next_i32_bounded(4) as usize];
            let (mut cx, mut cz) = (x, z);
            let mut y = y0;
            for i in 0..h {
                log(s, cx, y, cz, lg);
                if i >= h - 3 {
                    cx += d.0;
                    cz += d.1;
                }
                y += 1;
            }
            log(s, cx, y, cz, lg);
            disc(s, cx, y, cz, 2, lf, rng, true);
            disc(s, cx, y + 1, cz, 1, lf, rng, false);
            // second smaller branch
            if rng.next_bool() {
                let (bx, bz) = (x - d.0 * 2, z - d.1 * 2);
                log(s, x - d.0, y0 + h - 3, z - d.1, lg);
                log(s, bx, y0 + h - 2, bz, lg);
                disc(s, bx, y0 + h - 1, bz, 2, lf, rng, true);
            }
        }
        TreeKind::DarkOak => {
            let h = 6 + rng.next_i32_bounded(3);
            let top = ground + h;
            for y in y0..=top {
                for (dx, dz) in [(0, 0), (1, 0), (0, 1), (1, 1)] {
                    log(s, x + dx, y, z + dz, lg);
                }
            }
            for (i, r) in [2i32, 3, 3, 2].iter().enumerate() {
                let y = top - 1 + i as i32;
                for dx in -r..=r + 1 {
                    for dz in -r..=r + 1 {
                        let (ax, az) = (if dx > 0 { dx - 1 } else { dx }, if dz > 0 { dz - 1 } else { dz });
                        if ax.abs() == *r && az.abs() == *r && *r >= 3 && rng.next_bool() {
                            continue;
                        }
                        leaf(s, x + dx, y, z + dz, lf);
                    }
                }
            }
        }
        TreeKind::Cherry => {
            let h = 5 + rng.next_i32_bounded(3);
            let top = ground + h;
            for y in y0..=top {
                log(s, x, y, z, lg);
            }
            for (i, r) in [2, 3, 3, 2].iter().enumerate() {
                disc(s, x, top - 2 + i as i32, z, *r, lf, rng, true);
            }
            // fallen petals
            for _ in 0..4 {
                let (px, pz) = (x + rng.next_i32_bounded(7) - 3, z + rng.next_i32_bounded(7) - 3);
                if s.get(px, y0, pz).is_air() && !s.get(px, ground, pz).is_air() {
                    s.set(px, y0, pz, BlockId::PINK_PETALS);
                }
            }
        }
        TreeKind::Mangrove => {
            let h = 5 + rng.next_i32_bounded(4);
            let top = ground + h;
            for y in y0..=top {
                log(s, x, y, z, lg);
            }
            for d in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
                if rng.next_i32_bounded(5) < 3 {
                    log(s, x + d.0, y0, z + d.1, BlockId::MANGROVE_ROOTS);
                    log(s, x + d.0, y0 - 1, z + d.1, BlockId::MANGROVE_ROOTS);
                }
            }
            for (i, r) in [3, 3, 2].iter().enumerate() {
                disc(s, x, top - 1 + i as i32, z, *r, lf, rng, true);
            }
        }
        TreeKind::BrownMushroom => {
            let h = 4 + rng.next_i32_bounded(3);
            for y in y0..y0 + h {
                log(s, x, y, z, lg);
            }
            for dx in -3..=3i32 {
                for dz in -3..=3i32 {
                    if dx.abs() == 3 && dz.abs() == 3 {
                        continue;
                    }
                    leaf(s, x + dx, y0 + h, z + dz, lf);
                }
            }
        }
        TreeKind::RedMushroom => {
            let h = 3 + rng.next_i32_bounded(3);
            for y in y0..y0 + h {
                log(s, x, y, z, lg);
            }
            for dy in 0..3 {
                let r: i32 = [2, 2, 1][dy as usize];
                for dx in -r..=r {
                    for dz in -r..=r {
                        if dy < 2 && dx.abs() < r && dz.abs() < r {
                            continue; // hollow ring under the cap
                        }
                        leaf(s, x + dx, y0 + h - 2 + dy, z + dz, lf);
                    }
                }
            }
        }
        TreeKind::IceSpike => {
            let h = 10 + rng.next_i32_bounded(12);
            for i in 0..h {
                let r = ((3.0 * (1.0 - i as f64 / h as f64)).round() as i32).max(0);
                for dx in -r..=r {
                    for dz in -r..=r {
                        if dx * dx + dz * dz <= r * r + 1 {
                            let (px, py, pz) = (x + dx, ground + i, z + dz);
                            let b = s.get(px, py, pz);
                            if soft(b) || b == BlockId::SNOW_BLOCK || b == BlockId::DIRT {
                                s.set(px, py, pz, BlockId::PACKED_ICE);
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Which soil a tree kind accepts.
pub fn soil_ok(kind: TreeKind, soil: BlockId) -> bool {
    use TreeKind::*;
    let grassy = matches!(
        soil,
        BlockId::GRASS_BLOCK | BlockId::DIRT | BlockId::PODZOL | BlockId::COARSE_DIRT | BlockId::MOSS_BLOCK
    );
    match kind {
        Spruce | Pine => grassy || soil == BlockId::SNOW_BLOCK,
        Mangrove => soil == BlockId::MUD || grassy,
        BrownMushroom | RedMushroom => grassy || soil == BlockId::MYCELIUM,
        IceSpike => soil == BlockId::SNOW_BLOCK,
        _ => grassy,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::math::ChunkPos;

    fn flat(pos: ChunkPos) -> Chunk {
        let mut c = Chunk::new(pos);
        for x in 0..16 {
            for z in 0..16 {
                for y in -64..=63 {
                    c.set_block(x, y, z, if y == 63 { BlockId::GRASS_BLOCK } else { BlockId::STONE });
                }
            }
        }
        c
    }

    #[test]
    fn every_kind_grows_logs_and_stays_in_bounds() {
        let kinds = [
            TreeKind::Oak, TreeKind::BigOak, TreeKind::Birch, TreeKind::Spruce, TreeKind::Pine, TreeKind::Jungle,
            TreeKind::Acacia, TreeKind::DarkOak, TreeKind::Cherry, TreeKind::Mangrove, TreeKind::BrownMushroom,
            TreeKind::RedMushroom,
        ];
        for k in kinds {
            let mut c = flat(ChunkPos::new(0, 0));
            let mut rng = JavaRandom::new(7);
            grow(&mut ChunkSink { chunk: &mut c }, k, 8, 63, 8, &mut rng);
            let (lg, lf) = blocks_for(k);
            let mut logs = 0;
            let mut leaves = 0;
            for y in 64..110 {
                for x in 0..16 {
                    for z in 0..16 {
                        let b = c.get_block(x, y, z);
                        logs += (b == lg) as i32;
                        leaves += (b == lf) as i32;
                    }
                }
            }
            assert!(logs >= 3, "{k:?} grew {logs} logs");
            assert!(leaves >= 5, "{k:?} grew {leaves} leaves");
        }
    }

    #[test]
    fn ice_spike_and_clipping_at_chunk_edges() {
        let mut c = flat(ChunkPos::new(0, 0));
        c.set_block(8, 63, 8, BlockId::SNOW_BLOCK);
        let mut rng = JavaRandom::new(3);
        grow(&mut ChunkSink { chunk: &mut c }, TreeKind::IceSpike, 8, 63, 8, &mut rng);
        assert_eq!(c.get_block(8, 66, 8), BlockId::PACKED_ICE);
        // tree at the very edge must not panic and just clips
        let mut rng = JavaRandom::new(3);
        grow(&mut ChunkSink { chunk: &mut c }, TreeKind::Jungle, 0, 63, 0, &mut rng);
        grow(&mut ChunkSink { chunk: &mut c }, TreeKind::DarkOak, 15, 63, 15, &mut rng);
    }

    #[test]
    fn soil_rules() {
        assert!(soil_ok(TreeKind::Oak, BlockId::GRASS_BLOCK));
        assert!(!soil_ok(TreeKind::Oak, BlockId::SAND));
        assert!(soil_ok(TreeKind::Spruce, BlockId::SNOW_BLOCK));
        assert!(soil_ok(TreeKind::Mangrove, BlockId::MUD));
    }
}
