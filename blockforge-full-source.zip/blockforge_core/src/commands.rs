//! Slash-command parser + executor (`/gamemode`, `/time`, `/weather`, `/tp`, `/give`, `/setblock`,
//! `/fill`, `/effect`, `/xp`, `/kill`, `/clear`, `/seed`, `/biome`, `/fly`, `/heal`, `/feed`, `/help`).

use crate::block::BlockId;
use crate::effects::{ActiveEffects, Effect};
use crate::game::{GameMode, Vitals};
use crate::inventory::{Inventory, ItemStack};
use crate::item::ItemId;
use crate::math::{floor, BlockPos, Vec3};
use crate::physics::Player;
use crate::time::{GameClock, Weather};
use crate::world::World;

pub struct CommandContext<'a> {
    pub world: &'a mut World,
    pub player: &'a mut Player,
    pub inventory: &'a mut Inventory,
    pub vitals: &'a mut Vitals,
    pub clock: &'a mut GameClock,
    pub weather: &'a mut Weather,
    pub gamemode: &'a mut GameMode,
    pub effects: &'a mut ActiveEffects,
    /// Every block position changed by the command (so the caller can re-mesh).
    pub changed: &'a mut Vec<BlockPos>,
}

pub const COMMANDS: &[(&str, &str)] = &[
    ("gamemode <survival|creative|adventure|spectator>", "change game mode"),
    ("time <set <day|noon|night|midnight|N>|add N|query>", "control the clock"),
    ("weather <clear|rain|thunder> [seconds]", "control the weather"),
    ("tp <x> <y> <z>", "teleport (supports ~ relative coordinates)"),
    ("give <item> [count]", "give items"),
    ("setblock <x> <y> <z> <block>", "place a block"),
    ("fill <x1 y1 z1 x2 y2 z2> <block> [replace <block>]", "fill a region (max 32768 blocks)"),
    ("effect <give <effect> [seconds] [level]|clear>", "status effects"),
    ("xp <add N|query>", "experience"),
    ("kill / heal / feed / clear", "player utilities"),
    ("fly", "toggle flight (creative / spectator)"),
    ("seed / biome / pos", "information"),
    ("help", "this list"),
];

fn coord(arg: &str, base: f64) -> Result<f64, String> {
    if let Some(rest) = arg.strip_prefix('~') {
        if rest.is_empty() {
            Ok(base)
        } else {
            rest.parse::<f64>().map(|v| base + v).map_err(|_| format!("bad coordinate '{arg}'"))
        }
    } else {
        arg.parse::<f64>().map_err(|_| format!("bad coordinate '{arg}'"))
    }
}

fn block_arg(s: &str) -> Result<BlockId, String> {
    BlockId::from_name(s).ok_or_else(|| format!("unknown block '{s}'"))
}

pub fn execute(ctx: &mut CommandContext<'_>, line: &str) -> Result<Vec<String>, String> {
    let line = line.trim().trim_start_matches('/');
    let args: Vec<&str> = line.split_whitespace().collect();
    let Some(cmd) = args.first().copied() else { return Err("empty command".into()) };
    let a = &args[1..];
    match cmd {
        "help" | "?" => Ok(COMMANDS.iter().map(|(c, d)| format!("/{c} — {d}")).collect()),
        "gamemode" | "gm" => {
            let m = a.first().and_then(|s| GameMode::from_name(s)).ok_or("usage: /gamemode <survival|creative|adventure|spectator>")?;
            *ctx.gamemode = m;
            ctx.player.can_fly = m.can_fly();
            if !m.can_fly() {
                ctx.player.flying = false;
            }
            Ok(vec![format!("Game mode set to {}", m.name())])
        }
        "fly" => {
            if !ctx.player.can_fly {
                return Err("flight needs creative or spectator mode".into());
            }
            ctx.player.flying = !ctx.player.flying;
            Ok(vec![format!("flying: {}", ctx.player.flying)])
        }
        "time" => match a.first().copied() {
            Some("set") => {
                let v = a.get(1).ok_or("usage: /time set <value>")?;
                if let Ok(n) = v.parse::<u64>() {
                    ctx.clock.day_time = ctx.clock.day_number() * crate::time::DAY_LENGTH + n % crate::time::DAY_LENGTH;
                } else if !ctx.clock.set_named(v) {
                    return Err(format!("unknown time '{v}'"));
                }
                Ok(vec![format!("Time set to {}", ctx.clock.time_of_day())])
            }
            Some("add") => {
                let n: u64 = a.get(1).and_then(|s| s.parse().ok()).ok_or("usage: /time add <ticks>")?;
                ctx.clock.day_time += n;
                Ok(vec![format!("Time is now {}", ctx.clock.time_of_day())])
            }
            Some("query") | None => Ok(vec![format!("day {} · time {} · moon phase {}", ctx.clock.day_number(), ctx.clock.time_of_day(), ctx.clock.moon_phase())]),
            Some(x) => Err(format!("unknown /time option '{x}'")),
        },
        "weather" => {
            let secs: i32 = a.get(1).and_then(|s| s.parse().ok()).unwrap_or(300);
            match a.first().copied() {
                Some("clear") => ctx.weather.set_clear(secs * 20),
                Some("rain") => ctx.weather.set_rain(secs * 20),
                Some("thunder") => ctx.weather.set_thunder(secs * 20),
                _ => return Err("usage: /weather <clear|rain|thunder> [seconds]".into()),
            }
            Ok(vec!["Weather changed".into()])
        }
        "tp" | "teleport" => {
            if a.len() < 3 {
                return Err("usage: /tp <x> <y> <z>".into());
            }
            let p = ctx.player.pos;
            let (x, y, z) = (coord(a[0], p.x)?, coord(a[1], p.y)?, coord(a[2], p.z)?);
            if !(-64.0..=320.0).contains(&y) {
                return Err("y must be between -64 and 320".into());
            }
            ctx.player.pos = Vec3::new(x, y, z);
            ctx.player.prev_pos = ctx.player.pos;
            ctx.player.vel = Vec3::ZERO;
            ctx.player.fall_distance = 0.0;
            Ok(vec![format!("Teleported to {x:.1} {y:.1} {z:.1}")])
        }
        "give" => {
            let name = a.first().ok_or("usage: /give <item> [count]")?;
            let item = ItemId::from_name(name).ok_or_else(|| format!("unknown item '{name}'"))?;
            let mut n: u32 = a.get(1).and_then(|s| s.parse().ok()).unwrap_or(1).clamp(1, 2304);
            let total = n;
            while n > 0 {
                let c = n.min(item.max_stack() as u32) as u8;
                let rest = ctx.inventory.add(ItemStack::new(item, c));
                if !rest.is_empty() {
                    return Err("inventory full".into());
                }
                n -= c as u32;
            }
            Ok(vec![format!("Gave {total} × {}", item.name())])
        }
        "setblock" => {
            if a.len() < 4 {
                return Err("usage: /setblock <x> <y> <z> <block>".into());
            }
            let p = ctx.player.pos;
            let (x, y, z) = (floor(coord(a[0], p.x)?), floor(coord(a[1], p.y)?), floor(coord(a[2], p.z)?));
            let b = block_arg(a[3])?;
            ctx.world.set_block(x, y, z, b).ok_or("position out of the world or chunk not loaded")?;
            ctx.changed.push(BlockPos::new(x, y, z));
            Ok(vec![format!("Changed block at {x} {y} {z}")])
        }
        "fill" => {
            if a.len() < 7 {
                return Err("usage: /fill x1 y1 z1 x2 y2 z2 <block> [replace <block>]".into());
            }
            let p = ctx.player.pos;
            let c: Vec<i32> = (0..6).map(|i| coord(a[i], [p.x, p.y, p.z][i % 3]).map(floor)).collect::<Result<_, _>>()?;
            let b = block_arg(a[6])?;
            let filter = if a.get(7) == Some(&"replace") { Some(block_arg(a.get(8).ok_or("replace needs a block")?)?) } else { None };
            let (x0, x1, y0, y1, z0, z1) = (c[0].min(c[3]), c[0].max(c[3]), c[1].min(c[4]), c[1].max(c[4]), c[2].min(c[5]), c[2].max(c[5]));
            let volume = (x1 - x0 + 1) as i64 * (y1 - y0 + 1) as i64 * (z1 - z0 + 1) as i64;
            if volume > 32_768 {
                return Err(format!("too many blocks ({volume} > 32768)"));
            }
            let mut n = 0;
            for x in x0..=x1 {
                for y in y0..=y1 {
                    for z in z0..=z1 {
                        if filter.is_none_or(|f| ctx.world.get_block(x, y, z) == f) && ctx.world.set_block(x, y, z, b).is_some() {
                            ctx.changed.push(BlockPos::new(x, y, z));
                            n += 1;
                        }
                    }
                }
            }
            Ok(vec![format!("{n} blocks filled")])
        }
        "effect" => match a.first().copied() {
            Some("give") => {
                let name = a.get(1).ok_or("usage: /effect give <effect> [seconds] [level]")?;
                let e = Effect::ALL.iter().copied().find(|e| e.name() == name.trim_start_matches("minecraft:")).ok_or_else(|| format!("unknown effect '{name}'"))?;
                let secs: i32 = a.get(2).and_then(|s| s.parse().ok()).unwrap_or(30);
                let lvl: u8 = a.get(3).and_then(|s| s.parse::<u8>().ok()).unwrap_or(1).saturating_sub(1);
                ctx.effects.add(e, lvl, secs * 20);
                Ok(vec![format!("Applied {} {} for {secs}s", e.name(), lvl + 1)])
            }
            Some("clear") => {
                ctx.effects.clear();
                Ok(vec!["Effects cleared".into()])
            }
            _ => Err("usage: /effect <give|clear> …".into()),
        },
        "xp" => match a.first().copied() {
            Some("add") => {
                let n: i32 = a.get(1).and_then(|s| s.parse().ok()).ok_or("usage: /xp add <points>")?;
                ctx.vitals.add_xp(n);
                Ok(vec![format!("Level {}", ctx.vitals.xp_level)])
            }
            _ => Ok(vec![format!("Level {} (+{} pts)", ctx.vitals.xp_level, ctx.vitals.xp_points)]),
        },
        "kill" => {
            ctx.vitals.health = 0.0;
            ctx.vitals.dead = true;
            Ok(vec!["Ouch. That looked like it hurt.".into()])
        }
        "heal" => {
            ctx.vitals.health = crate::game::MAX_HEALTH;
            Ok(vec!["Healed".into()])
        }
        "feed" => {
            ctx.vitals.food = 20;
            ctx.vitals.saturation = 20.0;
            Ok(vec!["Fed".into()])
        }
        "clear" => {
            ctx.inventory.clear();
            Ok(vec!["Inventory cleared".into()])
        }
        "seed" => Ok(vec![format!("Seed: {}", ctx.world.seed)]),
        "pos" => {
            let p = ctx.player.pos;
            Ok(vec![format!("{:.2} {:.2} {:.2}  yaw {:.1} pitch {:.1}", p.x, p.y, p.z, ctx.player.yaw, ctx.player.pitch)])
        }
        "biome" => {
            let p = ctx.player.pos;
            let (x, y, z) = (floor(p.x), floor(p.y), floor(p.z));
            let c = ctx.world.chunk(BlockPos::new(x, y, z).chunk_pos()).ok_or("chunk not loaded")?;
            let id = c.biome_at((x & 15) as usize, y, (z & 15) as usize);
            Ok(vec![format!("Biome: {}", crate::biome::BiomeId::from_u8(id).name())])
        }
        other => Err(format!("unknown command '/{other}' — try /help")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::Chunk;
    use crate::math::ChunkPos;

    struct Fixture {
        world: World,
        player: Player,
        inv: Inventory,
        vitals: Vitals,
        clock: GameClock,
        weather: Weather,
        mode: GameMode,
        effects: ActiveEffects,
        changed: Vec<BlockPos>,
    }

    impl Fixture {
        fn new() -> Self {
            let mut world = World::new(99);
            world.insert_chunk(Chunk::new(ChunkPos::new(0, 0)));
            Self { world, player: Player::new(Vec3::new(8.0, 70.0, 8.0)), inv: Inventory::default(), vitals: Vitals::default(), clock: GameClock::default(), weather: Weather::new(1), mode: GameMode::Survival, effects: ActiveEffects::default(), changed: vec![] }
        }
        fn run(&mut self, line: &str) -> Result<Vec<String>, String> {
            let mut ctx = CommandContext { world: &mut self.world, player: &mut self.player, inventory: &mut self.inv, vitals: &mut self.vitals, clock: &mut self.clock, weather: &mut self.weather, gamemode: &mut self.mode, effects: &mut self.effects, changed: &mut self.changed };
            execute(&mut ctx, line)
        }
    }

    #[test]
    fn gamemode_time_weather_tp() {
        let mut f = Fixture::new();
        f.run("/gamemode creative").unwrap();
        assert_eq!(f.mode, GameMode::Creative);
        assert!(f.player.can_fly);
        f.run("fly").unwrap();
        assert!(f.player.flying);
        f.run("/time set midnight").unwrap();
        assert_eq!(f.clock.time_of_day(), 18_000);
        f.run("time add 10").unwrap();
        assert_eq!(f.clock.time_of_day(), 18_010);
        f.run("weather thunder 60").unwrap();
        assert!(f.weather.thundering);
        f.run("tp ~ ~10 100").unwrap();
        assert_eq!((f.player.pos.y, f.player.pos.z), (80.0, 100.0));
        assert!(f.run("tp 0 999 0").is_err());
        assert!(f.run("gamemode banana").is_err());
        assert!(f.run("blah").unwrap_err().contains("unknown command"));
    }

    #[test]
    fn give_setblock_fill_effect() {
        let mut f = Fixture::new();
        f.run("give diamond_pickaxe").unwrap();
        f.run("give minecraft:cobblestone 200").unwrap();
        assert_eq!(f.inv.count_of(ItemId::of("cobblestone")), 200);
        assert!(f.run("give nothing").is_err());
        f.run("setblock 1 10 1 stone").unwrap();
        assert_eq!(f.world.get_block(1, 10, 1), BlockId::STONE);
        f.run("fill 0 5 0 3 6 3 oak_planks").unwrap();
        assert_eq!(f.world.get_block(2, 6, 2), BlockId::OAK_PLANKS);
        f.run("fill 0 5 0 3 6 3 glass replace oak_planks").unwrap();
        assert_eq!(f.world.get_block(2, 6, 2), BlockId::GLASS);
        assert!(f.run("fill 0 0 0 100 100 100 stone").unwrap_err().contains("too many"));
        assert!(f.changed.len() >= 32 + 33);
        f.run("effect give speed 60 2").unwrap();
        assert!(f.effects.level(Effect::Speed) == 2);
        f.run("xp add 100").unwrap();
        assert!(f.vitals.xp_level > 3);
        f.run("kill").unwrap();
        assert!(f.vitals.dead);
        assert!(f.run("help").unwrap().len() >= 10);
    }
}
