//! Headless benchmark / self-check for the core.
//!
//! ```text
//! cargo run --release -- [--view N] [--seed S] [--threads T]
//! ```

use blockforge_core::biome::BiomeId;
use blockforge_core::block::{BLOCK_COUNT, TEXTURE_COUNT};
use blockforge_core::chunk::HeightmapKind;
use blockforge_core::item::item_count;
use blockforge_core::mesher::{mesh_section, MeshInput};
use blockforge_core::prelude::*;
use blockforge_core::raycast::raycast_solid;
use blockforge_core::recipe;
use std::collections::BTreeSet;
use std::time::Instant;

fn arg<T: std::str::FromStr>(name: &str, default: T) -> T {
    let args: Vec<String> = std::env::args().collect();
    args.iter().position(|a| a == name).and_then(|i| args.get(i + 1)).and_then(|v| v.parse().ok()).unwrap_or(default)
}

fn main() {
    let view: i32 = arg("--view", 8);
    let seed: i64 = arg("--seed", 1_234_567);
    let threads: usize = arg("--threads", std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2));

    println!("BlockForge Core v{}  |  target Minecraft Java {VERSION_NAME}  (protocol {PROTOCOL_VERSION}, data {DATA_VERSION})", env!("CARGO_PKG_VERSION"));
    println!("seed={seed} view_distance={view} threads={threads}");
    println!(
        "registries: {BLOCK_COUNT} blocks · {TEXTURE_COUNT} textures · {} items · {} crafting + {} smelting recipes · {} biomes · {} mobs · {} effects · {} enchantments\n",
        item_count(),
        recipe::book().crafting.len(),
        recipe::book().smelting.len(),
        BiomeId::ALL.len(),
        blockforge_core::entity::MobKind::ALL.len(),
        blockforge_core::effects::Effect::ALL.len(),
        blockforge_core::effects::Enchantment::ALL.len(),
    );

    // ---- 1. single threaded terrain generation (biomes + caves + ores + trees) ----------
    let gen = WorldGenerator::new(seed);
    let t = Instant::now();
    let n = 64;
    let mut sink = 0u64;
    let mut biomes = BTreeSet::new();
    for i in 0..n {
        let c = gen.generate_chunk(ChunkPos::new(i % 8, i / 8));
        sink += c.height_at(0, 0, HeightmapKind::WorldSurface) as u64;
        biomes.insert(c.biome_at(8, 70, 8));
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[worldgen ] {n} chunks in {:.1} ms  -> {:.1} chunks/s/thread  (sink {sink}, {} biomes in sample)", dt * 1e3, n as f64 / dt, biomes.len());

    // ---- 2. meshing throughput ----------------------------------------------------------
    let mut w = World::new(seed);
    for cx in -1..=8 {
        for cz in -1..=8 {
            w.insert_chunk(gen.generate_chunk(ChunkPos::new(cx, cz)));
        }
    }
    for cx in 0..8 {
        for cz in 0..8 {
            w.relight_chunk(ChunkPos::new(cx, cz));
        }
    }
    let t = Instant::now();
    let (mut sections, mut quads) = (0u64, 0u64);
    for cx in 0..8 {
        for cz in 0..8 {
            let chunk = w.chunk(ChunkPos::new(cx, cz)).unwrap();
            for sy in 0..24 {
                if chunk.sections[sy].is_empty() {
                    continue;
                }
                let m = mesh_section(&MeshInput::from_world(&w, ChunkPos::new(cx, cz), sy));
                sections += 1;
                quads += m.quad_count() as u64;
            }
        }
    }
    let dt = t.elapsed().as_secs_f64();
    println!("[mesher   ] {sections} sections, {quads} quads in {:.1} ms  -> {:.0} sections/s", dt * 1e3, sections as f64 / dt);

    // ---- 3. raycast + physics -----------------------------------------------------------
    let t = Instant::now();
    let mut hits = 0;
    for i in 0..20_000 {
        let o = Vec3::new(8.0 + (i % 100) as f64 * 0.5, 200.0, 8.0 + (i / 100) as f64 * 0.5);
        if raycast_solid(&w, o, Vec3::new(0.0, -1.0, 0.0), 200.0).is_some() {
            hits += 1;
        }
    }
    println!("[raycast  ] 20000 rays in {:.1} ms ({hits} hits)", t.elapsed().as_secs_f64() * 1e3);
    let spawn_y = w.height_at(40, 40, HeightmapKind::WorldSurface).unwrap() as f64 + 1.0;
    let mut p = Player::new(Vec3::new(40.5, spawn_y + 20.0, 40.5));
    for _ in 0..200 {
        p.tick(&w, Input { forward: 1.0, sprint: true, ..Default::default() });
    }
    println!("[physics  ] 200 sprint ticks -> pos ({:.2}, {:.2}, {:.2}) on_ground={}", p.pos.x, p.pos.y, p.pos.z, p.on_ground);

    // ---- 4. full threaded pipeline + world simulation ------------------------------------
    let mut m = blockforge_core::manager::ChunkManager::new(seed, threads);
    let t = Instant::now();
    let centre = ChunkPos::new(0, 0);
    while !(m.is_idle() && m.world.loaded_count() as i32 >= (view * 2) * (view * 2) / 2) {
        m.update(centre, view);
        std::thread::sleep(std::time::Duration::from_millis(1));
    }
    println!(
        "[pipeline ] view {view}: {} chunks, {} sections meshed, {} quads, {:.1} MiB meshes in {:.0} ms",
        m.stats.chunks_generated, m.stats.sections_meshed, m.stats.quads, m.mesh_bytes() as f64 / 1048576.0, t.elapsed().as_secs_f64() * 1e3
    );
    let top = m.world.height_at(0, 0, HeightmapKind::WorldSurface).unwrap();
    m.set_block(0, top + 6, 0, BlockId::WATER);
    let t = Instant::now();
    let changes: usize = (0..100).map(|_| m.tick_world(centre, 4)).sum();
    println!("[simulate ] 100 ticks (water poured from the sky + random ticks): {changes} block changes in {:.1} ms", t.elapsed().as_secs_f64() * 1e3);

    // ---- 5. persistence --------------------------------------------------------------------
    let c = gen.generate_chunk(ChunkPos::new(3, 3));
    let bytes = blockforge_core::save::serialize_chunk(&c);
    println!("[save     ] one chunk = {} bytes, reload ok = {}", bytes.len(), blockforge_core::save::deserialize_chunk(&bytes).is_ok());
    println!("\nOK");
}
