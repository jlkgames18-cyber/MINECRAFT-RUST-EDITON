//! Math primitives: vectors, block / chunk positions and AABBs.
//!
//! Conventions follow the vanilla Java Edition:
//! * +X = east, +Y = up, +Z = south
//! * a `BlockPos` packs into an `i64` as `x:26 | z:26 | y:12`
//! * a `ChunkPos` packs into an `i64` as `x:32 | z:32`

use std::ops::{Add, AddAssign, Mul, Neg, Sub};

pub const CHUNK_SIZE: i32 = 16;
pub const SECTION_HEIGHT: i32 = 16;
pub const MIN_Y: i32 = -64;
pub const MAX_Y: i32 = 320; // exclusive
pub const WORLD_HEIGHT: i32 = MAX_Y - MIN_Y; // 384
pub const SECTION_COUNT: usize = (WORLD_HEIGHT / SECTION_HEIGHT) as usize; // 24

#[derive(Clone, Copy, Debug, PartialEq, Default)]
pub struct Vec3 {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl Vec3 {
    pub const ZERO: Vec3 = Vec3 { x: 0.0, y: 0.0, z: 0.0 };

    #[inline]
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        Self { x, y, z }
    }
    #[inline]
    pub fn length_sqr(self) -> f64 {
        self.x * self.x + self.y * self.y + self.z * self.z
    }
    #[inline]
    pub fn length(self) -> f64 {
        self.length_sqr().sqrt()
    }
    #[inline]
    pub fn horizontal_distance_sqr(self) -> f64 {
        self.x * self.x + self.z * self.z
    }
    #[inline]
    pub fn normalize(self) -> Vec3 {
        let l = self.length();
        if l < 1.0e-5 {
            Vec3::ZERO
        } else {
            Vec3::new(self.x / l, self.y / l, self.z / l)
        }
    }
    #[inline]
    pub fn dot(self, o: Vec3) -> f64 {
        self.x * o.x + self.y * o.y + self.z * o.z
    }
    /// Direction vector from yaw / pitch in degrees (vanilla `Entity.calculateViewVector`).
    pub fn from_rotation(pitch_deg: f32, yaw_deg: f32) -> Vec3 {
        let p = pitch_deg.to_radians();
        let y = (-yaw_deg).to_radians();
        let (sy, cy) = y.sin_cos();
        let (sp, cp) = p.sin_cos();
        Vec3::new((sy * cp) as f64, (-sp) as f64, (cy * cp) as f64)
    }
}

impl Add for Vec3 {
    type Output = Vec3;
    #[inline]
    fn add(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x + o.x, self.y + o.y, self.z + o.z)
    }
}
impl AddAssign for Vec3 {
    #[inline]
    fn add_assign(&mut self, o: Vec3) {
        self.x += o.x;
        self.y += o.y;
        self.z += o.z;
    }
}
impl Sub for Vec3 {
    type Output = Vec3;
    #[inline]
    fn sub(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x - o.x, self.y - o.y, self.z - o.z)
    }
}
impl Mul<f64> for Vec3 {
    type Output = Vec3;
    #[inline]
    fn mul(self, s: f64) -> Vec3 {
        Vec3::new(self.x * s, self.y * s, self.z * s)
    }
}
impl Neg for Vec3 {
    type Output = Vec3;
    #[inline]
    fn neg(self) -> Vec3 {
        Vec3::new(-self.x, -self.y, -self.z)
    }
}

/// Vanilla `Mth.floor` for f64.
#[inline]
pub fn floor(v: f64) -> i32 {
    let i = v as i32;
    if v < i as f64 {
        i - 1
    } else {
        i
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default)]
pub struct BlockPos {
    pub x: i32,
    pub y: i32,
    pub z: i32,
}

impl BlockPos {
    #[inline]
    pub const fn new(x: i32, y: i32, z: i32) -> Self {
        Self { x, y, z }
    }
    #[inline]
    pub fn from_vec3(v: Vec3) -> Self {
        Self::new(floor(v.x), floor(v.y), floor(v.z))
    }
    #[inline]
    pub fn chunk_pos(self) -> ChunkPos {
        ChunkPos::new(self.x >> 4, self.z >> 4)
    }
    #[inline]
    pub fn offset(self, dx: i32, dy: i32, dz: i32) -> BlockPos {
        BlockPos::new(self.x + dx, self.y + dy, self.z + dz)
    }
    #[inline]
    pub fn relative(self, f: Face) -> BlockPos {
        let (dx, dy, dz) = f.offset();
        self.offset(dx, dy, dz)
    }
    /// Network encoding (`Position` type).
    #[inline]
    pub fn pack(self) -> i64 {
        (((self.x as i64) & 0x3FF_FFFF) << 38)
            | (((self.z as i64) & 0x3FF_FFFF) << 12)
            | ((self.y as i64) & 0xFFF)
    }
    #[inline]
    pub fn unpack(v: i64) -> BlockPos {
        BlockPos::new((v >> 38) as i32, ((v << 52) >> 52) as i32, ((v << 26) >> 38) as i32)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default, PartialOrd, Ord)]
pub struct ChunkPos {
    pub x: i32,
    pub z: i32,
}

impl ChunkPos {
    #[inline]
    pub const fn new(x: i32, z: i32) -> Self {
        Self { x, z }
    }
    #[inline]
    pub fn pack(self) -> i64 {
        (self.x as u32 as i64) | ((self.z as u32 as i64) << 32)
    }
    #[inline]
    pub fn unpack(v: i64) -> ChunkPos {
        ChunkPos::new(v as i32, (v >> 32) as i32)
    }
    #[inline]
    pub fn min_block_x(self) -> i32 {
        self.x << 4
    }
    #[inline]
    pub fn min_block_z(self) -> i32 {
        self.z << 4
    }
    #[inline]
    pub fn chebyshev_distance(self, o: ChunkPos) -> i32 {
        (self.x - o.x).abs().max((self.z - o.z).abs())
    }
}

/// Same order as vanilla `Direction` (by 3D data value).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(u8)]
pub enum Face {
    Down = 0,
    Up = 1,
    North = 2, // -Z
    South = 3, // +Z
    West = 4,  // -X
    East = 5,  // +X
}

impl Face {
    pub const ALL: [Face; 6] = [Face::Down, Face::Up, Face::North, Face::South, Face::West, Face::East];

    #[inline]
    pub const fn offset(self) -> (i32, i32, i32) {
        match self {
            Face::Down => (0, -1, 0),
            Face::Up => (0, 1, 0),
            Face::North => (0, 0, -1),
            Face::South => (0, 0, 1),
            Face::West => (-1, 0, 0),
            Face::East => (1, 0, 0),
        }
    }
    #[inline]
    pub const fn opposite(self) -> Face {
        match self {
            Face::Down => Face::Up,
            Face::Up => Face::Down,
            Face::North => Face::South,
            Face::South => Face::North,
            Face::West => Face::East,
            Face::East => Face::West,
        }
    }
    #[inline]
    pub const fn index(self) -> usize {
        self as usize
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Aabb {
    pub min: Vec3,
    pub max: Vec3,
}

const COLLIDE_EPS: f64 = 1.0e-7;

impl Aabb {
    #[inline]
    pub fn new(min: Vec3, max: Vec3) -> Self {
        Self { min, max }
    }
    /// Entity box centred on the feet position (like `EntityDimensions.makeBoundingBox`).
    pub fn from_feet(pos: Vec3, width: f64, height: f64) -> Self {
        let h = width / 2.0;
        Self::new(Vec3::new(pos.x - h, pos.y, pos.z - h), Vec3::new(pos.x + h, pos.y + height, pos.z + h))
    }
    #[inline]
    pub fn unit_block(x: i32, y: i32, z: i32) -> Self {
        Self::new(
            Vec3::new(x as f64, y as f64, z as f64),
            Vec3::new((x + 1) as f64, (y + 1) as f64, (z + 1) as f64),
        )
    }
    #[inline]
    pub fn offset(&self, d: Vec3) -> Aabb {
        Aabb::new(self.min + d, self.max + d)
    }
    #[inline]
    pub fn inflate(&self, v: f64) -> Aabb {
        Aabb::new(
            Vec3::new(self.min.x - v, self.min.y - v, self.min.z - v),
            Vec3::new(self.max.x + v, self.max.y + v, self.max.z + v),
        )
    }
    /// Grows the box in the direction of the motion vector (vanilla `expandTowards`).
    pub fn expand_towards(&self, d: Vec3) -> Aabb {
        let mut a = *self;
        if d.x < 0.0 { a.min.x += d.x } else { a.max.x += d.x }
        if d.y < 0.0 { a.min.y += d.y } else { a.max.y += d.y }
        if d.z < 0.0 { a.min.z += d.z } else { a.max.z += d.z }
        a
    }
    #[inline]
    pub fn intersects(&self, o: &Aabb) -> bool {
        self.min.x < o.max.x
            && self.max.x > o.min.x
            && self.min.y < o.max.y
            && self.max.y > o.min.y
            && self.min.z < o.max.z
            && self.max.z > o.min.z
    }

    /// Clips motion `d` on the X axis against `self` as an obstacle for the moving box `o`.
    #[inline]
    pub fn collide_x(&self, o: &Aabb, mut d: f64) -> f64 {
        if o.max.y > self.min.y && o.min.y < self.max.y && o.max.z > self.min.z && o.min.z < self.max.z {
            if d > 0.0 && o.max.x <= self.min.x + COLLIDE_EPS {
                d = d.min(self.min.x - o.max.x);
            } else if d < 0.0 && o.min.x >= self.max.x - COLLIDE_EPS {
                d = d.max(self.max.x - o.min.x);
            }
        }
        d
    }
    #[inline]
    pub fn collide_y(&self, o: &Aabb, mut d: f64) -> f64 {
        if o.max.x > self.min.x && o.min.x < self.max.x && o.max.z > self.min.z && o.min.z < self.max.z {
            if d > 0.0 && o.max.y <= self.min.y + COLLIDE_EPS {
                d = d.min(self.min.y - o.max.y);
            } else if d < 0.0 && o.min.y >= self.max.y - COLLIDE_EPS {
                d = d.max(self.max.y - o.min.y);
            }
        }
        d
    }
    #[inline]
    pub fn collide_z(&self, o: &Aabb, mut d: f64) -> f64 {
        if o.max.x > self.min.x && o.min.x < self.max.x && o.max.y > self.min.y && o.min.y < self.max.y {
            if d > 0.0 && o.max.z <= self.min.z + COLLIDE_EPS {
                d = d.min(self.min.z - o.max.z);
            } else if d < 0.0 && o.min.z >= self.max.z - COLLIDE_EPS {
                d = d.max(self.max.z - o.min.z);
            }
        }
        d
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn block_pos_pack_roundtrip() {
        for &(x, y, z) in &[(0, 0, 0), (-1, -64, -1), (29_999_999, 319, -29_999_999), (-30_000_000, 100, 12345)] {
            let p = BlockPos::new(x, y, z);
            assert_eq!(BlockPos::unpack(p.pack()), p);
        }
    }

    #[test]
    fn chunk_pos_pack_roundtrip() {
        for &(x, z) in &[(0, 0), (-1, -1), (1875000, -1875000), (-5, 7)] {
            let p = ChunkPos::new(x, z);
            assert_eq!(ChunkPos::unpack(p.pack()), p);
        }
    }

    #[test]
    fn floor_matches_vanilla() {
        assert_eq!(floor(-0.5), -1);
        assert_eq!(floor(0.5), 0);
        assert_eq!(floor(-1.0), -1);
        assert_eq!(floor(2.9999), 2);
    }

    #[test]
    fn aabb_collision_axis() {
        let floor_box = Aabb::unit_block(0, 0, 0);
        let player = Aabb::from_feet(Vec3::new(0.5, 1.5, 0.5), 0.6, 1.8);
        let d = floor_box.collide_y(&player, -2.0);
        assert!((d + 0.5).abs() < 1e-9);
    }
}
