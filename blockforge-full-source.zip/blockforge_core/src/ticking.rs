//! World simulation that runs at 20 TPS: **fluids**, **falling blocks** and **random ticks**.
//!
//! * water (7 blocks, 5-tick delay) and lava (3 blocks, 30-tick delay) with sources, falling
//!   columns, infinite water, drain-on-source-removal and obsidian / cobblestone generation
//! * sand, gravel, concrete powder and anvils fall as entities and land (or break) like vanilla
//! * random ticks (3 per section per tick): grass spread / death, leaf decay, saplings → trees,
//!   sugar cane / cactus / bamboo / kelp growth, ice melting

use crate::block::{flags, BlockId};
use crate::math::{floor, BlockPos, ChunkPos, Face, MIN_Y, SECTION_COUNT};
use crate::rng::{JavaRandom, RandomSource};
use crate::trees::{self, TreeKind};
use crate::world::{FxHashMap, World};
use std::collections::{HashSet, VecDeque};

const FALLING: u8 = 8;
const HORIZONTAL: [Face; 4] = [Face::North, Face::South, Face::West, Face::East];

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
enum Job {
    Fluid,
    Gravity,
}

#[derive(Clone, Copy, Debug)]
pub struct FallingBlock {
    pub x: i32,
    pub z: i32,
    pub y: f64,
    pub vy: f64,
    pub block: BlockId,
}

pub struct WorldTicker {
    levels: FxHashMap<i64, u8>,
    pending: VecDeque<(u64, BlockPos, Job)>,
    queued: HashSet<(i64, Job)>,
    pub falling: Vec<FallingBlock>,
    rng: JavaRandom,
    now: u64,
    changed: Vec<BlockPos>,
    /// Number of random ticks per section per tick (vanilla `randomTickSpeed` = 3).
    pub random_tick_speed: u32,
}

impl WorldTicker {
    pub fn new(seed: i64) -> Self {
        Self {
            levels: FxHashMap::default(),
            pending: VecDeque::new(),
            queued: HashSet::new(),
            falling: Vec::new(),
            rng: JavaRandom::new(seed ^ 0x71C4),
            now: 0,
            changed: Vec::new(),
            random_tick_speed: 3,
        }
    }

    /// Fluid level of a position: `Some(0)` source, `1..=7` flowing, `8` falling, `None` no fluid.
    pub fn fluid_level(&self, world: &World, p: BlockPos) -> Option<u8> {
        world.get_block_pos(p).is_liquid().then(|| self.levels.get(&p.pack()).copied().unwrap_or(0))
    }

    pub fn pending_jobs(&self) -> usize {
        self.pending.len() + self.falling.len()
    }

    fn schedule(&mut self, p: BlockPos, job: Job, delay: u64) {
        if self.queued.insert((p.pack(), job)) {
            self.pending.push_back((self.now + delay, p, job));
        }
    }

    /// Must be called whenever a block changes (player edit, worldgen patch, …).
    pub fn notify(&mut self, world: &World, p: BlockPos) {
        if !world.get_block_pos(p).is_liquid() {
            self.levels.remove(&p.pack());
        }
        let mut targets = vec![p];
        targets.extend(Face::ALL.iter().map(|&f| p.relative(f)));
        for t in targets {
            let b = world.get_block_pos(t);
            if b.is_liquid() {
                self.schedule(t, Job::Fluid, if b.is_lava() { 30 } else { 5 });
            } else if b.is_replaceable() {
                // an empty cell next to a fluid: let the fluid re-evaluate
                for f in Face::ALL {
                    let n = t.relative(f);
                    if world.get_block_pos(n).is_liquid() {
                        let d = if world.get_block_pos(n).is_lava() { 30 } else { 5 };
                        self.schedule(n, Job::Fluid, d);
                    }
                }
            }
            if b.is_gravity() {
                self.schedule(t, Job::Gravity, 2);
            }
        }
    }

    fn put(&mut self, world: &mut World, p: BlockPos, id: BlockId) {
        if world.set_block(p.x, p.y, p.z, id).is_some() {
            self.changed.push(p);
            self.notify(world, p);
        }
    }

    /// Advances the simulation by one tick. Returns every block position that changed.
    pub fn tick(&mut self, world: &mut World, active_chunks: &[ChunkPos]) -> Vec<BlockPos> {
        self.now += 1;
        // scheduled jobs
        let due = self.pending.iter().take_while(|(t, _, _)| *t <= self.now).count();
        for _ in 0..due.min(4096) {
            let (_, p, job) = self.pending.pop_front().unwrap();
            self.queued.remove(&(p.pack(), job));
            match job {
                Job::Fluid => self.process_fluid(world, p),
                Job::Gravity => self.process_gravity(world, p),
            }
        }
        self.tick_falling(world);
        for &cp in active_chunks {
            self.random_ticks(world, cp);
        }
        std::mem::take(&mut self.changed)
    }

    // ---------------------------------------------------------------- fluids
    fn process_fluid(&mut self, world: &mut World, p: BlockPos) {
        let b = world.get_block_pos(p);
        if !b.is_liquid() {
            self.levels.remove(&p.pack());
            return;
        }
        let water = b.is_water();
        let (drop, max) = if water { (1u8, 7u8) } else { (2u8, 6u8) };
        let cur = self.levels.get(&p.pack()).copied().unwrap_or(0);
        let is_source = cur == 0 && !self.levels.contains_key(&p.pack());

        // --- lava meets water -------------------------------------------------------------
        if !water {
            let touches_water = [Face::Up, Face::North, Face::South, Face::West, Face::East]
                .iter()
                .any(|&f| world.get_block_pos(p.relative(f)).is_water());
            if touches_water {
                self.levels.remove(&p.pack());
                self.put(world, p, if is_source { BlockId::OBSIDIAN } else { BlockId::COBBLESTONE });
                return;
            }
        }

        // --- is the cell still fed? -------------------------------------------------------
        if !is_source {
            let above_same = world.get_block_pos(p.relative(Face::Up)) == b;
            let mut best: Option<u8> = None;
            for f in HORIZONTAL {
                let n = p.relative(f);
                if world.get_block_pos(n) == b {
                    let nl = self.levels.get(&n.pack()).copied();
                    let strength = match nl {
                        None => 0,
                        Some(FALLING) => {
                            // falling water only feeds sideways once it has landed on something
                            if world.get_block_pos(n.relative(Face::Down)).is_replaceable() { continue } else { 0 }
                        }
                        Some(l) => l,
                    };
                    let cand = strength + drop;
                    if cand <= max && best.is_none_or(|x| cand < x) {
                        best = Some(cand);
                    }
                }
            }
            let new = if above_same { Some(FALLING) } else { best };
            match new {
                None => {
                    self.levels.remove(&p.pack());
                    self.put(world, p, BlockId::AIR);
                    return;
                }
                Some(l) if l != cur => {
                    // level changed (e.g. receding flow): re-evaluate this cell and the neighbours
                    self.levels.insert(p.pack(), l);
                    let d = if water { 5 } else { 30 };
                    self.schedule(p, Job::Fluid, d);
                    for f in HORIZONTAL {
                        let n = p.relative(f);
                        if world.get_block_pos(n) == b {
                            self.schedule(n, Job::Fluid, d);
                        }
                    }
                    return;
                }
                _ => {}
            }
            // infinite water: two adjacent sources and something solid / source below
            if water && !above_same {
                let sources = HORIZONTAL
                    .iter()
                    .filter(|&&f| {
                        let n = p.relative(f);
                        world.get_block_pos(n).is_water() && !self.levels.contains_key(&n.pack())
                    })
                    .count();
                let below = world.get_block_pos(p.relative(Face::Down));
                let below_ok = below.is_solid() || (below.is_water() && !self.levels.contains_key(&p.relative(Face::Down).pack()));
                if sources >= 2 && below_ok {
                    self.levels.remove(&p.pack());
                    self.notify(world, p);
                    return;
                }
            }
        }
        let cur = self.levels.get(&p.pack()).copied().unwrap_or(0);

        // --- flow down ---------------------------------------------------------------------
        let down = p.relative(Face::Down);
        let below = world.get_block_pos(down);
        if p.y > MIN_Y {
            if !water && below.is_water() {
                self.put(world, down, BlockId::STONE);
                return;
            }
            if water && below.is_lava() {
                let src = !self.levels.contains_key(&down.pack());
                self.levels.remove(&down.pack());
                self.put(world, down, if src { BlockId::OBSIDIAN } else { BlockId::COBBLESTONE });
                return;
            }
            if below.is_replaceable() && !below.is_liquid() {
                self.levels.insert(down.pack(), FALLING);
                self.put(world, down, b);
                return;
            }
            if below == b {
                // keep the column falling; no sideways spread above an unfinished column
                if self.levels.get(&down.pack()).is_some_and(|&l| l != 0) || below.is_liquid() {
                    return;
                }
            }
        }

        // --- spread sideways ---------------------------------------------------------------
        let next = if cur >= FALLING { drop } else { cur + drop };
        if next > max {
            return;
        }
        for f in HORIZONTAL {
            let n = p.relative(f);
            let nb = world.get_block_pos(n);
            if nb == b {
                if self.levels.get(&n.pack()).is_some_and(|&l| l != FALLING && l > next) {
                    self.levels.insert(n.pack(), next);
                    self.schedule(n, Job::Fluid, if water { 5 } else { 30 });
                }
            } else if nb.is_replaceable() && !nb.is_liquid() {
                self.levels.insert(n.pack(), next);
                self.put(world, n, b);
            } else if nb.is_liquid() && !water {
                // lava spreading into water handled from the lava side next tick
                self.schedule(n, Job::Fluid, 5);
            }
        }
    }

    // ---------------------------------------------------------------- gravity
    fn process_gravity(&mut self, world: &mut World, p: BlockPos) {
        let b = world.get_block_pos(p);
        if !b.is_gravity() || p.y <= MIN_Y {
            return;
        }
        let below = world.get_block_pos(p.relative(Face::Down));
        if below.is_replaceable() {
            self.put(world, p, BlockId::AIR);
            self.falling.push(FallingBlock { x: p.x, z: p.z, y: p.y as f64, vy: 0.0, block: b });
        }
    }

    fn tick_falling(&mut self, world: &mut World) {
        let mut i = 0;
        while i < self.falling.len() {
            let mut f = self.falling[i];
            f.vy = (f.vy - 0.04) * 0.98;
            let new_y = f.y + f.vy;
            let (cur_cell, target_cell) = (floor(f.y), floor(new_y));
            let mut land = None;
            for cy in (target_cell..=cur_cell).rev() {
                if !world.get_block(f.x, cy - 1, f.z).is_replaceable() {
                    land = Some(cy);
                    break;
                }
            }
            if let Some(cy) = land {
                let p = BlockPos::new(f.x, cy, f.z);
                if world.get_block_pos(p).is_replaceable() {
                    self.put(world, p, f.block);
                }
                self.falling.swap_remove(i);
                continue;
            }
            if new_y < MIN_Y as f64 {
                self.falling.swap_remove(i);
                continue;
            }
            f.y = new_y;
            self.falling[i] = f;
            i += 1;
        }
    }

    // ---------------------------------------------------------------- random ticks
    fn random_ticks(&mut self, world: &mut World, cp: ChunkPos) {
        let Some(chunk) = world.chunk(cp) else { return };
        let mut picks: Vec<BlockPos> = Vec::new();
        for si in 0..SECTION_COUNT {
            if chunk.sections[si].is_empty() {
                continue;
            }
            for _ in 0..self.random_tick_speed {
                let lx = self.rng.next_i32_bounded(16);
                let lz = self.rng.next_i32_bounded(16);
                let ly = self.rng.next_i32_bounded(16);
                let pos = BlockPos::new(cp.min_block_x() + lx, MIN_Y + si as i32 * 16 + ly, cp.min_block_z() + lz);
                if chunk.get_block(lx as usize, pos.y, lz as usize).has(flags::RANDOM_TICK) {
                    picks.push(pos);
                }
            }
        }
        for p in picks {
            self.random_tick_block(world, p);
        }
    }

    fn column_height_of(&self, world: &World, p: BlockPos, same: BlockId) -> i32 {
        let mut n = 1;
        while world.get_block(p.x, p.y - n, p.z) == same {
            n += 1;
        }
        n
    }

    pub fn random_tick_block(&mut self, world: &mut World, p: BlockPos) {
        let b = world.get_block_pos(p);
        let above = world.get_block(p.x, p.y + 1, p.z);
        match b {
            BlockId::GRASS_BLOCK | BlockId::MYCELIUM | BlockId::PODZOL => {
                if above.is_opaque() || above.is_liquid() {
                    self.put(world, p, BlockId::DIRT);
                } else if b != BlockId::PODZOL && world.sky_light(p.x, p.y + 1, p.z).max(world.block_light(p.x, p.y + 1, p.z)) >= 9 {
                    let t = BlockPos::new(
                        p.x + self.rng.next_i32_bounded(3) - 1,
                        p.y + self.rng.next_i32_bounded(5) - 3,
                        p.z + self.rng.next_i32_bounded(3) - 1,
                    );
                    if world.get_block_pos(t) == BlockId::DIRT {
                        let ta = world.get_block(t.x, t.y + 1, t.z);
                        if !ta.is_opaque() && !ta.is_liquid() && world.sky_light(t.x, t.y + 1, t.z).max(world.block_light(t.x, t.y + 1, t.z)) >= 4 {
                            self.put(world, t, b);
                        }
                    }
                }
            }
            BlockId::ICE => {
                if world.block_light(p.x, p.y, p.z) > 11 {
                    self.put(world, p, BlockId::WATER);
                }
            }
            BlockId::SUGAR_CANE | BlockId::CACTUS | BlockId::BAMBOO | BlockId::KELP => {
                let max = match b { BlockId::BAMBOO => 12, BlockId::KELP => 16, _ => 3 };
                let h = self.column_height_of(world, p, b);
                let free = if b == BlockId::KELP { above == BlockId::WATER } else { above.is_air() };
                if h < max && free && self.rng.next_i32_bounded(8) == 0 {
                    self.put(world, BlockPos::new(p.x, p.y + 1, p.z), b);
                }
            }
            _ if b.name().ends_with("_sapling") => {
                if self.rng.next_i32_bounded(7) != 0 {
                    return;
                }
                let kind = match b.short_name() {
                    "spruce_sapling" => TreeKind::Spruce,
                    "birch_sapling" => TreeKind::Birch,
                    "jungle_sapling" => TreeKind::Jungle,
                    "acacia_sapling" => TreeKind::Acacia,
                    "dark_oak_sapling" => TreeKind::DarkOak,
                    "mangrove_sapling" => TreeKind::Mangrove,
                    "cherry_sapling" => TreeKind::Cherry,
                    _ => if self.rng.next_i32_bounded(10) == 0 { TreeKind::BigOak } else { TreeKind::Oak },
                };
                if !trees::soil_ok(kind, world.get_block(p.x, p.y - 1, p.z)) {
                    return;
                }
                self.put(world, p, BlockId::AIR);
                let mut r = JavaRandom::new(self.rng.next_i64());
                let before = world.get_block(p.x, p.y + 1, p.z);
                trees::grow(world, kind, p.x, p.y - 1, p.z, &mut r);
                let _ = before;
                for dx in -4..=4 {
                    for dz in -4..=4 {
                        for dy in 0..20 {
                            self.changed.push(BlockPos::new(p.x + dx, p.y + dy, p.z + dz));
                        }
                    }
                }
            }
            _ if b.is_leaves() => {
                if !self.leaf_supported(world, p) {
                    self.put(world, p, BlockId::AIR);
                }
            }
            _ => {}
        }
    }

    /// Leaves survive when a log is within 6 blocks through connected leaves / logs.
    fn leaf_supported(&self, world: &World, start: BlockPos) -> bool {
        let mut seen: HashSet<i64> = HashSet::new();
        let mut q: VecDeque<(BlockPos, u8)> = VecDeque::new();
        q.push_back((start, 0));
        seen.insert(start.pack());
        while let Some((p, d)) = q.pop_front() {
            for f in Face::ALL {
                let n = p.relative(f);
                if !world.is_loaded(n.chunk_pos()) {
                    return true; // never decay next to unloaded terrain
                }
                if !seen.insert(n.pack()) {
                    continue;
                }
                let b = world.get_block_pos(n);
                if b.is_log() {
                    return true;
                }
                if b.is_leaves() && d + 1 < 6 {
                    q.push_back((n, d + 1));
                }
            }
        }
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::Chunk;

    fn world() -> World {
        let mut w = World::new(1);
        for cx in -2..=2 {
            for cz in -2..=2 {
                let mut c = Chunk::new(ChunkPos::new(cx, cz));
                for x in 0..16 {
                    for z in 0..16 {
                        for y in -64..=59 {
                            c.set_block(x, y, z, BlockId::STONE);
                        }
                        c.set_block(x, 60, z, BlockId::GRASS_BLOCK);
                    }
                }
                c.rebuild_heightmaps();
                w.insert_chunk(c);
            }
        }
        w
    }
    fn run(t: &mut WorldTicker, w: &mut World, n: usize) {
        for _ in 0..n {
            t.tick(w, &[]);
        }
    }

    #[test]
    fn sand_falls_and_lands() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        w.set_block(3, 70, 3, BlockId::SAND);
        t.notify(&w, BlockPos::new(3, 70, 3));
        run(&mut t, &mut w, 60);
        assert_eq!(w.get_block(3, 70, 3), BlockId::AIR);
        assert_eq!(w.get_block(3, 61, 3), BlockId::SAND);
        assert!(t.falling.is_empty());
    }

    #[test]
    fn water_flows_down_and_spreads_seven_blocks() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        w.set_block(0, 62, 0, BlockId::WATER);
        t.notify(&w, BlockPos::new(0, 62, 0));
        run(&mut t, &mut w, 200);
        // source spreads on the grass floor at y=61 (one above y=60 grass): it sits at y=62 on air
        assert_eq!(w.get_block(0, 61, 0), BlockId::WATER); // fell one block
        assert_eq!(w.get_block(7, 61, 0), BlockId::WATER);
        assert_eq!(w.get_block(8, 61, 0), BlockId::AIR);
    }

    #[test]
    fn removing_the_source_drains_the_flow() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        w.set_block(0, 61, 0, BlockId::WATER);
        t.notify(&w, BlockPos::new(0, 61, 0));
        run(&mut t, &mut w, 100);
        assert_eq!(w.get_block(3, 61, 0), BlockId::WATER);
        w.set_block(0, 61, 0, BlockId::AIR);
        t.notify(&w, BlockPos::new(0, 61, 0));
        run(&mut t, &mut w, 200);
        assert_eq!(w.get_block(3, 61, 0), BlockId::AIR);
        assert_eq!(w.get_block(1, 61, 0), BlockId::AIR);
    }

    #[test]
    fn lava_and_water_make_obsidian_and_cobblestone() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        w.set_block(0, 61, 0, BlockId::LAVA);
        w.set_block(1, 61, 0, BlockId::WATER);
        t.notify(&w, BlockPos::new(0, 61, 0));
        run(&mut t, &mut w, 80);
        assert_eq!(w.get_block(0, 61, 0), BlockId::OBSIDIAN);
    }

    #[test]
    fn infinite_water_source_forms() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        // a pool: ring of stone with two sources and a hole between
        for (x, z) in [(0, 0), (2, 0)] {
            w.set_block(x, 61, z, BlockId::WATER);
        }
        for (x, z) in [(1, 1), (1, -1), (-1, 0), (3, 0)] {
            w.set_block(x, 61, z, BlockId::STONE);
        }
        t.notify(&w, BlockPos::new(0, 61, 0));
        t.notify(&w, BlockPos::new(2, 61, 0));
        run(&mut t, &mut w, 100);
        assert!(w.get_block(1, 61, 0).is_water());
        assert_eq!(t.fluid_level(&w, BlockPos::new(1, 61, 0)), Some(0), "middle cell should have become a source");
    }

    #[test]
    fn grass_dies_under_blocks_and_ice_melts_next_to_light() {
        let mut w = world();
        let mut t = WorldTicker::new(1);
        w.set_block(5, 61, 5, BlockId::STONE);
        t.random_tick_block(&mut w, BlockPos::new(5, 60, 5));
        assert_eq!(w.get_block(5, 60, 5), BlockId::DIRT);
        w.set_block(9, 61, 9, BlockId::ICE);
        t.random_tick_block(&mut w, BlockPos::new(9, 61, 9));
        assert_eq!(w.get_block(9, 61, 9), BlockId::ICE); // no light source → stays
    }

    #[test]
    fn sapling_grows_into_a_tree_and_unsupported_leaves_decay() {
        let mut w = world();
        let mut t = WorldTicker::new(3);
        w.set_block(4, 61, 4, BlockId::OAK_SAPLING);
        for _ in 0..400 {
            if w.get_block(4, 61, 4) != BlockId::OAK_SAPLING {
                break;
            }
            t.random_tick_block(&mut w, BlockPos::new(4, 61, 4));
        }
        assert_eq!(w.get_block(4, 62, 4), BlockId::OAK_LOG, "tree did not grow");
        // floating leaf with no log nearby decays
        w.set_block(-20, 80, -20, BlockId::OAK_LEAVES);
        t.random_tick_block(&mut w, BlockPos::new(-20, 80, -20));
        assert_eq!(w.get_block(-20, 80, -20), BlockId::AIR);
    }

    #[test]
    fn sugar_cane_grows() {
        let mut w = world();
        let mut t = WorldTicker::new(9);
        w.set_block(2, 61, 2, BlockId::SUGAR_CANE);
        for _ in 0..200 {
            t.random_tick_block(&mut w, BlockPos::new(2, 61, 2));
        }
        assert_eq!(w.get_block(2, 62, 2), BlockId::SUGAR_CANE);
        assert_eq!(w.get_block(2, 64, 2), BlockId::AIR); // capped at 3
    }
}
