//! Mob registry (60 mobs) and a small physics + AI core for walking mobs.

use crate::math::{Aabb, Vec3};
use crate::physics::{collide, GRAVITY};
use crate::rng::{JavaRandom, RandomSource};
use crate::world::World;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Behavior {
    Passive,
    Neutral,
    Hostile,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Category {
    Creature,
    Monster,
    Water,
    Ambient,
}

macro_rules! mobs {
    ($( $V:ident $name:literal $w:literal $h:literal $hp:literal $atk:literal $spd:literal $beh:ident $cat:ident ;)*) => {
        #[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
        pub enum MobKind { $($V),* }
        #[derive(Clone, Copy, Debug)]
        pub struct MobInfo {
            pub name: &'static str, pub width: f64, pub height: f64, pub health: f32,
            pub attack: f32, pub speed: f64, pub behavior: Behavior, pub category: Category,
        }
        impl MobKind {
            pub const ALL: &'static [MobKind] = &[ $(MobKind::$V),* ];
            pub fn info(self) -> MobInfo {
                match self { $(MobKind::$V => MobInfo { name: $name, width: $w, height: $h, health: $hp, attack: $atk,
                    speed: $spd, behavior: Behavior::$beh, category: Category::$cat }),* }
            }
        }
    };
}

// name, width, height, health, attack, speed (blocks / tick), behaviour, category
mobs! {
    Zombie "zombie" 0.6 1.95 20.0 3.0 0.115 Hostile Monster;
    Husk "husk" 0.6 1.95 20.0 3.0 0.115 Hostile Monster;
    Drowned "drowned" 0.6 1.95 20.0 3.0 0.115 Hostile Monster;
    ZombieVillager "zombie_villager" 0.6 1.95 20.0 3.0 0.115 Hostile Monster;
    Skeleton "skeleton" 0.6 1.99 20.0 2.0 0.1 Hostile Monster;
    Stray "stray" 0.6 1.99 20.0 2.0 0.1 Hostile Monster;
    Creeper "creeper" 0.6 1.7 20.0 0.0 0.1 Hostile Monster;
    Spider "spider" 1.4 0.9 16.0 2.0 0.15 Hostile Monster;
    CaveSpider "cave_spider" 0.7 0.5 12.0 2.0 0.15 Hostile Monster;
    Enderman "enderman" 0.6 2.9 40.0 7.0 0.15 Neutral Monster;
    Witch "witch" 0.6 1.95 26.0 0.0 0.1 Hostile Monster;
    Slime "slime" 2.04 2.04 16.0 3.0 0.08 Hostile Monster;
    MagmaCube "magma_cube" 2.04 2.04 16.0 4.0 0.08 Hostile Monster;
    Silverfish "silverfish" 0.4 0.3 8.0 1.0 0.12 Hostile Monster;
    Phantom "phantom" 0.9 0.5 20.0 2.0 0.2 Hostile Monster;
    Pillager "pillager" 0.6 1.95 24.0 4.0 0.11 Hostile Monster;
    Vindicator "vindicator" 0.6 1.95 24.0 8.0 0.12 Hostile Monster;
    Evoker "evoker" 0.6 1.95 24.0 6.0 0.11 Hostile Monster;
    Ravager "ravager" 1.95 2.2 100.0 12.0 0.1 Hostile Monster;
    Vex "vex" 0.4 0.8 14.0 4.0 0.2 Hostile Monster;
    Guardian "guardian" 0.85 0.85 30.0 6.0 0.1 Hostile Water;
    Blaze "blaze" 0.6 1.8 20.0 6.0 0.1 Hostile Monster;
    Ghast "ghast" 4.0 4.0 10.0 0.0 0.05 Hostile Monster;
    PiglinBrute "piglin_brute" 0.6 1.95 50.0 13.0 0.12 Hostile Monster;
    Hoglin "hoglin" 1.4 1.4 40.0 6.0 0.1 Hostile Creature;
    WitherSkeleton "wither_skeleton" 0.7 2.4 20.0 8.0 0.1 Hostile Monster;
    Shulker "shulker" 1.0 1.0 30.0 4.0 0.0 Hostile Monster;
    Warden "warden" 0.9 2.9 500.0 30.0 0.13 Hostile Monster;
    Breeze "breeze" 0.6 1.77 30.0 1.0 0.12 Hostile Monster;
    Piglin "piglin" 0.6 1.95 16.0 5.0 0.12 Neutral Monster;
    ZombifiedPiglin "zombified_piglin" 0.6 1.95 20.0 5.0 0.12 Neutral Monster;
    Wolf "wolf" 0.6 0.85 8.0 4.0 0.15 Neutral Creature;
    IronGolem "iron_golem" 1.4 2.7 100.0 15.0 0.1 Neutral Creature;
    PolarBear "polar_bear" 1.4 1.4 30.0 6.0 0.12 Neutral Creature;
    Bee "bee" 0.7 0.6 10.0 2.0 0.12 Neutral Creature;
    Llama "llama" 0.9 1.87 15.0 1.0 0.1 Neutral Creature;
    Panda "panda" 1.3 1.25 20.0 6.0 0.08 Neutral Creature;
    Dolphin "dolphin" 0.9 0.6 10.0 3.0 0.2 Neutral Water;
    Goat "goat" 0.9 1.3 10.0 2.0 0.12 Neutral Creature;
    Cow "cow" 0.9 1.4 10.0 0.0 0.1 Passive Creature;
    Mooshroom "mooshroom" 0.9 1.4 10.0 0.0 0.1 Passive Creature;
    Pig "pig" 0.9 0.9 10.0 0.0 0.1 Passive Creature;
    Sheep "sheep" 0.9 1.3 8.0 0.0 0.1 Passive Creature;
    Chicken "chicken" 0.4 0.7 4.0 0.0 0.1 Passive Creature;
    Horse "horse" 1.4 1.6 22.0 0.0 0.17 Passive Creature;
    Donkey "donkey" 1.4 1.5 22.0 0.0 0.12 Passive Creature;
    Rabbit "rabbit" 0.4 0.5 3.0 0.0 0.15 Passive Creature;
    Cat "cat" 0.6 0.7 10.0 0.0 0.15 Passive Creature;
    Ocelot "ocelot" 0.6 0.7 10.0 0.0 0.15 Passive Creature;
    Fox "fox" 0.6 0.7 10.0 2.0 0.15 Passive Creature;
    Villager "villager" 0.6 1.95 20.0 0.0 0.1 Passive Creature;
    WanderingTrader "wandering_trader" 0.6 1.95 20.0 0.0 0.1 Passive Creature;
    Turtle "turtle" 1.2 0.4 30.0 0.0 0.03 Passive Creature;
    Parrot "parrot" 0.5 0.9 6.0 0.0 0.12 Passive Creature;
    Axolotl "axolotl" 0.75 0.42 14.0 2.0 0.1 Passive Water;
    Frog "frog" 0.5 0.5 10.0 0.0 0.1 Passive Creature;
    Camel "camel" 1.7 2.375 32.0 0.0 0.1 Passive Creature;
    Sniffer "sniffer" 1.9 1.75 14.0 0.0 0.08 Passive Creature;
    Armadillo "armadillo" 0.7 0.65 12.0 0.0 0.1 Passive Creature;
    Squid "squid" 0.8 0.8 10.0 0.0 0.1 Passive Water;
    GlowSquid "glow_squid" 0.8 0.8 10.0 0.0 0.1 Passive Water;
    Cod "cod" 0.5 0.3 3.0 0.0 0.1 Passive Water;
    Salmon "salmon" 0.7 0.4 3.0 0.0 0.1 Passive Water;
    Bat "bat" 0.5 0.9 6.0 0.0 0.1 Passive Ambient;
}

impl MobKind {
    pub fn from_name(n: &str) -> Option<MobKind> {
        let n = n.trim_start_matches("minecraft:");
        MobKind::ALL.iter().copied().find(|k| k.info().name == n)
    }
    pub fn burns_in_daylight(self) -> bool {
        matches!(self, MobKind::Zombie | MobKind::Skeleton | MobKind::ZombieVillager | MobKind::Phantom)
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum MobEvent {
    None,
    /// Melee hit on the player (raw damage).
    Attack(f32),
    /// A creeper blew up with this power.
    Explode(f32),
}

#[derive(Clone, Debug)]
pub struct Mob {
    pub kind: MobKind,
    pub pos: Vec3,
    pub vel: Vec3,
    pub yaw: f32,
    pub health: f32,
    pub on_ground: bool,
    pub age: u32,
    wander_timer: i32,
    wander_yaw: f64,
    cooldown: u32,
    fuse: i32,
}

pub const AGGRO_RANGE: f64 = 16.0;

impl Mob {
    pub fn new(kind: MobKind, pos: Vec3) -> Self {
        Self { kind, pos, vel: Vec3::ZERO, yaw: 0.0, health: kind.info().health, on_ground: false, age: 0, wander_timer: 0, wander_yaw: 0.0, cooldown: 0, fuse: -1 }
    }
    pub fn bounding_box(&self) -> Aabb {
        let i = self.kind.info();
        Aabb::from_feet(self.pos, i.width, i.height)
    }
    pub fn is_dead(&self) -> bool {
        self.health <= 0.0
    }
    pub fn hurt(&mut self, amount: f32, knock_from: Vec3) {
        self.health -= amount;
        let d = Vec3::new(self.pos.x - knock_from.x, 0.0, self.pos.z - knock_from.z).normalize();
        self.vel += Vec3::new(d.x * 0.4, 0.36, d.z * 0.4);
        self.on_ground = false;
    }

    /// One 20 TPS tick. `player` is the position of the nearest player, if any.
    pub fn tick(&mut self, world: &World, player: Option<Vec3>, is_day: bool, rng: &mut JavaRandom) -> MobEvent {
        let info = self.kind.info();
        self.age += 1;
        self.cooldown = self.cooldown.saturating_sub(1);
        let mut event = MobEvent::None;

        // sunlight damage for undead
        if self.kind.burns_in_daylight() && is_day && self.age % 20 == 0 {
            let (x, y, z) = (self.pos.x.floor() as i32, (self.pos.y + info.height).floor() as i32, self.pos.z.floor() as i32);
            if world.sky_light(x, y, z) >= 15 && !world.get_block(x, y, z).is_liquid() {
                self.health -= 1.0;
            }
        }

        // decide where to walk
        let mut dir: Option<f64> = None;
        let mut dist = f64::MAX;
        let hunting = matches!(info.behavior, Behavior::Hostile) && player.is_some_and(|p| (p - self.pos).length() < AGGRO_RANGE);
        if hunting {
            let p = player.unwrap();
            let d = p - self.pos;
            dist = (d.x * d.x + d.z * d.z).sqrt();
            dir = Some((-d.x).atan2(d.z));
        } else if info.speed > 0.0 {
            self.wander_timer -= 1;
            if self.wander_timer <= 0 {
                self.wander_timer = 40 + rng.next_i32_bounded(80);
                self.wander_yaw = if rng.next_i32_bounded(3) == 0 { f64::NAN } else { rng.next_f64() * std::f64::consts::TAU };
            }
            if !self.wander_yaw.is_nan() {
                dir = Some(self.wander_yaw);
            }
        }

        let reach = info.width * 0.5 + 0.9;
        let mut wish = Vec3::ZERO;
        if let Some(a) = dir {
            if !(hunting && dist < reach * 0.8) {
                let speed = info.speed * if hunting { 1.0 } else { 0.5 };
                wish = Vec3::new(-a.sin() * speed, 0.0, a.cos() * speed);
                self.yaw = a.to_degrees() as f32;
            }
        }

        // attacks
        if hunting {
            if self.kind == MobKind::Creeper {
                if dist < 3.0 {
                    if self.fuse < 0 {
                        self.fuse = 30;
                    }
                } else if dist > 7.0 {
                    self.fuse = -1;
                }
                if self.fuse >= 0 {
                    self.fuse -= 1;
                    wish = Vec3::ZERO;
                    if self.fuse == 0 {
                        self.health = 0.0;
                        event = MobEvent::Explode(crate::explosion::CREEPER_POWER);
                    }
                }
            } else if dist < reach && self.cooldown == 0 && info.attack > 0.0 {
                self.cooldown = 20;
                event = MobEvent::Attack(info.attack);
            }
        }

        // physics
        let in_water = world.get_block(self.pos.x.floor() as i32, (self.pos.y + 0.2).floor() as i32, self.pos.z.floor() as i32).is_liquid();
        if in_water && info.category != Category::Water {
            self.vel.y += 0.04;
        }
        let ground_fric = if self.on_ground { 0.6 * 0.91 } else { 0.91 };
        self.vel.x = self.vel.x * ground_fric + wish.x * 0.35;
        self.vel.z = self.vel.z * ground_fric + wish.z * 0.35;
        if info.category == Category::Water && in_water {
            self.vel.y *= 0.8;
        } else {
            self.vel.y = (self.vel.y - GRAVITY) * 0.98;
        }
        let want = self.vel;
        let got = collide(world, &self.bounding_box(), want);
        let blocked_h = (want.x - got.x).abs() > 1e-9 || (want.z - got.z).abs() > 1e-9;
        self.on_ground = want.y < 0.0 && (want.y - got.y).abs() > 1e-9;
        if (want.y - got.y).abs() > 1e-9 {
            self.vel.y = 0.0;
        }
        if blocked_h {
            if self.on_ground && dir.is_some() {
                self.vel.y = 0.42; // hop over a one block ledge
            }
            if (want.x - got.x).abs() > 1e-9 { self.vel.x = 0.0 }
            if (want.z - got.z).abs() > 1e-9 { self.vel.z = 0.0 }
            if !hunting {
                self.wander_timer = 0;
            }
        }
        self.pos += got;
        event
    }
}

/// Vanilla-like spawn conditions for `kind` at the feet position `(x, y, z)`.
pub fn can_spawn(world: &World, kind: MobKind, x: i32, y: i32, z: i32, is_night: bool) -> bool {
    let info = kind.info();
    let feet = world.get_block(x, y, z);
    let head = world.get_block(x, y + 1, z);
    let below = world.get_block(x, y - 1, z);
    match info.category {
        Category::Water => feet.is_water() && head.is_water(),
        Category::Ambient => feet.is_air() && y < 63 && world.sky_light(x, y, z) < 4,
        Category::Monster => {
            below.is_solid() && !feet.is_solid() && !feet.is_liquid() && !head.is_solid()
                && world.block_light(x, y, z) <= 7
                && (world.sky_light(x, y, z) <= 7 || is_night && world.sky_light(x, y, z) < 11)
        }
        Category::Creature => {
            matches!(below, crate::block::BlockId::GRASS_BLOCK | crate::block::BlockId::SAND | crate::block::BlockId::SNOW_BLOCK | crate::block::BlockId::PODZOL | crate::block::BlockId::MYCELIUM)
                && feet.is_air() && head.is_air() && world.sky_light(x, y, z) >= 9
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::block::BlockId;
    use crate::chunk::Chunk;
    use crate::math::ChunkPos;

    fn world() -> World {
        let mut w = World::new(1);
        for cx in -2..=2 {
            for cz in -2..=2 {
                let mut c = Chunk::new(ChunkPos::new(cx, cz));
                for x in 0..16 {
                    for z in 0..16 {
                        for y in -64..=59 {
                            c.set_block(x, y, z, BlockId::STONE);
                        }
                        c.set_block(x, 60, z, BlockId::GRASS_BLOCK);
                    }
                }
                c.rebuild_heightmaps();
                crate::lighting::compute_chunk_light(&mut c);
                w.insert_chunk(c);
            }
        }
        w
    }

    #[test]
    fn registry_size() {
        assert!(MobKind::ALL.len() >= 60, "{}", MobKind::ALL.len());
        assert_eq!(MobKind::from_name("minecraft:creeper"), Some(MobKind::Creeper));
        assert_eq!(MobKind::Zombie.info().behavior, Behavior::Hostile);
    }

    #[test]
    fn zombie_chases_and_hits_the_player() {
        let w = world();
        let mut rng = JavaRandom::new(1);
        let mut z = Mob::new(MobKind::Zombie, Vec3::new(8.0, 61.0, 8.0));
        let player = Vec3::new(14.0, 61.0, 8.0);
        let mut hit = false;
        for _ in 0..200 {
            if let MobEvent::Attack(d) = z.tick(&w, Some(player), false, &mut rng) {
                assert_eq!(d, 3.0);
                hit = true;
                break;
            }
        }
        assert!(hit, "zombie never reached the player, at {:?}", z.pos);
        assert!(z.on_ground || z.pos.y >= 60.9);
    }

    #[test]
    fn creeper_explodes_and_cows_wander() {
        let w = world();
        let mut rng = JavaRandom::new(2);
        let mut c = Mob::new(MobKind::Creeper, Vec3::new(8.0, 61.0, 8.0));
        let mut boom = false;
        for _ in 0..120 {
            if let MobEvent::Explode(p) = c.tick(&w, Some(Vec3::new(9.0, 61.0, 8.0)), false, &mut rng) {
                assert_eq!(p, 3.0);
                boom = true;
                break;
            }
        }
        assert!(boom && c.is_dead());
        let mut cow = Mob::new(MobKind::Cow, Vec3::new(8.0, 61.0, 8.0));
        let start = cow.pos;
        for _ in 0..400 {
            cow.tick(&w, None, true, &mut rng);
        }
        assert!((cow.pos - start).length() > 0.5);
        assert!(cow.pos.y >= 60.99 && cow.pos.y < 61.2);
    }

    #[test]
    fn spawn_rules() {
        let w = world();
        assert!(can_spawn(&w, MobKind::Cow, 3, 61, 3, false));
        assert!(!can_spawn(&w, MobKind::Zombie, 3, 61, 3, false)); // bright daylight
        assert!(!can_spawn(&w, MobKind::Squid, 3, 61, 3, false));
    }
}
