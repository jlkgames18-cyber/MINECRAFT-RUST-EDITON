//! Game rules around the player: game modes, health / hunger ([`Vitals`]), damage and armour.

use crate::item::ItemId;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum GameMode {
    #[default]
    Survival,
    Creative,
    Adventure,
    Spectator,
}

impl GameMode {
    pub fn from_name(s: &str) -> Option<GameMode> {
        match s {
            "survival" | "s" | "0" => Some(GameMode::Survival),
            "creative" | "c" | "1" => Some(GameMode::Creative),
            "adventure" | "a" | "2" => Some(GameMode::Adventure),
            "spectator" | "sp" | "3" => Some(GameMode::Spectator),
            _ => None,
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            GameMode::Survival => "survival",
            GameMode::Creative => "creative",
            GameMode::Adventure => "adventure",
            GameMode::Spectator => "spectator",
        }
    }
    pub fn can_fly(self) -> bool {
        matches!(self, GameMode::Creative | GameMode::Spectator)
    }
    pub fn takes_damage(self) -> bool {
        matches!(self, GameMode::Survival | GameMode::Adventure)
    }
    pub fn can_build(self) -> bool {
        matches!(self, GameMode::Survival | GameMode::Creative)
    }
    pub fn instabreak(self) -> bool {
        self == GameMode::Creative
    }
    /// Block interaction reach in blocks.
    pub fn reach(self) -> f64 {
        if self == GameMode::Creative { 5.0 } else { 4.5 }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum DamageSource {
    Fall,
    Drown,
    Lava,
    Fire,
    Starve,
    Mob(f32),
    Explosion,
    Void,
    Generic,
}

#[derive(Clone, Debug)]
pub struct Vitals {
    pub health: f32,
    pub food: i32,
    pub saturation: f32,
    pub exhaustion: f32,
    pub air: i32,
    pub xp_level: i32,
    pub xp_points: i32,
    regen_timer: u32,
    drown_timer: u32,
    pub dead: bool,
}

pub const MAX_HEALTH: f32 = 20.0;
pub const MAX_AIR: i32 = 300;

impl Default for Vitals {
    fn default() -> Self {
        Self { health: MAX_HEALTH, food: 20, saturation: 5.0, exhaustion: 0.0, air: MAX_AIR, xp_level: 0, xp_points: 0, regen_timer: 0, drown_timer: 0, dead: false }
    }
}

/// Damage after armour (vanilla formula, `armor` in armour points 0..=20).
pub fn damage_after_armor(damage: f32, armor: f32, toughness: f32) -> f32 {
    let reduction = (armor / 5.0).max(armor - damage / (2.0 + toughness / 4.0)).clamp(0.0, 20.0);
    damage * (1.0 - reduction / 25.0)
}

/// Fall damage for a fall of `distance` blocks (3 free blocks, `feather_falling` levels each −12 %).
pub fn fall_damage(distance: f64, jump_boost: i32, feather_falling: i32) -> f32 {
    let raw = (distance - 3.0 - jump_boost as f64).ceil();
    if raw <= 0.0 { 0.0 } else { (raw as f32) * (1.0 - 0.12 * feather_falling.min(4) as f32) }
}

impl Vitals {
    pub fn damage(&mut self, amount: f32) {
        self.health = (self.health - amount).max(0.0);
        if self.health <= 0.0 {
            self.dead = true;
        }
        self.exhaustion += 0.1;
    }
    pub fn heal(&mut self, amount: f32) {
        self.health = (self.health + amount).min(MAX_HEALTH);
    }
    pub fn exhaust(&mut self, amount: f32) {
        self.exhaustion += amount;
    }
    pub fn eat(&mut self, hunger: i32, saturation: f32) {
        self.food = (self.food + hunger).min(20);
        self.saturation = (self.saturation + saturation).min(self.food as f32);
    }
    pub fn can_eat(&self) -> bool {
        self.food < 20
    }
    /// Exhaustion costs of common actions.
    pub fn on_jump(&mut self, sprinting: bool) {
        self.exhaust(if sprinting { 0.2 } else { 0.05 });
    }
    pub fn on_walk(&mut self, blocks: f64, sprinting: bool, swimming: bool) {
        if sprinting {
            self.exhaust(0.1 * blocks as f32);
        } else if swimming {
            self.exhaust(0.01 * blocks as f32);
        }
    }
    pub fn add_xp(&mut self, points: i32) {
        self.xp_points += points;
        while self.xp_points >= xp_for_next_level(self.xp_level) {
            self.xp_points -= xp_for_next_level(self.xp_level);
            self.xp_level += 1;
        }
    }

    /// One 20 TPS tick of hunger, regeneration, starvation and drowning.
    pub fn tick(&mut self, eyes_in_water: bool, can_breathe_water: bool) {
        // exhaustion → saturation → food
        while self.exhaustion >= 4.0 {
            self.exhaustion -= 4.0;
            if self.saturation > 0.0 {
                self.saturation = (self.saturation - 1.0).max(0.0);
            } else if self.food > 0 {
                self.food -= 1;
            }
        }
        // regeneration
        if self.saturation > 0.0 && self.food >= 20 && self.health < MAX_HEALTH {
            self.regen_timer += 1;
            if self.regen_timer >= 10 {
                let a = self.saturation.min(6.0);
                self.heal(a / 6.0);
                self.exhaust(a);
                self.regen_timer = 0;
            }
        } else if self.food >= 18 && self.health < MAX_HEALTH {
            self.regen_timer += 1;
            if self.regen_timer >= 80 {
                self.heal(1.0);
                self.exhaust(6.0);
                self.regen_timer = 0;
            }
        } else if self.food <= 0 {
            self.regen_timer += 1;
            if self.regen_timer >= 80 {
                self.damage(1.0);
                self.regen_timer = 0;
            }
        } else {
            self.regen_timer = 0;
        }
        // air
        if eyes_in_water && !can_breathe_water {
            if self.air > -20 {
                self.air -= 1;
            }
            if self.air <= -20 {
                self.air = 0;
                self.drown_timer += 1;
                self.damage(2.0);
            }
        } else {
            self.air = (self.air + 4).min(MAX_AIR);
        }
    }
}

pub fn xp_for_next_level(level: i32) -> i32 {
    if level >= 30 { 112 + (level - 30) * 9 } else if level >= 15 { 37 + (level - 15) * 5 } else { 7 + level * 2 }
}

/// Item the player holds for a food check helper (used by `Inventory`/commands).
pub fn is_edible(item: ItemId) -> bool {
    item.info().food.is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn armor_and_fall_damage() {
        assert!((damage_after_armor(10.0, 20.0, 0.0) - 4.0).abs() < 1e-4); // 20 armour points ≈ 60 % here
        assert_eq!(damage_after_armor(5.0, 0.0, 0.0), 5.0);
        assert_eq!(fall_damage(3.0, 0, 0), 0.0);
        assert_eq!(fall_damage(10.0, 0, 0), 7.0);
        assert!(fall_damage(10.0, 0, 4) < 4.0);
    }

    #[test]
    fn hunger_and_regen() {
        let mut v = Vitals::default();
        v.health = 10.0;
        for _ in 0..200 {
            v.tick(false, false);
        }
        assert!(v.health > 10.0);
        v.exhaust(40.0);
        v.tick(false, false);
        assert!(v.food < 20 || v.saturation < 5.0);
    }

    #[test]
    fn starvation_and_drowning_kill() {
        let mut v = Vitals::default();
        v.food = 0;
        v.saturation = 0.0;
        for _ in 0..80 * 25 {
            v.tick(false, false);
        }
        assert!(v.dead);
        let mut d = Vitals::default();
        for _ in 0..600 {
            d.tick(true, false);
        }
        assert!(d.health < 20.0);
        let mut ok = Vitals::default();
        for _ in 0..600 {
            ok.tick(true, true);
        }
        assert_eq!(ok.health, 20.0);
    }

    #[test]
    fn xp_levels() {
        let mut v = Vitals::default();
        v.add_xp(7);
        assert_eq!(v.xp_level, 1);
        v.add_xp(500);
        assert!(v.xp_level >= 10);
        assert_eq!(GameMode::from_name("creative"), Some(GameMode::Creative));
        assert!(GameMode::Creative.can_fly() && !GameMode::Survival.can_fly());
    }
}
