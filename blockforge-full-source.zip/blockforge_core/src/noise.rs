//! Improved Perlin noise + fractal octaves, with the permutation table built the same way
//! the vanilla game builds it (shuffle driven by the seeded RNG, random per-instance offsets).

use crate::rng::RandomSource;

const GRADIENT: [[i8; 3]; 16] = [
    [1, 1, 0],
    [-1, 1, 0],
    [1, -1, 0],
    [-1, -1, 0],
    [1, 0, 1],
    [-1, 0, 1],
    [1, 0, -1],
    [-1, 0, -1],
    [0, 1, 1],
    [0, -1, 1],
    [0, 1, -1],
    [0, -1, -1],
    [1, 1, 0],
    [0, -1, 1],
    [-1, 1, 0],
    [0, -1, -1],
];

#[inline]
fn smoothstep(t: f64) -> f64 {
    t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
}

#[inline]
fn lerp(t: f64, a: f64, b: f64) -> f64 {
    a + t * (b - a)
}

#[derive(Clone)]
pub struct ImprovedNoise {
    p: [u8; 256],
    xo: f64,
    yo: f64,
    zo: f64,
}

impl ImprovedNoise {
    pub fn new<R: RandomSource>(rng: &mut R) -> Self {
        let xo = rng.next_f64() * 256.0;
        let yo = rng.next_f64() * 256.0;
        let zo = rng.next_f64() * 256.0;
        let mut p = [0u8; 256];
        for (i, v) in p.iter_mut().enumerate() {
            *v = i as u8;
        }
        for i in 0..256 {
            let j = rng.next_i32_bounded((256 - i) as i32) as usize;
            p.swap(i, i + j);
        }
        Self { p, xo, yo, zo }
    }

    #[inline(always)]
    fn perm(&self, i: i32) -> i32 {
        self.p[(i & 0xFF) as usize] as i32
    }

    #[inline(always)]
    fn grad(hash: i32, x: f64, y: f64, z: f64) -> f64 {
        let g = &GRADIENT[(hash & 15) as usize];
        g[0] as f64 * x + g[1] as f64 * y + g[2] as f64 * z
    }

    pub fn noise(&self, x: f64, y: f64, z: f64) -> f64 {
        let x = x + self.xo;
        let y = y + self.yo;
        let z = z + self.zo;
        let xf = x.floor();
        let yf = y.floor();
        let zf = z.floor();
        let xi = xf as i32;
        let yi = yf as i32;
        let zi = zf as i32;
        let xr = x - xf;
        let yr = y - yf;
        let zr = z - zf;

        let a = self.perm(xi);
        let b = self.perm(xi + 1);
        let aa = self.perm(a + yi);
        let ab = self.perm(a + yi + 1);
        let ba = self.perm(b + yi);
        let bb = self.perm(b + yi + 1);

        let g000 = Self::grad(self.perm(aa + zi), xr, yr, zr);
        let g100 = Self::grad(self.perm(ba + zi), xr - 1.0, yr, zr);
        let g010 = Self::grad(self.perm(ab + zi), xr, yr - 1.0, zr);
        let g110 = Self::grad(self.perm(bb + zi), xr - 1.0, yr - 1.0, zr);
        let g001 = Self::grad(self.perm(aa + zi + 1), xr, yr, zr - 1.0);
        let g101 = Self::grad(self.perm(ba + zi + 1), xr - 1.0, yr, zr - 1.0);
        let g011 = Self::grad(self.perm(ab + zi + 1), xr, yr - 1.0, zr - 1.0);
        let g111 = Self::grad(self.perm(bb + zi + 1), xr - 1.0, yr - 1.0, zr - 1.0);

        let u = smoothstep(xr);
        let v = smoothstep(yr);
        let w = smoothstep(zr);

        lerp(
            w,
            lerp(v, lerp(u, g000, g100), lerp(u, g010, g110)),
            lerp(v, lerp(u, g001, g101), lerp(u, g011, g111)),
        )
    }
}

/// Fractal sum of several [`ImprovedNoise`] octaves.
#[derive(Clone)]
pub struct OctaveNoise {
    octaves: Vec<ImprovedNoise>,
    lacunarity: f64,
    persistence: f64,
    max_value: f64,
}

impl OctaveNoise {
    pub fn new<R: RandomSource>(rng: &mut R, octaves: usize) -> Self {
        let lacunarity = 2.0;
        let persistence = 0.5;
        let list: Vec<ImprovedNoise> = (0..octaves).map(|_| ImprovedNoise::new(rng)).collect();
        let mut max_value = 0.0;
        let mut amp = 1.0;
        for _ in 0..octaves {
            max_value += amp;
            amp *= persistence;
        }
        Self { octaves: list, lacunarity, persistence, max_value }
    }

    /// Returns a value roughly in `[-1, 1]`.
    pub fn sample(&self, x: f64, y: f64, z: f64) -> f64 {
        let mut freq = 1.0;
        let mut amp = 1.0;
        let mut sum = 0.0;
        for o in &self.octaves {
            sum += o.noise(x * freq, y * freq, z * freq) * amp;
            freq *= self.lacunarity;
            amp *= self.persistence;
        }
        sum / self.max_value
    }

    /// 2D convenience (y fixed).
    #[inline]
    pub fn sample2d(&self, x: f64, z: f64) -> f64 {
        self.sample(x, 0.0, z)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::JavaRandom;

    #[test]
    fn noise_is_deterministic_and_bounded() {
        let mut r1 = JavaRandom::new(1234);
        let mut r2 = JavaRandom::new(1234);
        let n1 = ImprovedNoise::new(&mut r1);
        let n2 = ImprovedNoise::new(&mut r2);
        for i in 0..500 {
            let (x, y, z) = (i as f64 * 0.37, i as f64 * 0.11, i as f64 * -0.23);
            let a = n1.noise(x, y, z);
            assert_eq!(a, n2.noise(x, y, z));
            assert!(a.abs() <= 1.5);
        }
    }

    #[test]
    fn noise_is_continuous() {
        let mut r = JavaRandom::new(99);
        let n = ImprovedNoise::new(&mut r);
        let a = n.noise(10.0, 5.0, 3.0);
        let b = n.noise(10.0001, 5.0, 3.0);
        assert!((a - b).abs() < 0.01);
    }

    #[test]
    fn octave_noise_normalised() {
        let mut r = JavaRandom::new(5);
        let n = OctaveNoise::new(&mut r, 6);
        for i in 0..1000 {
            let v = n.sample2d(i as f64 * 0.7, i as f64 * 1.3);
            assert!(v.abs() <= 1.2, "value {v}");
        }
    }
}
