//! Block breaking: vanilla destroy-speed formula, tool tiers, drops and tool wear.

use crate::block::{flags, tool, BlockId};
use crate::effects::ActiveEffects;
use crate::inventory::ItemStack;
use crate::item::{ItemId, ItemInfo};
use crate::rng::{JavaRandom, RandomSource};

#[derive(Clone, Copy, Debug, Default)]
pub struct MiningContext {
    pub in_water: bool,
    pub on_ground: bool,
    pub aqua_affinity: bool,
    pub efficiency: u8,
    pub haste: i32,
    pub fatigue: i32,
    pub silk_touch: bool,
    pub fortune: u8,
    pub creative: bool,
}

impl MiningContext {
    pub fn from_effects(e: &ActiveEffects) -> Self {
        Self { on_ground: true, haste: e.haste_level(), fatigue: e.fatigue_level(), ..Default::default() }
    }
}

fn tool_matches(block: BlockId, t: Option<&ItemInfo>) -> bool {
    let b = block.info();
    match t {
        Some(t) if t.tool != tool::NONE => {
            t.tool == b.tool
                || (t.tool == tool::SHEARS && (block.is_leaves() || block.short_name().ends_with("_wool") || block == BlockId::COBWEB || block == BlockId::VINE))
                || (t.tool == tool::SWORD && (block == BlockId::COBWEB || block == BlockId::BAMBOO))
        }
        _ => false,
    }
}

/// Whether the block drops anything with this tool.
pub fn can_harvest(block: BlockId, t: Option<&ItemInfo>) -> bool {
    let b = block.info();
    if b.flags & flags::REQUIRES_TOOL == 0 {
        return true;
    }
    matches!(t, Some(t) if t.tool == b.tool && t.tier >= b.min_tier)
}

/// Destroy speed per tick (vanilla `Player.getDestroySpeed`).
pub fn destroy_speed(block: BlockId, t: Option<&ItemInfo>, ctx: &MiningContext) -> f32 {
    let mut speed = 1.0f32;
    if tool_matches(block, t) {
        let t = t.unwrap();
        speed = match (t.tool, block) {
            (tool::SHEARS, BlockId::COBWEB) => 15.0,
            (tool::SHEARS, b) if b.is_leaves() => 15.0,
            (tool::SHEARS, _) => 5.0,
            (tool::SWORD, BlockId::COBWEB) => 15.0,
            (tool::SWORD, _) => 1.5,
            _ => t.mining_speed,
        };
        if ctx.efficiency > 0 {
            speed += (ctx.efficiency as f32).powi(2) + 1.0;
        }
    }
    if ctx.haste > 0 {
        speed *= 1.0 + 0.2 * ctx.haste as f32;
    }
    if ctx.fatigue > 0 {
        speed *= match ctx.fatigue { 1 => 0.3, 2 => 0.09, 3 => 0.0027, _ => 0.000_81 };
    }
    if ctx.in_water && !ctx.aqua_affinity {
        speed /= 5.0;
    }
    if !ctx.on_ground {
        speed /= 5.0;
    }
    speed
}

/// Ticks needed to break the block (0 = instant). `None` = unbreakable.
pub fn break_ticks(block: BlockId, t: Option<&ItemInfo>, ctx: &MiningContext) -> Option<u32> {
    let h = block.hardness();
    if block.is_air() || h < 0.0 {
        return if ctx.creative && !block.is_air() && block != BlockId::BEDROCK { Some(0) } else { None };
    }
    if ctx.creative || h == 0.0 {
        return Some(0);
    }
    let divisor = if can_harvest(block, t) { 30.0 } else { 100.0 };
    let damage = destroy_speed(block, t, ctx) / h / divisor;
    if damage >= 1.0 {
        return Some(0);
    }
    Some((1.0 / damage).ceil() as u32)
}

/// Items dropped when a block is broken.
pub fn drops(block: BlockId, t: Option<&ItemInfo>, ctx: &MiningContext, rng: &mut JavaRandom) -> Vec<ItemStack> {
    let it = |n: &str, c: i32| ItemStack::new(ItemId::of(n), c.clamp(0, 64) as u8);
    let own = ItemStack::new(ItemId::from_block(block), 1);
    let name = block.short_name();
    if block.is_air() || block.is_liquid() || block == BlockId::BEDROCK || block == BlockId::SPAWNER {
        return vec![];
    }
    let shears = matches!(t, Some(t) if t.tool == tool::SHEARS);
    if ctx.silk_touch && !block.is_liquid() && name != "spawner" {
        return vec![own];
    }
    if !can_harvest(block, t) {
        return vec![];
    }
    let fortune = ctx.fortune as i32;
    let fort_mult = |rng: &mut JavaRandom| -> i32 { if fortune == 0 { 1 } else { (rng.next_i32_bounded(fortune + 2) - 1).max(0) + 1 } };
    match name {
        "grass_block" | "podzol" | "mycelium" | "farmland" | "dirt_path" | "rooted_dirt" => vec![it("dirt", 1)],
        "stone" => vec![it("cobblestone", 1)],
        "deepslate" => vec![it("cobbled_deepslate", 1)],
        "coal_ore" | "deepslate_coal_ore" => vec![it("coal", fort_mult(rng))],
        "diamond_ore" | "deepslate_diamond_ore" => vec![it("diamond", fort_mult(rng))],
        "emerald_ore" | "deepslate_emerald_ore" => vec![it("emerald", fort_mult(rng))],
        "iron_ore" | "deepslate_iron_ore" => vec![it("raw_iron", fort_mult(rng))],
        "gold_ore" | "deepslate_gold_ore" => vec![it("raw_gold", fort_mult(rng))],
        "copper_ore" | "deepslate_copper_ore" => vec![it("raw_copper", (2 + rng.next_i32_bounded(4)) * fort_mult(rng))],
        "lapis_ore" | "deepslate_lapis_ore" => vec![it("lapis_lazuli", (4 + rng.next_i32_bounded(6)) * fort_mult(rng))],
        "redstone_ore" | "deepslate_redstone_ore" => vec![it("redstone", 4 + rng.next_i32_bounded(2) + fortune)],
        "nether_quartz_ore" => vec![it("quartz", fort_mult(rng))],
        "nether_gold_ore" => vec![it("gold_nugget_dummy", 0)].into_iter().filter(|s| !s.is_empty()).chain([it("gold_ingot", 2 + rng.next_i32_bounded(5))]).collect(),
        "gravel" => {
            let chance = [10, 7, 4, 1][fortune.min(3) as usize];
            if rng.next_i32_bounded(chance) == 0 { vec![it("flint", 1)] } else { vec![own] }
        }
        "snow_block" => vec![it("snowball", 4)],
        "clay" => vec![it("clay_ball", 4)],
        "glowstone" => vec![it("glowstone_dust", (2 + rng.next_i32_bounded(3 + fortune)).min(4))],
        "sea_lantern" => vec![it("prismarine_crystals", 2 + rng.next_i32_bounded(3))],
        "glass" | "ice" | "packed_ice" | "blue_ice" | "spawner" => vec![],
        s if s.ends_with("stained_glass") => vec![],
        "bookshelf" => vec![it("book", 3)],
        "melon" => vec![it("melon_slice", 3 + rng.next_i32_bounded(5))],
        "short_grass" | "tall_grass" | "fern" | "large_fern" => {
            if shears { vec![own] } else if rng.next_i32_bounded(8) == 0 { vec![it("wheat_seeds", 1)] } else { vec![] }
        }
        "dead_bush" => if shears { vec![own] } else { vec![it("stick", rng.next_i32_bounded(3))] },
        "cobweb" => vec![it("string", 1)],
        "vine" | "lily_pad_dummy" => if shears { vec![own] } else { vec![] },
        "wheat" => vec![it("wheat", 1), it("wheat_seeds", 1 + rng.next_i32_bounded(3))],
        "carrots" => vec![it("carrot", 1 + rng.next_i32_bounded(4))],
        "potatoes" => vec![it("potato", 1 + rng.next_i32_bounded(4))],
        "beetroots" => vec![it("beetroot", 1), it("beetroot_seeds", rng.next_i32_bounded(3))],
        "sweet_berry_bush" => vec![it("sweet_berries", 2 + rng.next_i32_bounded(2))],
        "tnt" => vec![own],
        "torch" | "soul_torch" | "redstone_torch" => vec![own],
        "pumpkin" | "carved_pumpkin" | "jack_o_lantern" => vec![own],
        n if n.ends_with("_leaves") => {
            if shears {
                return vec![own];
            }
            let sapling = n.replace("_leaves", "_sapling");
            let mut v = Vec::new();
            let base = [20, 16, 12, 10][fortune.min(3) as usize];
            if let Some(s) = ItemId::from_name(&sapling) {
                if rng.next_i32_bounded(base) == 0 {
                    v.push(ItemStack::new(s, 1));
                }
            }
            if rng.next_i32_bounded(20) == 0 {
                v.push(it("stick", 1 + rng.next_i32_bounded(2)));
            }
            if n == "oak_leaves" || n == "dark_oak_leaves" {
                if rng.next_i32_bounded([200, 180, 160, 120][fortune.min(3) as usize]) == 0 {
                    v.push(it("apple", 1));
                }
            }
            v
        }
        _ => vec![own],
    }
}

/// Durability cost of breaking a block with the tool (swords 2, other tools 1, none for 0-hardness).
pub fn tool_wear_for_break(block: BlockId, t: Option<&ItemInfo>) -> u16 {
    match t {
        Some(t) if t.durability > 0 && block.hardness() > 0.0 => if t.tool == tool::SWORD { 2 } else { 1 },
        _ => 0,
    }
}

/// Melee damage of an attack with the held item at full charge.
pub fn attack_damage(t: Option<&ItemInfo>, effects: &ActiveEffects, sharpness: u8, critical: bool) -> f32 {
    let base = t.map_or(1.0, |t| t.attack_damage.max(1.0));
    let mut d = (base + crate::effects::sharpness_bonus(sharpness)) * effects.damage_multiplier();
    if critical {
        d *= 1.5;
    }
    d
}

#[cfg(test)]
mod tests {
    use super::*;

    fn info(n: &str) -> ItemInfo {
        ItemId::of(n).info().clone()
    }

    #[test]
    fn stone_with_pickaxes_matches_vanilla_times() {
        let ctx = MiningContext { on_ground: true, ..Default::default() };
        let hand = break_ticks(BlockId::STONE, None, &ctx).unwrap();
        let wood = break_ticks(BlockId::STONE, Some(&info("wooden_pickaxe")), &ctx).unwrap();
        let iron = break_ticks(BlockId::STONE, Some(&info("iron_pickaxe")), &ctx).unwrap();
        let dia = break_ticks(BlockId::STONE, Some(&info("diamond_pickaxe")), &ctx).unwrap();
        assert_eq!(hand, 150); // 7.5 s bare handed
        assert_eq!(wood, 23); // 1.15 s
        assert_eq!(iron, 8); // 0.4 s
        assert_eq!(dia, 6); // 0.3 s
    }

    #[test]
    fn obsidian_and_bedrock() {
        let ctx = MiningContext { on_ground: true, ..Default::default() };
        assert_eq!(break_ticks(BlockId::BEDROCK, None, &ctx), None);
        assert_eq!(break_ticks(BlockId::OBSIDIAN, Some(&info("diamond_pickaxe")), &ctx), Some(188)); // 9.4 s like vanilla
        let c = MiningContext { creative: true, ..ctx };
        assert_eq!(break_ticks(BlockId::OBSIDIAN, None, &c), Some(0));
        assert!(!can_harvest(BlockId::DIAMOND_ORE, Some(&info("stone_pickaxe"))));
        assert!(can_harvest(BlockId::DIAMOND_ORE, Some(&info("iron_pickaxe"))));
    }

    #[test]
    fn penalties_and_enchants() {
        let base = MiningContext { on_ground: true, ..Default::default() };
        let t = info("iron_pickaxe");
        let a = destroy_speed(BlockId::STONE, Some(&t), &base);
        let water = destroy_speed(BlockId::STONE, Some(&t), &MiningContext { in_water: true, ..base });
        let air = destroy_speed(BlockId::STONE, Some(&t), &MiningContext { on_ground: false, ..base });
        assert!((a / 5.0 - water).abs() < 1e-4 && (a / 5.0 - air).abs() < 1e-4);
        let eff = destroy_speed(BlockId::STONE, Some(&t), &MiningContext { efficiency: 3, ..base });
        assert_eq!(eff, 6.0 + 10.0);
    }

    #[test]
    fn drops_follow_rules() {
        let mut rng = JavaRandom::new(1);
        let ctx = MiningContext::default();
        let pick = info("wooden_pickaxe");
        assert_eq!(drops(BlockId::STONE, Some(&pick), &ctx, &mut rng)[0].item, ItemId::of("cobblestone"));
        assert!(drops(BlockId::STONE, None, &ctx, &mut rng).is_empty());
        assert_eq!(drops(BlockId::GRASS_BLOCK, None, &ctx, &mut rng)[0].item, ItemId::of("dirt"));
        let silk = MiningContext { silk_touch: true, ..ctx };
        assert_eq!(drops(BlockId::GRASS_BLOCK, None, &silk, &mut rng)[0].item, ItemId::of("grass_block"));
        let iron = info("iron_pickaxe");
        assert_eq!(drops(BlockId::DIAMOND_ORE, Some(&iron), &ctx, &mut rng)[0].item, ItemId::of("diamond"));
        assert_eq!(tool_wear_for_break(BlockId::STONE, Some(&iron)), 1);
        assert_eq!(attack_damage(Some(&info("diamond_sword")), &ActiveEffects::default(), 0, false), 7.0);
    }
}
