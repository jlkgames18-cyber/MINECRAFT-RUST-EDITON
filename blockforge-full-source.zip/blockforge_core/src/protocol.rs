//! Network protocol primitives for Java Edition 1.21.11 (protocol 774).
//!
//! Provides `VarInt`/`VarLong`, strings, positions, a zero-copy-ish [`PacketBuf`],
//! frame (length-prefixed) encode/decode, the handshake packet and the server-list-ping
//! status response. Encryption / compression / play packets are intentionally left to the
//! game layer built on top of this core.

use crate::math::BlockPos;
use std::fmt;

pub const PROTOCOL_VERSION: i32 = 774;
pub const VERSION_NAME: &str = "1.21.11";
pub const DATA_VERSION: i32 = 4671;
pub const DEFAULT_PORT: u16 = 25565;
pub const TICKS_PER_SECOND: u32 = 20;

#[derive(Debug, PartialEq, Eq, Clone)]
pub enum ProtocolError {
    UnexpectedEof,
    VarIntTooLong,
    InvalidUtf8,
    StringTooLong { max: usize, got: usize },
    InvalidState(i32),
    InvalidPacket(i32),
}

impl fmt::Display for ProtocolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ProtocolError::UnexpectedEof => write!(f, "unexpected end of buffer"),
            ProtocolError::VarIntTooLong => write!(f, "varint too long"),
            ProtocolError::InvalidUtf8 => write!(f, "invalid utf-8 in string"),
            ProtocolError::StringTooLong { max, got } => write!(f, "string too long ({got} > {max})"),
            ProtocolError::InvalidState(s) => write!(f, "invalid next state {s}"),
            ProtocolError::InvalidPacket(id) => write!(f, "unexpected packet id {id}"),
        }
    }
}

impl std::error::Error for ProtocolError {}

pub type Result<T> = std::result::Result<T, ProtocolError>;

/// Growable write buffer + read cursor.
#[derive(Default, Clone, Debug)]
pub struct PacketBuf {
    data: Vec<u8>,
    pos: usize,
}

impl PacketBuf {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn with_capacity(n: usize) -> Self {
        Self { data: Vec::with_capacity(n), pos: 0 }
    }
    pub fn from_vec(data: Vec<u8>) -> Self {
        Self { data, pos: 0 }
    }
    pub fn as_slice(&self) -> &[u8] {
        &self.data
    }
    pub fn into_vec(self) -> Vec<u8> {
        self.data
    }
    pub fn len(&self) -> usize {
        self.data.len()
    }
    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }
    pub fn remaining(&self) -> usize {
        self.data.len() - self.pos
    }
    pub fn clear(&mut self) {
        self.data.clear();
        self.pos = 0;
    }

    // ---- writers ----------------------------------------------------------------------
    #[inline]
    pub fn write_u8(&mut self, v: u8) {
        self.data.push(v);
    }
    #[inline]
    pub fn write_bool(&mut self, v: bool) {
        self.data.push(v as u8);
    }
    #[inline]
    pub fn write_i16(&mut self, v: i16) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_u16(&mut self, v: u16) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_i32(&mut self, v: i32) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_i64(&mut self, v: i64) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_f32(&mut self, v: f32) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_f64(&mut self, v: f64) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    pub fn write_bytes(&mut self, b: &[u8]) {
        self.data.extend_from_slice(b);
    }
    pub fn write_uuid(&mut self, v: u128) {
        self.data.extend_from_slice(&v.to_be_bytes());
    }
    #[inline]
    pub fn write_varint(&mut self, v: i32) {
        let mut v = v as u32;
        loop {
            if v & !0x7F == 0 {
                self.data.push(v as u8);
                return;
            }
            self.data.push((v & 0x7F) as u8 | 0x80);
            v >>= 7;
        }
    }
    #[inline]
    pub fn write_varlong(&mut self, v: i64) {
        let mut v = v as u64;
        loop {
            if v & !0x7F == 0 {
                self.data.push(v as u8);
                return;
            }
            self.data.push((v & 0x7F) as u8 | 0x80);
            v >>= 7;
        }
    }
    pub fn write_string(&mut self, s: &str) {
        self.write_varint(s.len() as i32);
        self.data.extend_from_slice(s.as_bytes());
    }
    pub fn write_position(&mut self, p: BlockPos) {
        self.write_i64(p.pack());
    }

    // ---- readers ----------------------------------------------------------------------
    #[inline]
    fn take(&mut self, n: usize) -> Result<&[u8]> {
        if self.remaining() < n {
            return Err(ProtocolError::UnexpectedEof);
        }
        let s = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }
    pub fn read_u8(&mut self) -> Result<u8> {
        Ok(self.take(1)?[0])
    }
    pub fn read_bool(&mut self) -> Result<bool> {
        Ok(self.read_u8()? != 0)
    }
    pub fn read_u16(&mut self) -> Result<u16> {
        let b = self.take(2)?;
        Ok(u16::from_be_bytes([b[0], b[1]]))
    }
    pub fn read_i16(&mut self) -> Result<i16> {
        Ok(self.read_u16()? as i16)
    }
    pub fn read_i32(&mut self) -> Result<i32> {
        let b = self.take(4)?;
        Ok(i32::from_be_bytes([b[0], b[1], b[2], b[3]]))
    }
    pub fn read_i64(&mut self) -> Result<i64> {
        let b = self.take(8)?;
        let mut a = [0u8; 8];
        a.copy_from_slice(b);
        Ok(i64::from_be_bytes(a))
    }
    pub fn read_f32(&mut self) -> Result<f32> {
        Ok(f32::from_bits(self.read_i32()? as u32))
    }
    pub fn read_f64(&mut self) -> Result<f64> {
        Ok(f64::from_bits(self.read_i64()? as u64))
    }
    pub fn read_uuid(&mut self) -> Result<u128> {
        let b = self.take(16)?;
        let mut a = [0u8; 16];
        a.copy_from_slice(b);
        Ok(u128::from_be_bytes(a))
    }
    pub fn read_varint(&mut self) -> Result<i32> {
        let mut result: u32 = 0;
        for i in 0..5 {
            let b = self.read_u8()?;
            result |= ((b & 0x7F) as u32) << (7 * i);
            if b & 0x80 == 0 {
                return Ok(result as i32);
            }
        }
        Err(ProtocolError::VarIntTooLong)
    }
    pub fn read_varlong(&mut self) -> Result<i64> {
        let mut result: u64 = 0;
        for i in 0..10 {
            let b = self.read_u8()?;
            result |= ((b & 0x7F) as u64) << (7 * i);
            if b & 0x80 == 0 {
                return Ok(result as i64);
            }
        }
        Err(ProtocolError::VarIntTooLong)
    }
    pub fn read_string(&mut self, max_chars: usize) -> Result<String> {
        let len = self.read_varint()?;
        if len < 0 {
            return Err(ProtocolError::UnexpectedEof);
        }
        let len = len as usize;
        // UTF-8 can use up to 3 bytes per UTF-16 code unit.
        if len > max_chars * 3 {
            return Err(ProtocolError::StringTooLong { max: max_chars * 3, got: len });
        }
        let bytes = self.take(len)?.to_vec();
        let s = String::from_utf8(bytes).map_err(|_| ProtocolError::InvalidUtf8)?;
        if s.chars().count() > max_chars {
            return Err(ProtocolError::StringTooLong { max: max_chars, got: s.chars().count() });
        }
        Ok(s)
    }
    pub fn read_position(&mut self) -> Result<BlockPos> {
        Ok(BlockPos::unpack(self.read_i64()?))
    }
}

/// Wraps a packet body (`id` + payload) in the length-prefixed frame.
pub fn encode_frame(packet_id: i32, body: &PacketBuf) -> Vec<u8> {
    let mut inner = PacketBuf::with_capacity(body.len() + 5);
    inner.write_varint(packet_id);
    inner.write_bytes(body.as_slice());
    let mut out = PacketBuf::with_capacity(inner.len() + 5);
    out.write_varint(inner.len() as i32);
    out.write_bytes(inner.as_slice());
    out.into_vec()
}

/// Tries to extract one frame from `input`. Returns `(packet_id, payload, bytes_consumed)`
/// or `Ok(None)` when more bytes are needed.
pub fn decode_frame(input: &[u8]) -> Result<Option<(i32, PacketBuf, usize)>> {
    let mut b = PacketBuf::from_vec(input.to_vec());
    let len = match b.read_varint() {
        Ok(l) => l as usize,
        Err(ProtocolError::UnexpectedEof) => return Ok(None),
        Err(e) => return Err(e),
    };
    let header = b.pos;
    if b.remaining() < len {
        return Ok(None);
    }
    let id = b.read_varint()?;
    let payload_start = b.pos;
    let payload = input[payload_start..header + len].to_vec();
    Ok(Some((id, PacketBuf::from_vec(payload), header + len)))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NextState {
    Status,
    Login,
    Transfer,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Handshake {
    pub protocol: i32,
    pub address: String,
    pub port: u16,
    pub next_state: NextState,
}

impl Handshake {
    pub const PACKET_ID: i32 = 0x00;

    pub fn decode(buf: &mut PacketBuf) -> Result<Self> {
        let protocol = buf.read_varint()?;
        let address = buf.read_string(255)?;
        let port = buf.read_u16()?;
        let next_state = match buf.read_varint()? {
            1 => NextState::Status,
            2 => NextState::Login,
            3 => NextState::Transfer,
            s => return Err(ProtocolError::InvalidState(s)),
        };
        Ok(Self { protocol, address, port, next_state })
    }

    pub fn encode(&self) -> PacketBuf {
        let mut b = PacketBuf::new();
        b.write_varint(self.protocol);
        b.write_string(&self.address);
        b.write_u16(self.port);
        b.write_varint(match self.next_state {
            NextState::Status => 1,
            NextState::Login => 2,
            NextState::Transfer => 3,
        });
        b
    }
}

/// JSON body of the status response (server list ping).
pub fn status_response_json(motd: &str, online: u32, max: u32) -> String {
    let esc: String = motd
        .chars()
        .flat_map(|c| match c {
            '"' => vec!['\\', '"'],
            '\\' => vec!['\\', '\\'],
            '\n' => vec!['\\', 'n'],
            c => vec![c],
        })
        .collect();
    format!(
        "{{\"version\":{{\"name\":\"{VERSION_NAME}\",\"protocol\":{PROTOCOL_VERSION}}},\"players\":{{\"max\":{max},\"online\":{online}}},\"description\":{{\"text\":\"{esc}\"}}}}"
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn varint_known_encodings() {
        let cases: &[(i32, &[u8])] = &[
            (0, &[0x00]),
            (1, &[0x01]),
            (127, &[0x7f]),
            (128, &[0x80, 0x01]),
            (255, &[0xff, 0x01]),
            (25565, &[0xdd, 0xc7, 0x01]),
            (2147483647, &[0xff, 0xff, 0xff, 0xff, 0x07]),
            (-1, &[0xff, 0xff, 0xff, 0xff, 0x0f]),
            (-2147483648, &[0x80, 0x80, 0x80, 0x80, 0x08]),
        ];
        for (v, bytes) in cases {
            let mut b = PacketBuf::new();
            b.write_varint(*v);
            assert_eq!(b.as_slice(), *bytes, "encode {v}");
            assert_eq!(PacketBuf::from_vec(bytes.to_vec()).read_varint().unwrap(), *v);
        }
    }

    #[test]
    fn varlong_roundtrip() {
        for v in [0i64, 1, -1, i64::MAX, i64::MIN, 123456789012345] {
            let mut b = PacketBuf::new();
            b.write_varlong(v);
            assert_eq!(b.read_varlong().unwrap(), v);
        }
    }

    #[test]
    fn varint_too_long_is_error() {
        let mut b = PacketBuf::from_vec(vec![0x80; 6]);
        assert_eq!(b.read_varint(), Err(ProtocolError::VarIntTooLong));
    }

    #[test]
    fn string_roundtrip_and_limit() {
        let mut b = PacketBuf::new();
        b.write_string("héllo ⛏");
        assert_eq!(b.read_string(32).unwrap(), "héllo ⛏");
        let mut b = PacketBuf::new();
        b.write_string(&"a".repeat(100));
        assert!(b.read_string(10).is_err());
    }

    #[test]
    fn handshake_roundtrip_via_frame() {
        let hs = Handshake { protocol: PROTOCOL_VERSION, address: "localhost".into(), port: DEFAULT_PORT, next_state: NextState::Status };
        let frame = encode_frame(Handshake::PACKET_ID, &hs.encode());
        let (id, mut payload, used) = decode_frame(&frame).unwrap().unwrap();
        assert_eq!(id, 0);
        assert_eq!(used, frame.len());
        assert_eq!(Handshake::decode(&mut payload).unwrap(), hs);
        // partial frame needs more data
        assert!(decode_frame(&frame[..frame.len() - 1]).unwrap().is_none());
    }

    #[test]
    fn status_json_has_protocol() {
        let j = status_response_json("A \"test\" server", 1, 20);
        assert!(j.contains("\"protocol\":774"));
        assert!(j.contains("1.21.11"));
        assert!(j.contains("\\\"test\\\""));
    }
}
