//! Player inventory: 36 slots (0–8 hotbar), 4 armour slots, off-hand, stack merging and tools wear.

use crate::item::ItemId;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct ItemStack {
    pub item: ItemId,
    pub count: u8,
    /// Durability points used.
    pub damage: u16,
}

impl ItemStack {
    pub const EMPTY: ItemStack = ItemStack { item: ItemId(0), count: 0, damage: 0 };
    pub fn new(item: ItemId, count: u8) -> Self {
        if item.is_air() || count == 0 { Self::EMPTY } else { Self { item, count: count.min(item.max_stack()), damage: 0 } }
    }
    pub fn is_empty(&self) -> bool {
        self.item.is_air() || self.count == 0
    }
    pub fn can_merge(&self, o: &ItemStack) -> bool {
        self.item == o.item && self.item.max_stack() > 1 && self.damage == o.damage
    }
    pub fn durability_left(&self) -> Option<u16> {
        let d = self.item.info().durability;
        (d > 0).then(|| d.saturating_sub(self.damage))
    }
}

pub const HOTBAR: usize = 9;
pub const SLOTS: usize = 36;

#[derive(Clone, Debug)]
pub struct Inventory {
    pub slots: [ItemStack; SLOTS],
    pub armor: [ItemStack; 4], // boots, leggings, chestplate, helmet
    pub offhand: ItemStack,
    pub selected: usize,
}

impl Default for Inventory {
    fn default() -> Self {
        Self { slots: [ItemStack::EMPTY; SLOTS], armor: [ItemStack::EMPTY; 4], offhand: ItemStack::EMPTY, selected: 0 }
    }
}

impl Inventory {
    pub fn selected_stack(&self) -> &ItemStack {
        &self.slots[self.selected]
    }
    pub fn select(&mut self, slot: usize) {
        self.selected = slot.min(HOTBAR - 1);
    }
    pub fn scroll(&mut self, delta: i32) {
        self.selected = (self.selected as i32 - delta).rem_euclid(HOTBAR as i32) as usize;
    }

    /// Adds a stack; returns what did not fit.
    pub fn add(&mut self, mut stack: ItemStack) -> ItemStack {
        if stack.is_empty() {
            return ItemStack::EMPTY;
        }
        let max = stack.item.max_stack();
        // top up existing stacks first (hotbar first, then main inventory)
        for s in self.slots.iter_mut() {
            if !s.is_empty() && s.can_merge(&stack) && s.count < max {
                let n = (max - s.count).min(stack.count);
                s.count += n;
                stack.count -= n;
                if stack.count == 0 {
                    return ItemStack::EMPTY;
                }
            }
        }
        for s in self.slots.iter_mut() {
            if s.is_empty() {
                let n = max.min(stack.count);
                *s = ItemStack { count: n, ..stack };
                stack.count -= n;
                if stack.count == 0 {
                    return ItemStack::EMPTY;
                }
            }
        }
        stack
    }

    pub fn count_of(&self, item: ItemId) -> u32 {
        self.slots.iter().filter(|s| s.item == item).map(|s| s.count as u32).sum()
    }

    /// Removes up to `n` items, returns the number actually removed.
    pub fn take(&mut self, item: ItemId, mut n: u32) -> u32 {
        let want = n;
        for s in self.slots.iter_mut().rev() {
            if s.item == item && n > 0 {
                let t = (s.count as u32).min(n);
                s.count -= t as u8;
                n -= t;
                if s.count == 0 {
                    *s = ItemStack::EMPTY;
                }
            }
        }
        want - n
    }

    /// Uses one item of the selected slot (placing a block, eating). Returns the item used.
    pub fn consume_selected(&mut self) -> Option<ItemId> {
        let s = &mut self.slots[self.selected];
        if s.is_empty() {
            return None;
        }
        let it = s.item;
        s.count -= 1;
        if s.count == 0 {
            *s = ItemStack::EMPTY;
        }
        Some(it)
    }

    /// Wears the selected tool by `amount` (Unbreaking is applied by the caller). True when it broke.
    pub fn damage_selected(&mut self, amount: u16) -> bool {
        let s = &mut self.slots[self.selected];
        let max = s.item.info().durability;
        if s.is_empty() || max == 0 {
            return false;
        }
        s.damage = s.damage.saturating_add(amount);
        if s.damage >= max {
            *s = ItemStack::EMPTY;
            return true;
        }
        false
    }

    pub fn swap(&mut self, a: usize, b: usize) {
        self.slots.swap(a.min(SLOTS - 1), b.min(SLOTS - 1));
    }

    /// Splits half of a stack off (right click in a GUI). Returns the taken half.
    pub fn split_half(&mut self, slot: usize) -> ItemStack {
        let s = &mut self.slots[slot];
        if s.is_empty() {
            return ItemStack::EMPTY;
        }
        let take = s.count.div_ceil(2);
        let out = ItemStack { count: take, ..*s };
        s.count -= take;
        if s.count == 0 {
            *s = ItemStack::EMPTY;
        }
        out
    }

    /// Equips an armour item from the selected slot into its armour slot (swapping).
    pub fn equip_selected(&mut self) -> bool {
        let sel = self.slots[self.selected];
        let Some(slot) = sel.item.info().armor_slot else { return false };
        std::mem::swap(&mut self.armor[slot as usize], &mut self.slots[self.selected]);
        true
    }

    pub fn armor_points(&self) -> f32 {
        self.armor.iter().filter(|s| !s.is_empty()).map(|s| s.item.info().armor_points as f32).sum()
    }
    pub fn armor_toughness(&self) -> f32 {
        self.armor.iter().filter(|s| !s.is_empty()).map(|s| s.item.info().toughness).sum()
    }
    pub fn clear(&mut self) {
        *self = Inventory::default();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stacking_and_overflow() {
        let mut inv = Inventory::default();
        let stone = ItemId::of("stone");
        assert!(inv.add(ItemStack::new(stone, 64)).is_empty());
        assert!(inv.add(ItemStack::new(stone, 10)).is_empty());
        assert_eq!(inv.count_of(stone), 74);
        assert_eq!(inv.slots[0].count, 64);
        assert_eq!(inv.slots[1].count, 10);
        // fill everything
        let dirt = ItemId::of("dirt");
        let rest = inv.add(ItemStack::new(dirt, 64));
        assert!(rest.is_empty());
        for _ in 0..40 {
            inv.add(ItemStack::new(dirt, 64));
        }
        assert!(!inv.add(ItemStack::new(dirt, 64)).is_empty(), "inventory should be full");
    }

    #[test]
    fn tools_do_not_stack_and_break() {
        let mut inv = Inventory::default();
        let pick = ItemId::of("wooden_pickaxe");
        inv.add(ItemStack::new(pick, 1));
        inv.add(ItemStack::new(pick, 1));
        assert!(!inv.slots[1].is_empty());
        for _ in 0..58 {
            assert!(!inv.damage_selected(1));
        }
        assert!(inv.damage_selected(1));
        assert!(inv.slots[0].is_empty());
    }

    #[test]
    fn take_consume_equip() {
        let mut inv = Inventory::default();
        inv.add(ItemStack::new(ItemId::of("oak_planks"), 20));
        assert_eq!(inv.take(ItemId::of("oak_planks"), 5), 5);
        assert_eq!(inv.consume_selected(), Some(ItemId::of("oak_planks")));
        assert_eq!(inv.count_of(ItemId::of("oak_planks")), 14);
        inv.add(ItemStack::new(ItemId::of("diamond_chestplate"), 1));
        inv.select(1);
        assert!(inv.equip_selected());
        assert_eq!(inv.armor_points(), 8.0);
        assert_eq!(inv.armor_toughness(), 2.0);
        inv.scroll(1);
        assert_eq!(inv.selected, 0);
        let half = inv.split_half(0);
        assert_eq!(half.count, 7);
    }
}
