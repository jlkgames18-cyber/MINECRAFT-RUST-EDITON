//! Day / night clock, moon phases and weather (rain + thunder state machine).

use crate::rng::{JavaRandom, RandomSource};

pub const DAY_LENGTH: u64 = 24_000;

#[derive(Clone, Debug)]
pub struct GameClock {
    pub game_time: u64,
    pub day_time: u64,
    pub do_daylight_cycle: bool,
}

impl Default for GameClock {
    fn default() -> Self {
        Self { game_time: 0, day_time: 1000, do_daylight_cycle: true }
    }
}

impl GameClock {
    pub fn tick(&mut self) {
        self.game_time += 1;
        if self.do_daylight_cycle {
            self.day_time += 1;
        }
    }
    pub fn time_of_day(&self) -> u64 {
        self.day_time % DAY_LENGTH
    }
    pub fn day_number(&self) -> u64 {
        self.day_time / DAY_LENGTH
    }
    pub fn is_day(&self) -> bool {
        self.time_of_day() < 13_000
    }
    pub fn is_night(&self) -> bool {
        !self.is_day()
    }
    /// 0 = full moon … 4 = new moon (vanilla order).
    pub fn moon_phase(&self) -> u8 {
        (self.day_number() % 8) as u8
    }
    /// Sun angle in radians (0 = rising on the east horizon, π/2 = zenith at noon).
    pub fn sun_angle(&self) -> f32 {
        let t = ((self.time_of_day() + 18_000) % DAY_LENGTH) as f32 / DAY_LENGTH as f32;
        // celestial angle 0 = noon; convert so noon (t=0) → π/2
        std::f32::consts::FRAC_PI_2 + t * std::f32::consts::TAU
    }
    pub fn set_named(&mut self, name: &str) -> bool {
        let t = match name {
            "day" => 1000,
            "noon" => 6000,
            "sunset" | "dusk" => 12_000,
            "night" => 13_000,
            "midnight" => 18_000,
            "sunrise" | "dawn" => 23_000,
            _ => return false,
        };
        self.day_time = self.day_number() * DAY_LENGTH + t;
        true
    }
    pub fn can_sleep(&self, thundering: bool) -> bool {
        self.time_of_day() >= 12_542 && self.time_of_day() < 23_460 || thundering
    }
    /// Skips to the next morning (what sleeping does).
    pub fn skip_to_morning(&mut self) {
        self.day_time = (self.day_number() + 1) * DAY_LENGTH;
    }
}

#[derive(Clone, Debug)]
pub struct Weather {
    pub raining: bool,
    pub thundering: bool,
    pub rain_time: i32,
    pub thunder_time: i32,
    pub clear_time: i32,
    pub rain_level: f32,
    pub thunder_level: f32,
    rng: JavaRandom,
}

impl Weather {
    pub fn new(seed: i64) -> Self {
        let mut rng = JavaRandom::new(seed ^ 0x57EA7);
        let clear = 12_000 + rng.next_i32_bounded(168_000);
        Self { raining: false, thundering: false, rain_time: 0, thunder_time: 0, clear_time: clear, rain_level: 0.0, thunder_level: 0.0, rng }
    }
    pub fn set_clear(&mut self, ticks: i32) {
        self.clear_time = ticks;
        self.rain_time = 0;
        self.thunder_time = 0;
        self.raining = false;
        self.thundering = false;
    }
    pub fn set_rain(&mut self, ticks: i32) {
        self.clear_time = 0;
        self.rain_time = ticks;
        self.thunder_time = ticks;
        self.raining = true;
        self.thundering = false;
    }
    pub fn set_thunder(&mut self, ticks: i32) {
        self.clear_time = 0;
        self.rain_time = ticks;
        self.thunder_time = ticks;
        self.raining = true;
        self.thundering = true;
    }
    /// Vanilla-like state machine, one call per tick.
    pub fn tick(&mut self) {
        if self.clear_time > 0 {
            self.clear_time -= 1;
            self.thunder_time = if self.thundering { 0 } else { 1 };
            self.rain_time = if self.raining { 0 } else { 1 };
            self.thundering = false;
            self.raining = false;
        } else {
            if self.thunder_time > 0 {
                self.thunder_time -= 1;
                if self.thunder_time == 0 {
                    self.thundering = !self.thundering;
                }
            } else {
                self.thunder_time = if self.thundering { 3_600 + self.rng.next_i32_bounded(12_000) } else { 12_000 + self.rng.next_i32_bounded(168_000) };
            }
            if self.rain_time > 0 {
                self.rain_time -= 1;
                if self.rain_time == 0 {
                    self.raining = !self.raining;
                }
            } else {
                self.rain_time = if self.raining { 12_000 + self.rng.next_i32_bounded(12_000) } else { 12_000 + self.rng.next_i32_bounded(168_000) };
            }
        }
        // smooth fade like the client does
        let fade = |level: f32, on: bool| (level + if on { 0.01 } else { -0.01 }).clamp(0.0, 1.0);
        self.rain_level = fade(self.rain_level, self.raining);
        self.thunder_level = fade(self.thunder_level, self.thundering);
    }
    /// Lightning strike probability per chunk per tick while thundering (vanilla 1 / 100 000).
    pub fn lightning_chance(&self) -> f64 {
        if self.thundering { 1.0 / 100_000.0 } else { 0.0 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clock_cycles() {
        let mut c = GameClock::default();
        assert!(c.is_day());
        for _ in 0..12_500 {
            c.tick();
        }
        assert!(c.is_night());
        assert!(c.set_named("noon"));
        assert_eq!(c.time_of_day(), 6000);
        assert!(!c.set_named("lunch"));
        c.set_named("midnight");
        assert!(c.can_sleep(false));
        c.skip_to_morning();
        assert_eq!(c.time_of_day(), 0);
        assert_eq!(c.moon_phase(), (c.day_number() % 8) as u8);
        c.do_daylight_cycle = false;
        let t = c.day_time;
        c.tick();
        assert_eq!(c.day_time, t);
    }

    #[test]
    fn weather_eventually_changes_and_commands_work() {
        let mut w = Weather::new(5);
        w.set_rain(100);
        for _ in 0..50 {
            w.tick();
        }
        assert!(w.raining && w.rain_level > 0.4);
        w.set_thunder(100);
        w.tick();
        assert!(w.thundering && w.lightning_chance() > 0.0);
        w.set_clear(500);
        for _ in 0..120 {
            w.tick();
        }
        assert!(!w.raining && w.rain_level < 0.01 + 0.0 || w.rain_level < 0.5);
        // a free-running weather system must start raining some time within ~ 20 in-game days
        let mut free = Weather::new(7);
        let mut rained = false;
        for _ in 0..24_000 * 30 {
            free.tick();
            rained |= free.raining;
        }
        assert!(rained);
    }
}
