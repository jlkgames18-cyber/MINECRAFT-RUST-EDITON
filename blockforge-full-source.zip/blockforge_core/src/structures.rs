//! Small procedural structures that fit completely inside one chunk:
//! desert wells, monster dungeons (mossy room + spawner + chests) and surface lava pools.

use crate::biome::BiomeId;
use crate::block::BlockId;
use crate::chunk::Chunk;
use crate::rng::{JavaRandom, RandomSource};
use crate::worldgen::{Column, SEA_LEVEL};

pub fn place_structures(chunk: &mut Chunk, cols: &[Column; 256], rng: &mut JavaRandom, _seed: i64) {
    // ---- desert well ------------------------------------------------------------------
    let (wx, wz) = (3 + rng.next_i32_bounded(10), 3 + rng.next_i32_bounded(10));
    let roll = rng.next_i32_bounded(120);
    let col = cols[((wz as usize) << 4) | wx as usize];
    if roll == 0 && col.biome == BiomeId::Desert && col.height > SEA_LEVEL + 1 {
        place_desert_well(chunk, wx, col.height, wz);
    }

    // ---- dungeon ----------------------------------------------------------------------
    let (dx, dz) = (4 + rng.next_i32_bounded(8), 4 + rng.next_i32_bounded(8));
    let dy = -40 + rng.next_i32_bounded(80);
    if rng.next_i32_bounded(14) == 0 {
        place_dungeon(chunk, dx, dy, dz, rng);
    }
}

pub fn place_desert_well(chunk: &mut Chunk, cx: i32, ground: i32, cz: i32) {
    let s = |c: &mut Chunk, x: i32, y: i32, z: i32, b: BlockId| {
        if (0..16).contains(&x) && (0..16).contains(&z) {
            c.set_block(x as usize, y, z as usize, b);
        }
    };
    for dx in -2..=2 {
        for dz in -2..=2 {
            s(chunk, cx + dx, ground, cz + dz, BlockId::SANDSTONE);
            s(chunk, cx + dx, ground - 1, cz + dz, BlockId::SANDSTONE);
            for y in 1..=4 {
                s(chunk, cx + dx, ground + y, cz + dz, BlockId::AIR);
            }
        }
    }
    for dx in -1..=1 {
        for dz in -1..=1 {
            s(chunk, cx + dx, ground, cz + dz, BlockId::WATER);
            s(chunk, cx + dx, ground - 1, cz + dz, BlockId::WATER);
            s(chunk, cx + dx, ground - 2, cz + dz, BlockId::WATER);
        }
    }
    for (dx, dz) in [(-2, -2), (2, -2), (-2, 2), (2, 2)] {
        s(chunk, cx + dx, ground + 1, cz + dz, BlockId::SANDSTONE);
        s(chunk, cx + dx, ground + 2, cz + dz, BlockId::SANDSTONE);
    }
    for (dx, dz) in [(-1, -2), (0, -2), (1, -2), (-1, 2), (0, 2), (1, 2), (-2, -1), (-2, 0), (-2, 1), (2, -1), (2, 0), (2, 1)] {
        s(chunk, cx + dx, ground + 1, cz + dz, BlockId::CUT_SANDSTONE);
    }
    for dx in -1..=1 {
        for dz in -1..=1 {
            s(chunk, cx + dx, ground + 4, cz + dz, BlockId::SMOOTH_SANDSTONE);
        }
    }
    for (dx, dz) in [(-1, -1), (1, -1), (-1, 1), (1, 1)] {
        s(chunk, cx + dx, ground + 3, cz + dz, BlockId::SANDSTONE);
        s(chunk, cx + dx, ground + 2, cz + dz, BlockId::SANDSTONE);
    }
}

/// 5×4×5 interior room, mossy / plain cobblestone shell, spawner in the middle.
/// Only placed when the whole 7×6×7 box is solid rock so it never opens into a cave.
pub fn place_dungeon(chunk: &mut Chunk, cx: i32, cy: i32, cz: i32, rng: &mut JavaRandom) -> bool {
    for x in cx - 3..=cx + 3 {
        for z in cz - 3..=cz + 3 {
            for y in cy - 1..=cy + 4 {
                if !(0..16).contains(&x) || !(0..16).contains(&z) {
                    return false;
                }
                let b = chunk.get_block(x as usize, y, z as usize);
                if b.is_air() || b.is_liquid() || !b.is_solid() || b == BlockId::BEDROCK {
                    return false;
                }
            }
        }
    }
    for x in cx - 3..=cx + 3 {
        for z in cz - 3..=cz + 3 {
            for y in cy - 1..=cy + 4 {
                let shell = x == cx - 3 || x == cx + 3 || z == cz - 3 || z == cz + 3 || y == cy - 1 || y == cy + 4;
                let id = if shell {
                    if y == cy - 1 && rng.next_i32_bounded(4) != 0 { BlockId::MOSSY_COBBLESTONE } else { BlockId::COBBLESTONE }
                } else {
                    BlockId::AIR
                };
                chunk.set_block(x as usize, y, z as usize, id);
            }
        }
    }
    chunk.set_block(cx as usize, cy, cz as usize, BlockId::SPAWNER);
    for (dx, dz) in [(-2, -2), (2, 2), (-2, 2), (2, -2)] {
        if rng.next_i32_bounded(2) == 0 {
            chunk.set_block((cx + dx) as usize, cy, (cz + dz) as usize, BlockId::CHEST);
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::math::ChunkPos;

    #[test]
    fn dungeon_needs_solid_rock() {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        let mut rng = JavaRandom::new(1);
        assert!(!place_dungeon(&mut c, 8, 10, 8, &mut rng)); // all air
        for x in 0..16 {
            for z in 0..16 {
                for y in -10..30 {
                    c.set_block(x, y, z, BlockId::STONE);
                }
            }
        }
        assert!(place_dungeon(&mut c, 8, 10, 8, &mut rng));
        assert_eq!(c.get_block(8, 10, 8), BlockId::SPAWNER);
        assert_eq!(c.get_block(6, 11, 6), BlockId::AIR);
    }

    #[test]
    fn well_has_water() {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        for x in 0..16 {
            for z in 0..16 {
                for y in 0..=64 {
                    c.set_block(x, y, z, BlockId::SAND);
                }
            }
        }
        place_desert_well(&mut c, 8, 64, 8);
        assert_eq!(c.get_block(8, 64, 8), BlockId::WATER);
        assert_eq!(c.get_block(8, 68, 8), BlockId::SMOOTH_SANDSTONE);
    }
}
