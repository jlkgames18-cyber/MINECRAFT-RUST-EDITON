//! Deterministic terrain generator v2 (noise based, thread safe, allocation light).
//!
//! Pipeline per chunk:
//! 1. continentalness / erosion / detail noise → surface height; rivers carve valleys
//! 2. [`BiomeSource`] resolves one of 40 biomes per column (temperature, humidity, height)
//! 3. stone / deepslate strata, bedrock floor, biome specific surface layers
//!    (sand, red sand + terracotta bands, mud, podzol, snow, packed ice, gravel, clay …)
//! 4. seas to y = 63, ice on frozen oceans
//! 5. caves: cheese caverns + spaghetti tunnels (+ lava below y = −54) with lush / dripstone variants
//! 6. ores with vanilla-like height bands (+ deepslate variants) and stone blobs
//! 7. vegetation: grass, ferns, 20 flower types, cacti, sugar cane, seagrass, kelp, lily pads …
//! 8. trees of 13 kinds, placed *seamlessly across chunk borders* (see [`crate::trees`])
//! 9. small structures (desert wells, dungeons) – see [`crate::structures`]

use crate::biome::{BiomeId, BiomeSource, ColumnInfo};
use crate::block::BlockId;
use crate::chunk::Chunk;
use crate::math::{ChunkPos, MIN_Y};
use crate::noise::OctaveNoise;
use crate::rng::{JavaRandom, RandomSource, Xoroshiro128pp};
use crate::structures;
use crate::trees::{self, ChunkSink, TreeKind};

pub const SEA_LEVEL: i32 = 63;

/// Terrain facts for one world column.
#[derive(Clone, Copy, Debug)]
pub struct Column {
    pub height: i32,
    pub biome: BiomeId,
    pub river: bool,
}

pub struct WorldGenerator {
    seed: i64,
    continental: OctaveNoise,
    erosion: OctaveNoise,
    detail: OctaveNoise,
    surface: OctaveNoise,
    cheese: OctaveNoise,
    spag_a: OctaveNoise,
    spag_b: OctaveNoise,
    cave_biome: OctaveNoise,
    pub biomes: BiomeSource,
}

const BADLANDS_BANDS: [BlockId; 12] = [
    BlockId::TERRACOTTA, BlockId::ORANGE_TERRACOTTA, BlockId::TERRACOTTA, BlockId::YELLOW_TERRACOTTA,
    BlockId::BROWN_TERRACOTTA, BlockId::TERRACOTTA, BlockId::RED_TERRACOTTA, BlockId::WHITE_TERRACOTTA,
    BlockId::TERRACOTTA, BlockId::ORANGE_TERRACOTTA, BlockId::LIGHT_GRAY_TERRACOTTA, BlockId::TERRACOTTA,
];

impl WorldGenerator {
    pub fn new(seed: i64) -> Self {
        let mut r = Xoroshiro128pp::from_seed(seed);
        Self {
            seed,
            continental: OctaveNoise::new(&mut r, 5),
            erosion: OctaveNoise::new(&mut r, 4),
            detail: OctaveNoise::new(&mut r, 6),
            surface: OctaveNoise::new(&mut r, 3),
            cheese: OctaveNoise::new(&mut r, 3),
            spag_a: OctaveNoise::new(&mut r, 2),
            spag_b: OctaveNoise::new(&mut r, 2),
            cave_biome: OctaveNoise::new(&mut r, 2),
            biomes: BiomeSource::new(seed),
        }
    }

    pub fn seed(&self) -> i64 {
        self.seed
    }

    /// `(height, is_river)` of the topmost solid block at a column.
    fn terrain(&self, x: i32, z: i32) -> (i32, bool) {
        let fx = x as f64;
        let fz = z as f64;
        let c = (self.continental.sample2d(fx / 700.0, fz / 700.0) * 2.4).clamp(-1.0, 1.0);
        let e = (self.erosion.sample2d(fx / 320.0 + 1000.0, fz / 320.0 - 1000.0) * 2.2).clamp(-1.0, 1.0);
        let d = self.detail.sample2d(fx / 64.0, fz / 64.0);
        let base = 70.0 + c * 36.0;
        let mountain = ((c - 0.3).max(0.0) * 1.43) * (1.0 - e.abs() * 0.55) * 95.0;
        let mut h = base + mountain + d * (4.0 + (1.0 - e.abs()) * 9.0);

        // rivers: carve a valley along the zero line of a dedicated noise field
        let rd = self.biomes.river_distance(x, z);
        let mut river = false;
        if rd < 0.075 && c > -0.1 && h < 118.0 {
            let f = (1.0 - rd / 0.075).powf(0.6);
            let target = (SEA_LEVEL - 3) as f64;
            if h > target {
                h += (target - h) * f;
            }
            river = rd < 0.05;
        }
        (h.round() as i32, river)
    }

    /// Terrain height (world y of the topmost solid block) at a column.
    pub fn height(&self, x: i32, z: i32) -> i32 {
        self.terrain(x, z).0
    }

    pub fn column(&self, x: i32, z: i32) -> Column {
        let (height, river) = self.terrain(x, z);
        let biome = self.biomes.biome(x, z, ColumnInfo { height, sea_level: SEA_LEVEL, river });
        Column { height, biome, river }
    }

    pub fn biome_at(&self, x: i32, z: i32) -> BiomeId {
        self.column(x, z).biome
    }

    /// `(top, filler)` for a column. Used by both terrain and tree placement so they agree.
    pub fn surface_blocks(&self, b: BiomeId, h: i32, wx: i32, wz: i32) -> (BlockId, BlockId) {
        use BiomeId::*;
        let n = self.surface.sample2d(wx as f64 / 12.0, wz as f64 / 12.0) * 2.0;
        let (mut top, mut fill) = match b {
            Desert => (BlockId::SAND, BlockId::SANDSTONE),
            Badlands => (if n > 0.3 { BlockId::RED_SAND } else { BlockId::COARSE_DIRT }, BlockId::TERRACOTTA),
            Beach | SnowyBeach => (BlockId::SAND, BlockId::SANDSTONE),
            StonyShore => (BlockId::STONE, BlockId::STONE),
            River | FrozenRiver => {
                if n > 0.55 {
                    (BlockId::CLAY, BlockId::CLAY)
                } else if n < -0.2 {
                    (BlockId::GRAVEL, BlockId::GRAVEL)
                } else {
                    (BlockId::SAND, BlockId::SAND)
                }
            }
            Ocean | DeepOcean | ColdOcean | WarmOcean | FrozenOcean => {
                if n > 0.6 {
                    (BlockId::CLAY, BlockId::CLAY)
                } else if b == WarmOcean || (b == Ocean && n > -0.3) {
                    (BlockId::SAND, BlockId::SAND)
                } else {
                    (BlockId::GRAVEL, BlockId::GRAVEL)
                }
            }
            MushroomFields => (BlockId::MYCELIUM, BlockId::DIRT),
            OldGrowthPineTaiga => (BlockId::PODZOL, BlockId::DIRT),
            Taiga => (if n > 0.7 { BlockId::PODZOL } else { BlockId::GRASS_BLOCK }, BlockId::DIRT),
            SnowyPlains | SnowyTaiga | IceSpikes => (BlockId::SNOW_BLOCK, BlockId::DIRT),
            Grove | SnowySlopes => (BlockId::SNOW_BLOCK, BlockId::STONE),
            FrozenPeaks => (if n > 0.3 { BlockId::PACKED_ICE } else { BlockId::SNOW_BLOCK }, BlockId::STONE),
            JaggedPeaks => {
                if h as f64 > 150.0 + n * 6.0 { (BlockId::SNOW_BLOCK, BlockId::STONE) } else { (BlockId::STONE, BlockId::STONE) }
            }
            StonyPeaks => {
                if n > 0.55 {
                    (BlockId::CALCITE, BlockId::STONE)
                } else if n < -0.6 {
                    (BlockId::TUFF, BlockId::STONE)
                } else {
                    (BlockId::STONE, BlockId::STONE)
                }
            }
            WindsweptHills | WindsweptForest => {
                if h as f64 > 100.0 + n * 6.0 {
                    (BlockId::STONE, BlockId::STONE)
                } else if n > 0.8 {
                    (BlockId::GRAVEL, BlockId::GRAVEL)
                } else {
                    (BlockId::GRASS_BLOCK, BlockId::DIRT)
                }
            }
            MangroveSwamp => (BlockId::MUD, BlockId::MUD),
            Savanna | SavannaPlateau => (if n > 0.8 { BlockId::COARSE_DIRT } else { BlockId::GRASS_BLOCK }, BlockId::DIRT),
            _ => (BlockId::GRASS_BLOCK, BlockId::DIRT),
        };
        // bare rock far above the tree line unless the biome is snowy
        if h > 185 && !matches!(b, FrozenPeaks | JaggedPeaks | Grove | SnowySlopes) {
            top = BlockId::STONE;
            fill = BlockId::STONE;
        }
        // soil under water becomes dirt
        if h < SEA_LEVEL && matches!(top, BlockId::GRASS_BLOCK | BlockId::MYCELIUM | BlockId::PODZOL | BlockId::SNOW_BLOCK) {
            top = BlockId::DIRT;
        }
        (top, fill)
    }

    pub fn generate_chunk(&self, pos: ChunkPos) -> Chunk {
        let mut chunk = Chunk::new(pos);
        let bx = pos.min_block_x();
        let bz = pos.min_block_z();

        // Per chunk RNG derived from the seed (same trick vanilla uses for decorators).
        let mut rng = JavaRandom::new(self.chunk_seed(pos));

        let mut cols = [Column { height: 0, biome: BiomeId::Plains, river: false }; 256];
        for lz in 0..16usize {
            for lx in 0..16usize {
                cols[(lz << 4) | lx] = self.column(bx + lx as i32, bz + lz as i32);
            }
        }

        // ---- terrain -------------------------------------------------------------------
        for lz in 0..16usize {
            for lx in 0..16usize {
                let col = cols[(lz << 4) | lx];
                let (wx, wz) = (bx + lx as i32, bz + lz as i32);
                let h = col.height;
                let top = h.max(SEA_LEVEL);
                let jitter = self.surface.sample2d(wx as f64 / 8.0, wz as f64 / 8.0);
                let deepslate_top = ((jitter * 8.0) as i32) - 4; // around y=-4
                let (top_block, filler) = self.surface_blocks(col.biome, h, wx, wz);
                let frozen = matches!(col.biome, BiomeId::FrozenOcean | BiomeId::FrozenRiver);
                let badlands = col.biome == BiomeId::Badlands;

                for y in MIN_Y..=top {
                    let id = if y <= MIN_Y + 4 && (y == MIN_Y || rng.next_i32_bounded(5) > (y - MIN_Y)) {
                        BlockId::BEDROCK
                    } else if y > h {
                        if frozen && y == SEA_LEVEL { BlockId::ICE } else { BlockId::WATER }
                    } else if y == h {
                        top_block
                    } else if badlands && y >= h - 24 && h > SEA_LEVEL {
                        BADLANDS_BANDS[((y + 128 + (jitter * 2.0) as i32) as usize) % 12]
                    } else if y >= h - 3 {
                        filler
                    } else if y < deepslate_top {
                        BlockId::DEEPSLATE
                    } else {
                        BlockId::STONE
                    };
                    chunk.set_block(lx, y, lz, id);
                }
                // biome per 4x4 cell, sampled at the cell centre
                if lx & 3 == 1 && lz & 3 == 1 {
                    chunk.set_column_biome(lx, lz, col.biome as u8);
                }
            }
        }

        self.carve_caves(&mut chunk, &cols, &mut rng);
        self.place_ores(&mut chunk, &cols, &mut rng);
        self.decorate(&mut chunk, &cols, &mut rng);

        // trees: replay the placement of the 3x3 neighbourhood so canopies cross borders
        for dx in -1..=1 {
            for dz in -1..=1 {
                self.trees_from_origin(&mut chunk, ChunkPos::new(pos.x + dx, pos.z + dz));
            }
        }

        structures::place_structures(&mut chunk, &cols, &mut rng, self.seed);

        chunk.rebuild_heightmaps();
        chunk.compact();
        chunk.dirty = false;
        chunk
    }

    fn chunk_seed(&self, pos: ChunkPos) -> i64 {
        self.seed ^ (pos.x as i64).wrapping_mul(341873128712) ^ (pos.z as i64).wrapping_mul(132897987541)
    }

    // ------------------------------------------------------------------------- caves
    fn carve_caves(&self, chunk: &mut Chunk, cols: &[Column; 256], rng: &mut JavaRandom) {
        let bx = chunk.pos.min_block_x();
        let bz = chunk.pos.min_block_z();
        for lz in 0..16usize {
            for lx in 0..16usize {
                let col = cols[(lz << 4) | lx];
                let (wx, wz) = ((bx + lx as i32) as f64, (bz + lz as i32) as f64);
                let ocean = col.height < SEA_LEVEL - 1;
                let cheese_top = (col.height - 10).min(52);
                let spag_top = if ocean { col.height - 8 } else { col.height - 2 };
                let lushness = self.cave_biome.sample2d(wx / 150.0 + 40.0, wz / 150.0) * 2.0;
                let lush = lushness > 0.55;
                let dripstone = lushness < -0.55;
                let mut cave_cells = 0;

                for y in (MIN_Y + 6)..=spag_top.max(MIN_Y + 6) {
                    let cur = chunk.get_block(lx, y, lz);
                    if cur == BlockId::AIR || cur == BlockId::WATER || cur == BlockId::BEDROCK {
                        continue;
                    }
                    let fy = y as f64;
                    let mut carve = false;
                    if y <= cheese_top {
                        // wide caverns, fatter with depth
                        let thr = 0.58 - ((52 - y).clamp(0, 116) as f64) * 0.0011;
                        carve = self.cheese.sample(wx / 34.0, fy / 22.0, wz / 34.0) * 1.9 > thr + 0.35;
                    }
                    if !carve {
                        let a = self.spag_a.sample(wx / 26.0, fy / 20.0, wz / 26.0) * 2.0;
                        if a.abs() < 0.075 {
                            let b = self.spag_b.sample(wx / 26.0 + 100.0, fy / 20.0, wz / 26.0 - 100.0) * 2.0;
                            carve = b.abs() < 0.075;
                        }
                    }
                    if carve {
                        chunk.set_block(lx, y, lz, if y <= -54 { BlockId::LAVA } else { BlockId::AIR });
                        cave_cells += 1;
                    }
                }

                // decorate cave floors / ceilings
                if cave_cells > 0 && (lush || dripstone) {
                    for y in (MIN_Y + 7)..=spag_top.min(100) {
                        let cur = chunk.get_block(lx, y, lz);
                        if cur != BlockId::AIR {
                            continue;
                        }
                        let below = chunk.get_block(lx, y - 1, lz);
                        let above = chunk.get_block(lx, y + 1, lz);
                        let solid_below = matches!(below, BlockId::STONE | BlockId::DEEPSLATE | BlockId::DIRT);
                        let solid_above = matches!(above, BlockId::STONE | BlockId::DEEPSLATE | BlockId::DIRT);
                        if lush {
                            if solid_below {
                                chunk.set_block(lx, y - 1, lz, BlockId::MOSS_BLOCK);
                                let r = rng.next_i32_bounded(10);
                                if r < 3 {
                                    chunk.set_block(lx, y, lz, BlockId::SHORT_GRASS);
                                } else if r == 3 {
                                    chunk.set_block(lx, y, lz, BlockId::SMALL_DRIPLEAF);
                                }
                            }
                            if solid_above && rng.next_i32_bounded(4) == 0 {
                                chunk.set_block(lx, y + 1, lz, BlockId::MOSS_BLOCK);
                                let len = 1 + rng.next_i32_bounded(4);
                                for k in 0..len {
                                    if chunk.get_block(lx, y - k, lz) == BlockId::AIR {
                                        chunk.set_block(lx, y - k, lz, BlockId::CAVE_VINES);
                                    }
                                }
                            }
                        } else {
                            if solid_below && rng.next_i32_bounded(2) == 0 {
                                chunk.set_block(lx, y - 1, lz, BlockId::DRIPSTONE_BLOCK);
                            }
                            if solid_above {
                                chunk.set_block(lx, y + 1, lz, BlockId::DRIPSTONE_BLOCK);
                            }
                        }
                    }
                    if lx & 3 == 1 && lz & 3 == 1 {
                        let b = if lush { BiomeId::LushCaves } else { BiomeId::DripstoneCaves };
                        let top_cell = ((spag_top.min(cheese_top.max(40)) - MIN_Y) >> 2).max(0);
                        for cy in 0..top_cell {
                            chunk.set_biome_cell(lx >> 2, MIN_Y + (cy << 2), lz >> 2, b as u8);
                        }
                    }
                }
            }
        }
    }

    // --------------------------------------------------------------------------- ores
    fn place_ores(&self, chunk: &mut Chunk, cols: &[Column; 256], rng: &mut JavaRandom) {
        // (block, deepslate variant, attempts per chunk, vein size, min_y, max_y)
        const ORES: [(BlockId, BlockId, i32, i32, i32, i32); 7] = [
            (BlockId::COAL_ORE, BlockId::DEEPSLATE_COAL_ORE, 20, 17, 0, 192),
            (BlockId::IRON_ORE, BlockId::DEEPSLATE_IRON_ORE, 20, 9, -64, 72),
            (BlockId::COPPER_ORE, BlockId::DEEPSLATE_COPPER_ORE, 16, 10, -16, 112),
            (BlockId::GOLD_ORE, BlockId::DEEPSLATE_GOLD_ORE, 4, 9, -64, 32),
            (BlockId::REDSTONE_ORE, BlockId::DEEPSLATE_REDSTONE_ORE, 8, 8, -64, 15),
            (BlockId::LAPIS_ORE, BlockId::DEEPSLATE_LAPIS_ORE, 3, 7, -64, 64),
            (BlockId::DIAMOND_ORE, BlockId::DEEPSLATE_DIAMOND_ORE, 7, 4, -64, 16),
        ];
        // stone blobs (replace stone / deepslate)
        const BLOBS: [(BlockId, i32, i32, i32, i32); 6] = [
            (BlockId::DIRT, 10, 33, 0, 160),
            (BlockId::GRAVEL, 8, 33, -64, 64),
            (BlockId::GRANITE, 10, 33, 0, 80),
            (BlockId::DIORITE, 10, 33, 0, 80),
            (BlockId::ANDESITE, 10, 33, 0, 80),
            (BlockId::TUFF, 6, 33, -64, 0),
        ];
        for &(blob, tries, size, min_y, max_y) in &BLOBS {
            for _ in 0..tries {
                self.vein(chunk, rng, blob, blob, size, min_y, max_y);
            }
        }
        for &(ore, deep, tries, size, min_y, max_y) in &ORES {
            for _ in 0..tries {
                self.vein(chunk, rng, ore, deep, size, min_y, max_y);
            }
        }
        // emeralds only in mountains
        let centre = cols[(8 << 4) | 8].biome;
        if centre.is_mountain() {
            for _ in 0..6 {
                self.vein(chunk, rng, BlockId::EMERALD_ORE, BlockId::DEEPSLATE_EMERALD_ORE, 1, 4, 160);
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn vein(&self, chunk: &mut Chunk, rng: &mut JavaRandom, ore: BlockId, deep: BlockId, size: i32, min_y: i32, max_y: i32) {
        let cx = rng.next_i32_bounded(16);
        let cz = rng.next_i32_bounded(16);
        let cy = min_y + rng.next_i32_bounded((max_y - min_y).max(1));
        let r = ((size as f64).cbrt().ceil() as i32).max(1);
        for _ in 0..size * 2 {
            let (x, y, z) = (
                cx + rng.next_i32_bounded(2 * r + 1) - r,
                cy + rng.next_i32_bounded(2 * r + 1) - r,
                cz + rng.next_i32_bounded(2 * r + 1) - r,
            );
            let d2 = (x - cx).pow(2) + (y - cy).pow(2) + (z - cz).pow(2);
            if d2 > r * r + 1 || !(0..16).contains(&x) || !(0..16).contains(&z) {
                continue;
            }
            let cur = chunk.get_block(x as usize, y, z as usize);
            if cur == BlockId::STONE {
                chunk.set_block(x as usize, y, z as usize, ore);
            } else if cur == BlockId::DEEPSLATE {
                chunk.set_block(x as usize, y, z as usize, deep);
            }
        }
    }

    // ---------------------------------------------------------------------- vegetation
    fn decorate(&self, chunk: &mut Chunk, cols: &[Column; 256], rng: &mut JavaRandom) {
        use BiomeId::*;
        // --- land plants ---------------------------------------------------------------
        for _ in 0..56 {
            let x = rng.next_i32_bounded(16) as usize;
            let z = rng.next_i32_bounded(16) as usize;
            let col = cols[(z << 4) | x];
            let h = col.height;
            if h < SEA_LEVEL || h > 190 {
                continue;
            }
            let ground = chunk.get_block(x, h, z);
            if !chunk.get_block(x, h + 1, z).is_air() {
                continue;
            }
            let r = rng.next_f32();
            let r2 = rng.next_i32_bounded(100);
            let grassy = matches!(ground, BlockId::GRASS_BLOCK | BlockId::PODZOL | BlockId::COARSE_DIRT | BlockId::MYCELIUM);
            let plant: Option<(BlockId, bool)> = match col.biome {
                Plains | Meadow | SunflowerPlains | CherryGrove if grassy => {
                    if r < 0.55 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.60 {
                        Some((BlockId::TALL_GRASS, true))
                    } else if r < 0.75 {
                        Some((pick_flower(col.biome, r2), col.biome == SunflowerPlains && r2 < 40))
                    } else {
                        None
                    }
                }
                Forest | BirchForest | DarkForest | WindsweptForest | WindsweptHills | Grove if grassy => {
                    if r < 0.35 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.42 {
                        Some((BlockId::FERN, false))
                    } else if r < 0.46 {
                        Some((BlockId::TALL_GRASS, true))
                    } else if r < 0.5 && col.biome != WindsweptHills {
                        Some((pick_flower(col.biome, r2), false))
                    } else {
                        None
                    }
                }
                FlowerForest if grassy => {
                    if r < 0.2 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.7 {
                        let tall = r2 % 5 == 0;
                        Some((pick_flower(col.biome, r2), tall))
                    } else {
                        None
                    }
                }
                Taiga | SnowyTaiga | OldGrowthPineTaiga if grassy || ground == BlockId::SNOW_BLOCK => {
                    if r < 0.3 {
                        Some((BlockId::FERN, false))
                    } else if r < 0.4 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.42 {
                        Some((BlockId::LARGE_FERN, true))
                    } else if r < 0.45 {
                        Some((BlockId::SWEET_BERRY_BUSH, false))
                    } else if r < 0.5 && !matches!(col.biome, SnowyTaiga) {
                        Some((if r2 < 50 { BlockId::BROWN_MUSHROOM } else { BlockId::RED_MUSHROOM }, false))
                    } else {
                        None
                    }
                }
                Savanna | SavannaPlateau if grassy => {
                    if r < 0.45 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.65 {
                        Some((BlockId::TALL_GRASS, true))
                    } else {
                        None
                    }
                }
                Jungle | SparseJungle | BambooJungle if grassy => {
                    if r < 0.3 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.5 {
                        Some((BlockId::FERN, false))
                    } else if r < 0.58 {
                        Some((BlockId::TALL_GRASS, true))
                    } else if r < 0.7 && col.biome == BambooJungle {
                        Some((BlockId::BAMBOO, true))
                    } else if r < 0.72 {
                        Some((BlockId::MELON, false))
                    } else {
                        None
                    }
                }
                Swamp | MangroveSwamp if grassy => {
                    if r < 0.4 {
                        Some((BlockId::SHORT_GRASS, false))
                    } else if r < 0.5 {
                        Some((BlockId::BLUE_ORCHID, false))
                    } else if r < 0.55 {
                        Some((BlockId::BROWN_MUSHROOM, false))
                    } else {
                        None
                    }
                }
                Desert | Badlands => {
                    if ground == BlockId::SAND || ground == BlockId::RED_SAND || ground == BlockId::COARSE_DIRT {
                        if r < 0.10 {
                            Some((BlockId::DEAD_BUSH, false))
                        } else if r < 0.14 {
                            // cactus needs free sides
                            let free = [(1i32, 0i32), (-1, 0), (0, 1), (0, -1)].iter().all(|&(dx, dz)| {
                                let (nx, nz) = (x as i32 + dx, z as i32 + dz);
                                !(0..16).contains(&nx) || !(0..16).contains(&nz) || chunk.get_block(nx as usize, h + 1, nz as usize).is_air()
                            });
                            if free { Some((BlockId::CACTUS, true)) } else { None }
                        } else {
                            None
                        }
                    } else {
                        None
                    }
                }
                MushroomFields if ground == BlockId::MYCELIUM => {
                    if r < 0.08 {
                        Some((if r2 < 50 { BlockId::BROWN_MUSHROOM } else { BlockId::RED_MUSHROOM }, false))
                    } else {
                        None
                    }
                }
                SnowyPlains | IceSpikes | Beach | StonyShore | River | FrozenRiver => None,
                _ => None,
            };
            if let Some((id, tall)) = plant {
                if id == BlockId::CACTUS {
                    for k in 0..(1 + rng.next_i32_bounded(3)) {
                        chunk.set_block(x, h + 1 + k, z, id);
                    }
                } else if id == BlockId::BAMBOO {
                    for k in 0..(3 + rng.next_i32_bounded(8)) {
                        chunk.set_block(x, h + 1 + k, z, id);
                    }
                } else if id == BlockId::MELON {
                    chunk.set_block(x, h + 1, z, id);
                } else {
                    chunk.set_block(x, h + 1, z, id);
                    if tall && chunk.get_block(x, h + 2, z).is_air() {
                        chunk.set_block(x, h + 2, z, id);
                    }
                }
            }
        }

        // plains pumpkin patch (rare)
        if cols[(8 << 4) | 8].biome == Plains && rng.next_i32_bounded(40) == 0 {
            let (px, pz) = (3 + rng.next_i32_bounded(10) as usize, 3 + rng.next_i32_bounded(10) as usize);
            for _ in 0..6 {
                let x = (px as i32 + rng.next_i32_bounded(5) - 2) as usize;
                let z = (pz as i32 + rng.next_i32_bounded(5) - 2) as usize;
                let h = cols[(z << 4) | x].height;
                if h >= SEA_LEVEL && chunk.get_block(x, h, z) == BlockId::GRASS_BLOCK && chunk.get_block(x, h + 1, z).is_air() {
                    chunk.set_block(x, h + 1, z, BlockId::PUMPKIN);
                }
            }
        }

        // --- sugar cane next to water ---------------------------------------------------
        for _ in 0..14 {
            let x = rng.next_i32_bounded(16) as usize;
            let z = rng.next_i32_bounded(16) as usize;
            let h = cols[(z << 4) | x].height;
            if h != SEA_LEVEL {
                continue;
            }
            let g = chunk.get_block(x, h, z);
            if !matches!(g, BlockId::SAND | BlockId::GRASS_BLOCK | BlockId::DIRT | BlockId::RED_SAND) {
                continue;
            }
            let wet = [(1i32, 0i32), (-1, 0), (0, 1), (0, -1)].iter().any(|&(dx, dz)| {
                let (nx, nz) = (x as i32 + dx, z as i32 + dz);
                (0..16).contains(&nx) && (0..16).contains(&nz) && cols[((nz as usize) << 4) | nx as usize].height < SEA_LEVEL
            });
            if wet && chunk.get_block(x, h + 1, z).is_air() {
                for k in 0..(2 + rng.next_i32_bounded(3)) {
                    chunk.set_block(x, h + 1 + k, z, BlockId::SUGAR_CANE);
                }
            }
        }

        // --- aquatic ----------------------------------------------------------------------
        for _ in 0..40 {
            let x = rng.next_i32_bounded(16) as usize;
            let z = rng.next_i32_bounded(16) as usize;
            let col = cols[(z << 4) | x];
            let h = col.height;
            let r = rng.next_f32();
            if h >= SEA_LEVEL - 1 {
                continue;
            }
            let floor = chunk.get_block(x, h, z);
            if col.biome == Swamp || col.biome == MangroveSwamp {
                if chunk.get_block(x, SEA_LEVEL + 1, z).is_air() && chunk.get_block(x, SEA_LEVEL, z) == BlockId::WATER && r < 0.5 {
                    chunk.set_block(x, SEA_LEVEL + 1, z, BlockId::LILY_PAD);
                }
                continue;
            }
            if !matches!(floor, BlockId::SAND | BlockId::GRAVEL | BlockId::CLAY | BlockId::DIRT) || !col.biome.is_ocean() && col.biome != River {
                continue;
            }
            if col.biome == FrozenOcean || col.biome == FrozenRiver || h < SEA_LEVEL - 32 {
                continue;
            }
            if chunk.get_block(x, h + 1, z) != BlockId::WATER {
                continue;
            }
            if r < 0.5 {
                chunk.set_block(x, h + 1, z, BlockId::SEAGRASS);
            } else if r < 0.7 && col.biome != River {
                let len = (2 + rng.next_i32_bounded(8)).min(SEA_LEVEL - h - 2);
                for k in 0..len {
                    chunk.set_block(x, h + 1 + k, z, BlockId::KELP);
                }
            } else if col.biome == WarmOcean && r < 0.75 {
                chunk.set_block(x, h + 1, z, BlockId::SEA_PICKLE);
            }
        }
    }

    // ------------------------------------------------------------------------- trees
    fn trees_from_origin(&self, chunk: &mut Chunk, origin: ChunkPos) {
        use BiomeId::*;
        let mut r = JavaRandom::new(self.chunk_seed(origin) ^ 0x7EE5_C0DE);
        let (ox, oz) = (origin.min_block_x(), origin.min_block_z());
        for _ in 0..12 {
            // always draw the same amount of randomness per attempt, whatever happens
            let lx = r.next_i32_bounded(16);
            let lz = r.next_i32_bounded(16);
            let roll = r.next_f32();
            let pick = r.next_i32_bounded(100);
            let (wx, wz) = (ox + lx, oz + lz);
            let mut grow_rng = JavaRandom::new(self.seed ^ (wx as i64).wrapping_mul(0x9E3779B1) ^ (wz as i64).wrapping_mul(0x85EBCA6B));

            let col = self.column(wx, wz);
            let h = col.height;
            if h <= SEA_LEVEL || h > 175 {
                continue;
            }
            let kind: Option<TreeKind> = match col.biome {
                Forest => (roll < 0.75).then_some(if pick < 22 { TreeKind::Birch } else if pick < 28 { TreeKind::BigOak } else { TreeKind::Oak }),
                FlowerForest => (roll < 0.45).then_some(if pick < 30 { TreeKind::Birch } else { TreeKind::Oak }),
                BirchForest => (roll < 0.7).then_some(TreeKind::Birch),
                DarkForest => (roll < 0.8).then_some(if pick < 10 { TreeKind::BrownMushroom } else if pick < 18 { TreeKind::RedMushroom } else { TreeKind::DarkOak }),
                Taiga | SnowyTaiga | Grove => (roll < 0.55).then_some(TreeKind::Spruce),
                OldGrowthPineTaiga => (roll < 0.7).then_some(if pick < 45 { TreeKind::Pine } else { TreeKind::Spruce }),
                Plains | SunflowerPlains | Meadow => (roll < 0.035).then_some(TreeKind::Oak),
                Savanna | SavannaPlateau => (roll < 0.14).then_some(TreeKind::Acacia),
                Jungle => (roll < 0.85).then_some(if pick < 15 { TreeKind::BigOak } else { TreeKind::Jungle }),
                SparseJungle => (roll < 0.25).then_some(TreeKind::Jungle),
                BambooJungle => (roll < 0.2).then_some(TreeKind::Jungle),
                Swamp => (roll < 0.25).then_some(TreeKind::Oak),
                MangroveSwamp => (roll < 0.55).then_some(TreeKind::Mangrove),
                CherryGrove => (roll < 0.3).then_some(TreeKind::Cherry),
                WindsweptForest => (roll < 0.35).then_some(if pick < 60 { TreeKind::Spruce } else { TreeKind::Oak }),
                MushroomFields => (roll < 0.12).then_some(if pick < 50 { TreeKind::BrownMushroom } else { TreeKind::RedMushroom }),
                IceSpikes => (roll < 0.06).then_some(TreeKind::IceSpike),
                _ => None,
            };
            let Some(kind) = kind else { continue };
            let (top, _) = self.surface_blocks(col.biome, h, wx, wz);
            if !trees::soil_ok(kind, top) {
                continue;
            }
            // skip when the tree cannot touch this chunk at all
            let reach = trees::max_radius(kind) + 1;
            let (cx0, cz0) = (chunk.pos.min_block_x(), chunk.pos.min_block_z());
            if wx + reach < cx0 || wx - reach > cx0 + 15 || wz + reach < cz0 || wz - reach > cz0 + 15 {
                continue;
            }
            trees::grow(&mut ChunkSink { chunk }, kind, wx, h, wz, &mut grow_rng);
        }
    }
}

fn pick_flower(b: BiomeId, r: i32) -> BlockId {
    use BiomeId::*;
    match b {
        SunflowerPlains if r < 40 => BlockId::SUNFLOWER,
        FlowerForest => [
            BlockId::DANDELION, BlockId::POPPY, BlockId::ALLIUM, BlockId::AZURE_BLUET, BlockId::RED_TULIP,
            BlockId::ORANGE_TULIP, BlockId::WHITE_TULIP, BlockId::PINK_TULIP, BlockId::OXEYE_DAISY,
            BlockId::CORNFLOWER, BlockId::LILY_OF_THE_VALLEY, BlockId::LILAC, BlockId::ROSE_BUSH, BlockId::PEONY,
        ][(r as usize) % 14],
        Forest | BirchForest | DarkForest => {
            [BlockId::LILY_OF_THE_VALLEY, BlockId::ROSE_BUSH, BlockId::LILAC, BlockId::PEONY][(r as usize) % 4]
        }
        Meadow => [BlockId::DANDELION, BlockId::CORNFLOWER, BlockId::AZURE_BLUET, BlockId::ALLIUM, BlockId::OXEYE_DAISY][(r as usize) % 5],
        CherryGrove => BlockId::PINK_PETALS,
        _ => [
            BlockId::DANDELION, BlockId::POPPY, BlockId::AZURE_BLUET, BlockId::OXEYE_DAISY, BlockId::CORNFLOWER,
            BlockId::RED_TULIP, BlockId::ORANGE_TULIP, BlockId::WHITE_TULIP, BlockId::PINK_TULIP,
        ][(r as usize) % 9],
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::chunk::HeightmapKind;

    #[test]
    fn generation_is_deterministic() {
        let g1 = WorldGenerator::new(42);
        let g2 = WorldGenerator::new(42);
        let a = g1.generate_chunk(ChunkPos::new(3, -2));
        let b = g2.generate_chunk(ChunkPos::new(3, -2));
        for y in (-64..200).step_by(5) {
            for x in 0..16 {
                for z in 0..16 {
                    assert_eq!(a.get_block(x, y, z), b.get_block(x, y, z));
                }
            }
        }
    }

    #[test]
    fn different_seeds_differ() {
        let a = WorldGenerator::new(1);
        let b = WorldGenerator::new(2);
        let mut diff = 0;
        for i in 0..64 {
            if a.height(i * 17, i * 31) != b.height(i * 17, i * 31) {
                diff += 1;
            }
        }
        assert!(diff > 32);
    }

    #[test]
    fn terrain_has_bedrock_floor_and_surface() {
        let g = WorldGenerator::new(7);
        let c = g.generate_chunk(ChunkPos::new(0, 0));
        for x in 0..16 {
            for z in 0..16 {
                assert_eq!(c.get_block(x, -64, z), BlockId::BEDROCK);
                assert!(c.height_at(x, z, HeightmapKind::WorldSurface) > SEA_LEVEL - 40);
            }
        }
    }

    #[test]
    fn world_contains_variety() {
        let g = WorldGenerator::new(2024);
        let mut hist = vec![0u64; crate::block::BLOCK_COUNT];
        let mut biomes = std::collections::HashSet::new();
        for cx in -12..12 {
            for cz in -12..12 {
                let c = g.generate_chunk(ChunkPos::new(cx * 5, cz * 5));
                for (i, n) in c.block_histogram().iter().enumerate() {
                    hist[i] += *n as u64;
                }
                biomes.insert(g.biome_at(cx * 80 + 8, cz * 80 + 8));
            }
        }
        let has = |b: BlockId| hist[b.0 as usize] > 0;
        assert!(has(BlockId::STONE) && has(BlockId::DEEPSLATE) && has(BlockId::WATER));
        assert!(has(BlockId::COAL_ORE) && has(BlockId::IRON_ORE) && has(BlockId::DIAMOND_ORE));
        assert!(has(BlockId::OAK_LOG), "no oak trees");
        assert!(has(BlockId::SHORT_GRASS));
        assert!(biomes.len() >= 8, "only {} biomes: {:?}", biomes.len(), biomes);
        let distinct = hist.iter().filter(|&&n| n > 0).count();
        assert!(distinct >= 45, "only {distinct} distinct blocks generated");
    }

    #[test]
    fn caves_exist_below_the_surface() {
        let g = WorldGenerator::new(11);
        let mut air_underground = 0;
        for cx in 0..6 {
            let c = g.generate_chunk(ChunkPos::new(cx, 0));
            for x in 0..16 {
                for z in 0..16 {
                    let h = c.height_at(x, z, HeightmapKind::WorldSurface);
                    for y in -50..(h - 12).min(40) {
                        if c.get_block(x, y, z) == BlockId::AIR {
                            air_underground += 1;
                        }
                    }
                }
            }
        }
        assert!(air_underground > 500, "caves too rare: {air_underground}");
    }

    #[test]
    fn trees_cross_chunk_borders_seamlessly() {
        // log blocks must exist and leaves must reach the very last column of some chunk
        let g = WorldGenerator::new(5);
        let mut edge_leaves = 0;
        for cx in 0..10 {
            for cz in 0..10 {
                let c = g.generate_chunk(ChunkPos::new(cx, cz));
                for i in 0..16 {
                    for y in 60..140 {
                        for (x, z) in [(0, i), (15, i), (i, 0), (i, 15)] {
                            if c.get_block(x, y, z).is_leaves() {
                                edge_leaves += 1;
                            }
                        }
                    }
                }
            }
        }
        assert!(edge_leaves > 0);
    }
}
