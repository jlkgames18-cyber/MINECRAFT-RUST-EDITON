//! Per-chunk light propagation (sky light + block light) with a BFS flood fill.
//!
//! Sky light starts at 15 above the heightmap, falls straight down through transparent blocks
//! without loss (vanilla rule) and floods sideways losing 1 per step. `light_filter` is the amount
//! of light a block *absorbs* (water/leaves/ice = 1, glass = 0, opaque = 15).
//!
//! v2 changes versus the original core:
//! * **bug fix**: transparent blocks used to *block* light (the filter was inverted)
//! * sky light no longer decays when travelling vertically through air
//! * [`compute_chunk_light_with_neighbours`] stitches light across chunk borders
//! * [`sky_brightness`] gives the day/night multiplier used by renderers

use crate::block::BlockId;
use crate::chunk::{nibble_set, Chunk, HeightmapKind};
use crate::math::{MIN_Y, SECTION_COUNT, WORLD_HEIGHT};
use std::collections::VecDeque;

const H: usize = WORLD_HEIGHT as usize;
const VOL: usize = 16 * H * 16;

#[inline(always)]
fn idx(x: usize, y: usize, z: usize) -> usize {
    (y << 8) | (z << 4) | x
}

/// Light lost when entering block `b` (always at least 1 for horizontal / block-light steps).
#[inline(always)]
fn attenuation(b: BlockId) -> u8 {
    if b.is_opaque() {
        15
    } else {
        b.info().light_filter.max(1)
    }
}

const DIRS: [(i32, i32, i32); 6] = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)];

type Queue = VecDeque<(u8, u8, u16)>;

fn flood(chunk: &Chunk, light: &mut [u8], queue: &mut Queue, sky: bool) {
    // queue entries are (x, z, y) packed to avoid heap churn
    while let Some((x, z, y)) = queue.pop_front() {
        let (xu, zu, yu) = (x as usize, z as usize, y as usize);
        let cur = light[idx(xu, yu, zu)];
        if cur <= 1 {
            continue;
        }
        for (dx, dy, dz) in DIRS {
            let nx = xu as i32 + dx;
            let nz = zu as i32 + dz;
            let ny = yu as i32 + dy;
            if !(0..16).contains(&nx) || !(0..16).contains(&nz) || !(0..H as i32).contains(&ny) {
                continue;
            }
            let (nxu, nyu, nzu) = (nx as usize, ny as usize, nz as usize);
            let nb = chunk.get_block(nxu, ny + MIN_Y, nzu);
            if nb.is_opaque() {
                continue;
            }
            let loss = if sky && dy == -1 && cur == 15 && nb.info().light_filter == 0 { 0 } else { attenuation(nb) };
            let next = cur.saturating_sub(loss);
            let slot = &mut light[idx(nxu, nyu, nzu)];
            if next > *slot {
                *slot = next;
                queue.push_back((nxu as u8, nzu as u8, nyu as u16));
            }
        }
    }
}

/// Seeds light entering through the four chunk borders from loaded neighbours
/// (`[+x, -x, +z, -z]`).
fn seed_from_neighbours(chunk: &Chunk, nb: &[Option<&Chunk>; 4], sky: &mut [u8], blk: &mut [u8], qs: &mut Queue, qb: &mut Queue) {
    for (side, n) in nb.iter().enumerate() {
        let Some(n) = n else { continue };
        for a in 0..16usize {
            // (x, z) of the border cell in `chunk` and the touching cell in the neighbour
            let ((x, z), (nx, nz)) = match side {
                0 => ((15, a), (0, a)),
                1 => ((0, a), (15, a)),
                2 => ((a, 15), (a, 0)),
                _ => ((a, 0), (a, 15)),
            };
            for y in 0..H {
                let wy = y as i32 + MIN_Y;
                let b = chunk.get_block(x, wy, z);
                if b.is_opaque() {
                    continue;
                }
                let att = attenuation(b);
                let ns = n.sky_light_at(nx, wy, nz);
                let nbk = n.block_light_at(nx, wy, nz);
                let (cs, cb) = (ns.saturating_sub(att), nbk.saturating_sub(att));
                if cs > sky[idx(x, y, z)] {
                    sky[idx(x, y, z)] = cs;
                    qs.push_back((x as u8, z as u8, y as u16));
                }
                if cb > blk[idx(x, y, z)] {
                    blk[idx(x, y, z)] = cb;
                    qb.push_back((x as u8, z as u8, y as u16));
                }
            }
        }
    }
}

/// Computes sky + block light for the whole chunk (no neighbour information).
pub fn compute_chunk_light(chunk: &mut Chunk) {
    compute_chunk_light_with_neighbours(chunk, [None, None, None, None]);
}

/// Same as [`compute_chunk_light`] but light spills in from the given neighbours `[+x, -x, +z, -z]`.
pub fn compute_chunk_light_with_neighbours(chunk: &mut Chunk, nb: [Option<&Chunk>; 4]) {
    let mut sky = vec![0u8; VOL];
    let mut blk = vec![0u8; VOL];
    let mut q_sky: Queue = VecDeque::new();
    let mut q_blk: Queue = VecDeque::new();

    // First free y (relative to MIN_Y) of every column: everything from there up is sky-lit.
    let mut tops = [0usize; 256];
    for z in 0..16usize {
        for x in 0..16usize {
            let top = (chunk.height_at(x, z, HeightmapKind::WorldSurface) - MIN_Y).clamp(0, H as i32 - 1) as usize;
            tops[(z << 4) | x] = top;
            for y in top..H {
                sky[idx(x, y, z)] = 15;
            }
        }
    }
    // Seed the flood only where a lit cell touches a lower (darker) neighbour column.
    for z in 0..16usize {
        for x in 0..16usize {
            let top = tops[(z << 4) | x];
            let mut max_nb = top;
            for (dx, dz) in [(1i32, 0i32), (-1, 0), (0, 1), (0, -1)] {
                let (nx, nz) = (x as i32 + dx, z as i32 + dz);
                if (0..16).contains(&nx) && (0..16).contains(&nz) {
                    max_nb = max_nb.max(tops[((nz as usize) << 4) | nx as usize]);
                }
            }
            for y in top..=max_nb.min(H - 1) {
                q_sky.push_back((x as u8, z as u8, y as u16));
            }
            // light must also leave downwards through transparent top blocks (leaves, water, glass)
            if top > 0 {
                q_sky.push_back((x as u8, z as u8, top as u16));
            }
        }
    }

    for si in 0..SECTION_COUNT {
        if chunk.sections[si].is_empty() {
            continue;
        }
        for ly in 0..16usize {
            for z in 0..16usize {
                for x in 0..16usize {
                    let b = chunk.sections[si].get(x, ly, z);
                    let e = b.light_emission();
                    if e > 0 {
                        let y = si * 16 + ly;
                        blk[idx(x, y, z)] = e;
                        q_blk.push_back((x as u8, z as u8, y as u16));
                    }
                }
            }
        }
    }

    seed_from_neighbours(chunk, &nb, &mut sky, &mut blk, &mut q_sky, &mut q_blk);
    flood(chunk, &mut sky, &mut q_sky, true);
    flood(chunk, &mut blk, &mut q_blk, false);

    for si in 0..SECTION_COUNT {
        let mut sa = Box::new([0u8; 2048]);
        let mut ba = Box::new([0u8; 2048]);
        let (mut any_s, mut any_b) = (false, false);
        for ly in 0..16usize {
            let y = si * 16 + ly;
            for z in 0..16usize {
                for x in 0..16usize {
                    let i = idx(x, ly, z);
                    let s = sky[idx(x, y, z)];
                    let b = blk[idx(x, y, z)];
                    if s != 0 {
                        nibble_set(&mut sa, i, s);
                        any_s = true;
                    }
                    if b != 0 {
                        nibble_set(&mut ba, i, b);
                        any_b = true;
                    }
                }
            }
        }
        chunk.sections[si].sky_light = any_s.then_some(sa);
        chunk.sections[si].block_light = any_b.then_some(ba);
    }
    chunk.light_ready = true;
}

/// Day/night brightness multiplier (0.2 ..= 1.0) from the time of day in ticks (0 = sunrise).
/// Mirrors the shape of vanilla `Level.getSkyDarken`.
pub fn sky_brightness(day_time: u64, raining: f32, thundering: f32) -> f32 {
    let t = ((day_time + 18_000) % 24_000) as f32 / 24_000.0; // celestial angle, 0 = noon
    let mut a = 1.0 - ((t * std::f32::consts::TAU).cos() * 2.0 + 0.2);
    a = a.clamp(0.0, 1.0);
    a = 1.0 - a;
    a *= 1.0 - raining * 5.0 / 16.0;
    a *= 1.0 - thundering * 5.0 / 16.0;
    0.2 + a * 0.8
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::math::ChunkPos;

    fn sky(c: &Chunk, x: usize, y: i32, z: usize) -> u8 {
        let ry = (y - MIN_Y) as usize;
        c.sections[ry >> 4].get_sky_light(x, ry & 15, z)
    }
    fn blk(c: &Chunk, x: usize, y: i32, z: usize) -> u8 {
        let ry = (y - MIN_Y) as usize;
        c.sections[ry >> 4].get_block_light(x, ry & 15, z)
    }

    fn floor_chunk() -> Chunk {
        let mut c = Chunk::new(ChunkPos::new(0, 0));
        for x in 0..16 {
            for z in 0..16 {
                for y in -64..=63 {
                    c.set_block(x, y, z, BlockId::STONE);
                }
            }
        }
        c
    }

    #[test]
    fn open_sky_is_fully_lit() {
        let mut c = floor_chunk();
        compute_chunk_light(&mut c);
        assert_eq!(sky(&c, 8, 64, 8), 15);
        assert_eq!(sky(&c, 8, 200, 8), 15);
        assert_eq!(sky(&c, 8, 10, 8), 0); // inside stone
    }

    #[test]
    fn torch_like_emitter_falls_off_by_one_per_block() {
        let mut c = floor_chunk();
        c.set_block(8, 64, 8, BlockId::GLOWSTONE);
        compute_chunk_light(&mut c);
        assert_eq!(blk(&c, 8, 64, 8), 15);
        assert_eq!(blk(&c, 8, 65, 8), 14);
        assert_eq!(blk(&c, 10, 65, 8), 12);
    }

    #[test]
    fn glass_and_water_do_not_block_sky_light() {
        let mut c = floor_chunk();
        c.set_block(8, 70, 8, BlockId::GLASS);
        c.set_block(9, 66, 9, BlockId::WATER);
        compute_chunk_light(&mut c);
        // vertical sky light passes through glass with no loss
        assert_eq!(sky(&c, 8, 69, 8), 15);
        assert_eq!(sky(&c, 8, 71, 8), 15);
        // water absorbs 1 per block but does not block
        assert!(sky(&c, 9, 65, 9) >= 13, "{}", sky(&c, 9, 65, 9));
    }

    #[test]
    fn light_crosses_chunk_borders() {
        let mut a = floor_chunk();
        let mut b = Chunk::new(ChunkPos::new(1, 0));
        for x in 0..16 {
            for z in 0..16 {
                for y in -64..=63 {
                    b.set_block(x, y, z, BlockId::STONE);
                }
            }
        }
        b.set_block(0, 64, 8, BlockId::GLOWSTONE);
        compute_chunk_light(&mut b);
        compute_chunk_light_with_neighbours(&mut a, [Some(&b), None, None, None]);
        assert_eq!(blk(&a, 15, 64, 8), 14);
        assert_eq!(blk(&a, 13, 64, 8), 12);
    }

    #[test]
    fn brightness_curve() {
        assert!(sky_brightness(6000, 0.0, 0.0) > 0.95); // noon
        assert!(sky_brightness(18000, 0.0, 0.0) < 0.3); // midnight
        assert!(sky_brightness(6000, 1.0, 0.0) < sky_brightness(6000, 0.0, 0.0));
    }

    #[test]
    fn roof_blocks_sky_but_light_leaks_in_from_the_side() {
        let mut c = floor_chunk();
        for x in 4..12 {
            for z in 4..12 {
                c.set_block(x, 66, z, BlockId::STONE);
            }
        }
        compute_chunk_light(&mut c);
        assert_eq!(sky(&c, 8, 67, 8), 15);
        let under_edge = sky(&c, 4, 65, 8);
        let under_mid = sky(&c, 8, 65, 8);
        assert!(under_edge > under_mid, "edge {under_edge} mid {under_mid}");
        assert!(under_mid < 15);
    }
}
