//! Integration tests that use only the public API (like a game client would).

use blockforge_core::block::BlockId;
use blockforge_core::chunk::Chunk;
use blockforge_core::game::{fall_damage, Vitals};
use blockforge_core::manager::ChunkManager;
use blockforge_core::math::{BlockPos, ChunkPos, Vec3};
use blockforge_core::physics::{Input, Player};
use blockforge_core::world::World;
use std::time::{Duration, Instant};

fn flat_world(top: BlockId) -> World {
    let mut w = World::new(1);
    for cx in -2..=2 {
        for cz in -2..=2 {
            let mut c = Chunk::new(ChunkPos::new(cx, cz));
            for x in 0..16 {
                for z in 0..16 {
                    for y in -64..=59 {
                        c.set_block(x, y, z, BlockId::STONE);
                    }
                    c.set_block(x, 60, z, top);
                }
            }
            c.rebuild_heightmaps();
            w.insert_chunk(c);
        }
    }
    w
}

fn settle(p: &mut Player, w: &World, ticks: usize) {
    for _ in 0..ticks {
        p.tick(w, Input::default());
    }
}

#[test]
fn walking_speed_matches_vanilla() {
    let w = flat_world(BlockId::STONE);
    let mut p = Player::new(Vec3::new(0.5, 61.0, 0.5));
    settle(&mut p, &w, 10);
    let start = p.pos.x;
    p.yaw = -90.0; // face +x
    for _ in 0..40 {
        p.tick(&w, Input { forward: 1.0, ..Default::default() });
    }
    let speed = (p.pos.x - start) / 2.0; // 40 ticks = 2 s
    assert!((speed - 4.317).abs() < 0.25, "walk speed {speed}");
}

#[test]
fn ice_is_slippery_and_soul_sand_is_slow() {
    let ice = flat_world(BlockId::ICE);
    let sand = flat_world(BlockId::SOUL_SAND);
    let stone = flat_world(BlockId::STONE);
    let run = |w: &World| {
        let mut p = Player::new(Vec3::new(0.5, 61.0, 0.5));
        p.yaw = -90.0;
        settle(&mut p, w, 5);
        let s = p.pos.x;
        for _ in 0..30 {
            p.tick(w, Input { forward: 1.0, ..Default::default() });
        }
        let at_stop = p.pos.x - s;
        for _ in 0..20 {
            p.tick(w, Input::default());
        }
        (at_stop, p.pos.x - s - at_stop) // distance while pushing, distance while gliding
    };
    let (_, glide_ice) = run(&ice);
    let (_, glide_stone) = run(&stone);
    let (walk_sand, _) = run(&sand);
    let (walk_stone, _) = run(&stone);
    assert!(glide_ice > glide_stone * 3.0, "ice glide {glide_ice} vs stone {glide_stone}");
    assert!(walk_sand < walk_stone * 0.8, "soul sand {walk_sand} vs stone {walk_stone}");
}

#[test]
fn fall_damage_is_reported_once_on_landing() {
    let w = flat_world(BlockId::STONE);
    let mut p = Player::new(Vec3::new(0.5, 80.0, 0.5));
    let mut reported = 0.0;
    let mut times = 0;
    for _ in 0..80 {
        p.tick(&w, Input::default());
        if p.landed_fall > 0.0 {
            reported = p.landed_fall;
            times += 1;
        }
    }
    assert_eq!(times, 1);
    assert!((reported - 19.0).abs() < 0.5, "fell {reported}");
    let mut v = Vitals::default();
    v.damage(fall_damage(reported, 0, 0));
    assert!(v.health < 5.0);
}

#[test]
fn water_cancels_fall_damage_and_ladders_hold() {
    let mut w = flat_world(BlockId::STONE);
    for y in 61..=75 {
        for x in -3..=3 {
            for z in -3..=3 {
                w.set_block(x, y, z, BlockId::WATER);
            }
        }
    }
    let mut p = Player::new(Vec3::new(0.5, 90.0, 0.5));
    let mut max_landed: f64 = 0.0;
    for _ in 0..120 {
        p.tick(&w, Input::default());
        max_landed = max_landed.max(p.landed_fall);
    }
    assert_eq!(max_landed, 0.0, "landing in water must not hurt");
    assert!(p.eyes_in_water || p.in_water);

    // ladder: stand against a wall and climb
    let mut w = flat_world(BlockId::STONE);
    for y in 61..=70 {
        w.set_block(2, y, 0, BlockId::STONE);
        w.set_block(1, y, 0, BlockId::LADDER);
    }
    let mut p = Player::new(Vec3::new(1.5, 61.0, 0.5));
    for _ in 0..60 {
        p.tick(&w, Input { jump: true, ..Default::default() });
    }
    assert!(p.pos.y > 64.0, "climbed to {}", p.pos.y);
    // letting go does not fall like a rock
    for _ in 0..10 {
        p.tick(&w, Input { sneak: true, ..Default::default() });
    }
    let held = p.pos.y;
    for _ in 0..10 {
        p.tick(&w, Input { sneak: true, ..Default::default() });
    }
    assert!((p.pos.y - held).abs() < 0.05);
}

#[test]
fn creative_flight_ignores_gravity() {
    let w = flat_world(BlockId::STONE);
    let mut p = Player::new(Vec3::new(0.5, 90.0, 0.5));
    p.can_fly = true;
    p.flying = true;
    let y0 = p.pos.y;
    for _ in 0..40 {
        p.tick(&w, Input::default());
    }
    assert!((p.pos.y - y0).abs() < 0.01, "should hover, moved {}", p.pos.y - y0);
    for _ in 0..20 {
        p.tick(&w, Input { jump: true, ..Default::default() });
    }
    assert!(p.pos.y > y0 + 3.0);
    p.can_fly = false;
    p.tick(&w, Input::default());
    assert!(!p.flying, "losing can_fly must end flight");
}

#[test]
fn lava_slows_and_cobweb_traps() {
    let mut w = flat_world(BlockId::STONE);
    for y in 61..=70 {
        w.set_block(0, y, 0, BlockId::LAVA);
    }
    let mut p = Player::new(Vec3::new(0.5, 70.0, 0.5));
    for _ in 0..30 {
        p.tick(&w, Input::default());
    }
    assert!(p.in_lava);
    assert!(p.pos.y > 61.5, "lava should be slow to sink in, y={}", p.pos.y);
    let mut w = flat_world(BlockId::STONE);
    for y in 61..=90 {
        w.set_block(0, y, 0, BlockId::COBWEB);
    }
    let mut p = Player::new(Vec3::new(0.5, 90.0, 0.5));
    for _ in 0..20 {
        p.tick(&w, Input::default());
    }
    assert!(p.pos.y > 85.0, "cobweb must hold the player, y={}", p.pos.y);
}

#[test]
fn threaded_pipeline_generates_lights_meshes_and_simulates() {
    let mut m = ChunkManager::new(31337, 4);
    let centre = ChunkPos::new(0, 0);
    let t = Instant::now();
    while !(m.is_idle() && m.world.loaded_count() > 20) {
        m.update(centre, 3);
        assert!(t.elapsed() < Duration::from_secs(60), "pipeline stalled");
        std::thread::sleep(Duration::from_millis(2));
    }
    assert!(!m.meshes.is_empty());
    // cross-chunk light: pick any border column and verify sky light is continuous there
    let y = m.world.height_at(15, 0, blockforge_core::chunk::HeightmapKind::WorldSurface).unwrap();
    assert!(m.world.sky_light(15, y + 1, 0) >= 14 && m.world.sky_light(16, y + 1, 0) >= 12);
    // edit + simulate: a water source poured on the surface spreads
    let top = m.world.height_at(2, 2, blockforge_core::chunk::HeightmapKind::WorldSurface).unwrap();
    assert!(m.set_block(2, top + 8, 2, BlockId::WATER));
    let mut changes = 0;
    for _ in 0..120 {
        changes += m.tick_world(centre, 3);
    }
    assert!(changes > 10, "fluid sim produced only {changes} changes");
    assert!(m.world.get_block_pos(BlockPos::new(2, top + 8, 2)).is_water() || m.world.get_block_pos(BlockPos::new(2, top + 7, 2)).is_water());
}
